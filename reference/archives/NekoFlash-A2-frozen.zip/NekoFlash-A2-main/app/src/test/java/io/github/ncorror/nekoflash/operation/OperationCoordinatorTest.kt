package io.github.ncorror.nekoflash.operation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OperationCoordinatorTest {
    private val kind = OperationCoordinator.Kind.FASTBOOT_DIAGNOSTIC_REFRESH

    @Test
    fun startsIdle() {
        val coordinator = OperationCoordinator()
        assertNull(coordinator.currentObservation().active)
        assertNull(coordinator.currentObservation().lastCompleted)
    }

    @Test
    fun onlyOneOperationCanOwnTheSlot() {
        val coordinator = OperationCoordinator()
        val first = coordinator.tryBegin(kind)
        val second = coordinator.tryBegin(kind)
        assertTrue(first != null)
        assertNull(second)
    }

    @Test
    fun newOperationStartsInStartingStage() {
        val coordinator = OperationCoordinator()
        coordinator.tryBegin(kind)!!
        assertEquals(OperationCoordinator.Stage.STARTING, coordinator.currentObservation().active?.stage)
    }

    @Test
    fun listenerReceivesCurrentStateImmediatelyAndTransitions() {
        val coordinator = OperationCoordinator()
        val observations = mutableListOf<OperationCoordinator.Observation>()
        coordinator.replaceObservationListener(observations::add)
        val lease = coordinator.tryBegin(kind)!!
        lease.complete(OperationCoordinator.Outcome.SUCCEEDED)
        assertEquals(3, observations.size)
        assertNull(observations[0].active)
        assertEquals(lease.generation, observations[1].active?.generation)
        assertNull(observations[2].active)
        assertEquals(OperationCoordinator.Outcome.SUCCEEDED, observations[2].lastCompleted?.outcome)
    }

    @Test
    fun stageAdvanceIsObservableAndGenerationSafe() {
        val coordinator = OperationCoordinator()
        val observations = mutableListOf<OperationCoordinator.Observation>()
        coordinator.replaceObservationListener(observations::add)
        val lease = coordinator.tryBegin(kind)!!
        assertTrue(lease.updateStage(OperationCoordinator.Stage.RUNNING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.FINALIZING))
        assertEquals(OperationCoordinator.Stage.RUNNING, observations[2].active?.stage)
        assertEquals(OperationCoordinator.Stage.FINALIZING, observations[3].active?.stage)
    }

    @Test
    fun stageCannotMoveBackwards() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(kind)!!
        assertTrue(lease.updateStage(OperationCoordinator.Stage.RUNNING))
        assertFalse(lease.updateStage(OperationCoordinator.Stage.STARTING))
        assertEquals(OperationCoordinator.Stage.RUNNING, coordinator.currentObservation().active?.stage)
    }

    @Test
    fun completionReleasesSlotAndRecordsOutcome() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(kind)!!
        assertTrue(lease.complete(OperationCoordinator.Outcome.FAILED))
        val observation = coordinator.currentObservation()
        assertNull(observation.active)
        assertEquals(lease.generation, observation.lastCompleted?.generation)
        assertEquals(OperationCoordinator.Outcome.FAILED, observation.lastCompleted?.outcome)
        assertTrue(coordinator.tryBegin(kind) != null)
    }

    @Test
    fun staleLeaseCannotClearNewOperation() {
        val coordinator = OperationCoordinator()
        val oldLease = coordinator.tryBegin(kind)!!
        assertTrue(oldLease.complete(OperationCoordinator.Outcome.SUCCEEDED))
        val newLease = coordinator.tryBegin(kind)!!
        assertFalse(oldLease.complete(OperationCoordinator.Outcome.ABORTED))
        assertEquals(newLease.generation, coordinator.currentObservation().active?.generation)
    }

    @Test
    fun staleLeaseCannotAdvanceNewOperationStage() {
        val coordinator = OperationCoordinator()
        val oldLease = coordinator.tryBegin(kind)!!
        assertTrue(oldLease.complete(OperationCoordinator.Outcome.SUCCEEDED))
        val newLease = coordinator.tryBegin(kind)!!
        assertFalse(oldLease.updateStage(OperationCoordinator.Stage.FINALIZING))
        assertEquals(OperationCoordinator.Stage.STARTING, coordinator.currentObservation().active?.stage)
        assertEquals(newLease.generation, coordinator.currentObservation().active?.generation)
    }

    @Test
    fun clearingOldListenerGenerationDoesNotClearReplacement() {
        val coordinator = OperationCoordinator()
        var firstCalls = 0
        var secondCalls = 0
        val firstGeneration = coordinator.replaceObservationListener { firstCalls++ }
        val secondGeneration = coordinator.replaceObservationListener { secondCalls++ }
        coordinator.clearObservationListener(firstGeneration)
        val lease = coordinator.tryBegin(kind)!!
        lease.complete(OperationCoordinator.Outcome.SUCCEEDED)
        assertEquals(1, firstCalls)
        assertEquals(3, secondCalls)
        coordinator.clearObservationListener(secondGeneration)
    }

    @Test
    fun abortedOutcomeIsDistinctFromFailure() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(kind)!!
        assertTrue(lease.complete(OperationCoordinator.Outcome.ABORTED))
        assertEquals(OperationCoordinator.Outcome.ABORTED, coordinator.currentObservation().lastCompleted?.outcome)
    }

    @Test
    fun stageTransitionsDoNotChangeTerminalOutcome() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(kind)!!
        assertTrue(lease.updateStage(OperationCoordinator.Stage.RUNNING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.FINALIZING))
        assertTrue(lease.complete(OperationCoordinator.Outcome.SUCCEEDED))
        assertEquals(OperationCoordinator.Outcome.SUCCEEDED, coordinator.currentObservation().lastCompleted?.outcome)
        assertNull(coordinator.currentObservation().active)
    }
    @Test
    fun cancellationMovesToCancellingAndInvokesHandlerWithoutCompleting() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH)!!
        var handlerCalls = 0
        assertTrue(lease.setCancellationHandler { handlerCalls++ })

        assertTrue(coordinator.requestCancellation())

        val active = coordinator.currentObservation().active
        assertEquals(1, handlerCalls)
        assertEquals(OperationCoordinator.Stage.CANCELLING, active?.stage)
        assertTrue(active?.cancellationRequested == true)
        assertNull(coordinator.currentObservation().lastCompleted)
        assertNull(coordinator.tryBegin(kind))
    }

    @Test
    fun cancelledLeaseRemainsOwnerUntilCleanupCompletes() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH)!!
        assertTrue(coordinator.requestCancellation())
        assertTrue(lease.isCancellationRequested())
        assertFalse(lease.updateStage(OperationCoordinator.Stage.FINALIZING))
        assertFalse(
            lease.updateProgress(
                OperationCoordinator.Progress(1, 2, 50, 1.0, 1000),
            ),
        )
        assertNull(coordinator.tryBegin(kind))

        assertTrue(lease.complete(OperationCoordinator.Outcome.ABORTED, "cleanup complete"))
        assertEquals(OperationCoordinator.Outcome.ABORTED, coordinator.currentObservation().lastCompleted?.outcome)
        assertEquals("cleanup complete", coordinator.currentObservation().lastCompleted?.message)
        assertTrue(coordinator.tryBegin(kind) != null)
    }

    @Test
    fun cancellationRequestedBeforeHandlerInstallationIsDeliveredImmediately() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH)!!
        assertTrue(coordinator.requestCancellation())

        var calls = 0
        assertTrue(lease.setCancellationHandler { calls++ })

        assertEquals(1, calls)
        assertTrue(lease.isCancellationRequested())
        assertEquals(OperationCoordinator.Stage.CANCELLING, coordinator.currentObservation().active?.stage)
    }

    @Test
    fun cancellationHandlerIsGenerationSafe() {
        val coordinator = OperationCoordinator()
        val oldLease = coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH)!!
        var oldHandlerCalls = 0
        assertTrue(oldLease.setCancellationHandler { oldHandlerCalls++ })
        assertTrue(oldLease.complete(OperationCoordinator.Outcome.SUCCEEDED))

        val newLease = coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH)!!
        var newHandlerCalls = 0
        assertTrue(newLease.setCancellationHandler { newHandlerCalls++ })
        assertFalse(oldLease.setCancellationHandler { oldHandlerCalls++ })
        assertTrue(coordinator.requestCancellation())

        assertEquals(0, oldHandlerCalls)
        assertEquals(1, newHandlerCalls)
    }

    @Test
    fun finalizingOperationRejectsLateCancellation() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH)!!
        assertTrue(lease.updateStage(OperationCoordinator.Stage.RUNNING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.FINALIZING))

        assertFalse(coordinator.requestCancellation())
        assertFalse(lease.isCancellationRequested())
        assertEquals(OperationCoordinator.Stage.FINALIZING, coordinator.currentObservation().active?.stage)
    }

    @Test
    fun writingOperationRejectsCancellationBecauseMutationMayAlreadyBeCommitted() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH)!!
        assertTrue(lease.updateStage(OperationCoordinator.Stage.RUNNING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.AUTHORIZING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.TRANSFERRING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.WRITING))

        assertFalse(coordinator.requestCancellation())
        assertFalse(lease.isCancellationRequested())
        assertEquals(OperationCoordinator.Stage.WRITING, coordinator.currentObservation().active?.stage)
    }

    @Test
    fun progressIsMonotonicAndTotalCannotChange() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH)!!
        val first = OperationCoordinator.Progress(25, 100, 25, 50.0, 1500)
        val second = OperationCoordinator.Progress(75, 100, 75, 75.0, 333)
        assertTrue(lease.updateProgress(first))
        assertTrue(lease.updateProgress(second))
        assertFalse(lease.updateProgress(first))
        assertFalse(
            lease.updateProgress(OperationCoordinator.Progress(80, 101, 79, 80.0, 250)),
        )
        assertEquals(second, coordinator.currentObservation().active?.progress)
    }

    @Test
    fun metadataAndProgressArePreservedInTerminalObservation() {
        val coordinator = OperationCoordinator()
        val metadata = OperationCoordinator.Metadata(
            product = "vayu",
            fileName = "boot.img",
            partition = "boot_b",
            slot = "exact",
            totalBytes = 1024,
        )
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH, metadata)!!
        val progress = OperationCoordinator.Progress(1024, 1024, 100, 1024.0, 0)
        assertTrue(lease.updateProgress(progress))
        assertTrue(lease.complete(OperationCoordinator.Outcome.SUCCEEDED, "done"))

        val completed = coordinator.currentObservation().lastCompleted
        assertEquals(metadata, completed?.metadata)
        assertEquals(progress, completed?.progress)
        assertEquals("done", completed?.message)
    }

}
