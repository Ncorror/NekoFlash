package io.github.ncorror.nekoflash.fastboot.transport

/**
 * Additional Fastboot variables collected for diagnostics after the core set.
 *
 * The order remains deterministic for comparable diagnostics, while command execution
 * itself is handled by the generic Fastboot transaction layer. The `anti` ->
 * `antirollback` fallback preserves device compatibility.
 */
internal object FastbootExtendedDiagnosticsPlan {
    val beforeAnti: List<FastbootCoreDiagnosticsPlan.Variable> = listOf(
        FastbootCoreDiagnosticsPlan.Variable("slot-suffix"),
        FastbootCoreDiagnosticsPlan.Variable("secure"),
        FastbootCoreDiagnosticsPlan.Variable("serialno", sensitive = true),
        FastbootCoreDiagnosticsPlan.Variable("version-bootloader"),
    )

    val antiPrimary = FastbootCoreDiagnosticsPlan.Variable("anti")
    val antiFallback = FastbootCoreDiagnosticsPlan.Variable("antirollback")

    val afterAnti: List<FastbootCoreDiagnosticsPlan.Variable> = listOf(
        FastbootCoreDiagnosticsPlan.Variable("is-userspace"),
        FastbootCoreDiagnosticsPlan.Variable("super-partition-name"),
        FastbootCoreDiagnosticsPlan.Variable("snapshot-update-status"),
        FastbootCoreDiagnosticsPlan.Variable("max-fetch-size"),
    )

    val fixedCommandOrderWithoutFallback: List<String>
        get() = (beforeAnti + antiPrimary + afterAnti).map { it.command }

    fun shouldQueryAntiRollback(primaryValue: String?): Boolean = primaryValue.isNullOrBlank()
}

internal data class FastbootExtendedDiagnostics(
    val slotSuffix: String? = null,
    val secure: String? = null,
    val serialReported: Boolean = false,
    val versionBootloader: String? = null,
    val antiRollback: String? = null,
    val antiRollbackSource: String? = null,
    val isUserspace: String? = null,
    val superPartitionName: String? = null,
    val snapshotUpdateStatus: String? = null,
    val maxFetchSizeRaw: String? = null,
    val maxFetchSizeBytes: Long? = null,
)
