package io.github.ncorror.nekoflash

import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.stringResource
import io.github.ncorror.nekoflash.operation.OperationCoordinator
import io.github.ncorror.nekoflash.operation.QuickFlashPayloadStore
import io.github.ncorror.nekoflash.operation.QuickFlashSlotMode
import io.github.ncorror.nekoflash.operation.SideloadPayloadStore
import io.github.ncorror.nekoflash.ui.entry.EntryGateScreen
import io.github.ncorror.nekoflash.ui.home.HomeScreen
import io.github.ncorror.nekoflash.ui.theme.NekoFlashTheme
import io.github.ncorror.nekoflash.usb.session.UsbManualScanPrompt
import io.github.ncorror.nekoflash.usb.session.UsbSessionObservation
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val app
        get() = application as NekoFlashApplication

    private val entrySessionGate
        get() = app.entrySessionGate

    private val usbSessionCoordinator
        get() = app.usbSessionCoordinator

    private val operationCoordinator
        get() = app.operationCoordinator

    private val quickFlashPayloadStore
        get() = app.quickFlashPayloadStore

    private val sideloadPayloadStore
        get() = app.sideloadPayloadStore

    private var usbUiEntryGeneration: Long? = null
    private var usbObservationListenerGeneration: Long? = null
    private var operationObservationListenerGeneration: Long? = null
    private var quickFlashPayloadListenerGeneration: Long? = null
    private var sideloadPayloadListenerGeneration: Long? = null
    private var usbObservation by mutableStateOf(UsbSessionObservation())
    private var operationObservation by mutableStateOf(OperationCoordinator.Observation())
    private var usbManualScanPrompt by mutableStateOf<UsbManualScanPrompt?>(null)
    private var diagnosticsExportMessage by mutableStateOf<String?>(null)
    private var diagnosticsExportInProgress by mutableStateOf(false)
    private var quickFlashPayloadSnapshot by mutableStateOf<QuickFlashPayloadStore.Snapshot?>(null)
    private var quickFlashPayloadPreparing by mutableStateOf(false)
    private var quickFlashMessage by mutableStateOf<String?>(null)
    private var sideloadPayloadSnapshot by mutableStateOf<SideloadPayloadStore.Snapshot?>(null)
    private var sideloadPayloadPreparing by mutableStateOf(false)
    private var sideloadMessage by mutableStateOf<String?>(null)
    private val quickFlashDocumentExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "NekoFlash-QuickFlash-Document").apply { isDaemon = true }
    }
    private val sideloadDocumentExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "NekoFlash-Sideload-Document").apply { isDaemon = true }
    }

    private val diagnosticsArchiveLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument(DIAGNOSTICS_ARCHIVE_MIME_TYPE),
    ) { uri ->
        if (uri == null) {
            diagnosticsExportInProgress = false
            return@registerForActivityResult
        }
        if (!entrySessionGate.isSessionAuthorized()) {
            diagnosticsExportInProgress = false
            diagnosticsExportMessage = getString(R.string.diagnostics_export_session_ended)
            return@registerForActivityResult
        }
        if (uri.scheme != ContentResolver.SCHEME_CONTENT) {
            diagnosticsExportInProgress = false
            diagnosticsExportMessage = getString(R.string.diagnostics_export_failed)
            return@registerForActivityResult
        }
        exportDiagnosticsTo(uri)
    }

    private val quickFlashImageLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri == null) {
            quickFlashPayloadPreparing = false
            return@registerForActivityResult
        }
        if (!entrySessionGate.isSessionAuthorized() || uri.scheme != ContentResolver.SCHEME_CONTENT) {
            quickFlashPayloadPreparing = false
            quickFlashMessage = getString(R.string.quick_flash_session_ended)
            return@registerForActivityResult
        }

        quickFlashPayloadPreparing = true
        quickFlashMessage = getString(R.string.quick_flash_image_preparing)
        quickFlashDocumentExecutor.execute {
            val result = quickFlashPayloadStore.replaceFromUri(uri)
            runOnUiThread {
                if (!isDestroyed) {
                    quickFlashPayloadPreparing = false
                    result.fold(
                        onSuccess = { snapshot ->
                            quickFlashPayloadSnapshot = snapshot
                            quickFlashMessage = getString(
                                R.string.quick_flash_image_selected,
                                snapshot.displayName,
                            )
                        },
                        onFailure = {
                            quickFlashPayloadSnapshot = quickFlashPayloadStore.currentSnapshot()
                            quickFlashMessage = getString(R.string.quick_flash_image_failed)
                        },
                    )
                }
            }
        }
    }

    private val sideloadPackageLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri == null) {
            sideloadPayloadPreparing = false
            return@registerForActivityResult
        }
        if (!entrySessionGate.isSessionAuthorized() || uri.scheme != ContentResolver.SCHEME_CONTENT) {
            sideloadPayloadPreparing = false
            sideloadMessage = getString(R.string.sideload_session_ended)
            return@registerForActivityResult
        }

        sideloadPayloadPreparing = true
        sideloadMessage = getString(R.string.sideload_package_preparing)
        sideloadDocumentExecutor.execute {
            val result = sideloadPayloadStore.replaceFromUri(uri)
            runOnUiThread {
                if (!isDestroyed) {
                    sideloadPayloadPreparing = false
                    result.fold(
                        onSuccess = { snapshot ->
                            sideloadPayloadSnapshot = snapshot
                            sideloadMessage = getString(
                                R.string.sideload_package_selected,
                                snapshot.displayName,
                            )
                        },
                        onFailure = {
                            sideloadPayloadSnapshot = sideloadPayloadStore.currentSnapshot()
                            sideloadMessage = getString(R.string.sideload_package_failed)
                        },
                    )
                }
            }
        }
    }

    private val authorizedRootBackCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            // Pinned legacy MainActivity behavior: Back on the authorized root UI
            // backgrounds the task and keeps the entry session alive.
            moveTaskToBack(true)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val authorizedAtCreate = entrySessionGate.isSessionAuthorized()
        quickFlashPayloadListenerGeneration = quickFlashPayloadStore.replaceSnapshotListener { snapshot ->
            runOnUiThread {
                if (!isDestroyed) quickFlashPayloadSnapshot = snapshot
            }
        }
        sideloadPayloadListenerGeneration = sideloadPayloadStore.replaceSnapshotListener { snapshot ->
            runOnUiThread {
                if (!isDestroyed) sideloadPayloadSnapshot = snapshot
            }
        }
        authorizedRootBackCallback.isEnabled = authorizedAtCreate
        onBackPressedDispatcher.addCallback(this, authorizedRootBackCallback)
        if (authorizedAtCreate) {
            usbSessionCoordinator.start()
            bindUsbObservation()
            bindOperationObservation()
            usbUiEntryGeneration = usbSessionCoordinator.onActivityCreated(intent)
        }

        enableEdgeToEdge()
        setContent {
            var authorized by remember { mutableStateOf(authorizedAtCreate) }
            var riskAccepted by remember { mutableStateOf(entrySessionGate.isRiskAcknowledged()) }
            var errorResId by remember { mutableStateOf<Int?>(null) }

            NekoFlashTheme {
                if (authorized) {
                    HomeScreen(
                        observation = usbObservation,
                        operationObservation = operationObservation,
                        manualScanPrompt = usbManualScanPrompt,
                        diagnosticsExportInProgress = diagnosticsExportInProgress,
                        diagnosticsExportMessage = diagnosticsExportMessage,
                        sideloadPayload = sideloadPayloadSnapshot,
                        sideloadPayloadPreparing = sideloadPayloadPreparing,
                        sideloadMessage = sideloadMessage,
                        quickFlashPayload = quickFlashPayloadSnapshot,
                        quickFlashPayloadPreparing = quickFlashPayloadPreparing,
                        quickFlashMessage = quickFlashMessage,
                        onRefreshUsb = ::refreshUsb,
                        onRefreshFastbootDiagnostics = ::refreshFastbootDiagnostics,
                        onManualCandidateChosen = ::chooseManualCandidate,
                        onConfirmGenericFastboot = ::confirmGenericFastboot,
                        onDismissManualPrompt = ::dismissManualUsbPrompt,
                        onExportDiagnostics = ::requestDiagnosticsExport,
                        onChooseSideloadPackage = ::chooseSideloadPackage,
                        onClearSideloadPackage = ::clearSideloadPackage,
                        onStartSideload = ::startSideload,
                        onChooseQuickFlashImage = ::chooseQuickFlashImage,
                        onClearQuickFlashImage = ::clearQuickFlashImage,
                        onStartQuickFlash = ::startQuickFlash,
                        onCancelActiveOperation = ::cancelActiveOperation,
                    )
                } else {
                    EntryGateScreen(
                        riskAccepted = riskAccepted,
                        onRiskAcceptedChange = {
                            riskAccepted = it
                            errorResId = null
                        },
                        errorMessage = errorResId?.let { stringResource(it) },
                        onContinue = {
                            if (entrySessionGate.authorize(riskAccepted)) {
                                usbSessionCoordinator.start()
                                bindUsbObservation()
                                bindOperationObservation()
                                usbUiEntryGeneration =
                                    usbSessionCoordinator.onEntryAuthorized(intent)
                                errorResId = null
                                authorizedRootBackCallback.isEnabled = true
                                authorized = true
                            } else {
                                errorResId = if (riskAccepted) {
                                    R.string.entry_acknowledgement_save_failed
                                } else {
                                    R.string.entry_risk_required
                                }
                            }
                        },
                    )
                }
            }
        }
    }


    private fun bindUsbObservation() {
        usbObservationListenerGeneration?.let(usbSessionCoordinator::clearObservationListener)
        usbObservationListenerGeneration = usbSessionCoordinator.replaceObservationListener { observation ->
            usbObservation = observation
        }
    }

    private fun bindOperationObservation() {
        operationObservationListenerGeneration?.let(operationCoordinator::clearObservationListener)
        operationObservationListenerGeneration = operationCoordinator.replaceObservationListener { observation ->
            runOnUiThread {
                if (!isDestroyed) {
                    operationObservation = observation
                }
            }
        }
    }

    private fun refreshUsb() {
        usbManualScanPrompt = usbSessionCoordinator.refreshUsb()
    }

    private fun refreshFastbootDiagnostics() {
        usbSessionCoordinator.refreshFastbootDiagnostics()
    }

    private fun chooseManualCandidate(stableKey: String) {
        usbManualScanPrompt = usbSessionCoordinator.chooseManualCandidate(stableKey)
    }

    private fun confirmGenericFastboot(stableKey: String) {
        usbSessionCoordinator.confirmManualGenericFastboot(stableKey)
        usbManualScanPrompt = null
    }

    private fun dismissManualUsbPrompt() {
        usbSessionCoordinator.cancelManualUsbPrompt()
        usbManualScanPrompt = null
    }

    private fun chooseSideloadPackage() {
        if (
            !entrySessionGate.isSessionAuthorized() ||
            sideloadPayloadPreparing ||
            operationObservation.active != null
        ) return
        sideloadMessage = null
        sideloadPayloadPreparing = true
        runCatching {
            sideloadPackageLauncher.launch(
                arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"),
            )
        }.onFailure {
            sideloadPayloadPreparing = false
            sideloadMessage = getString(R.string.sideload_package_failed)
        }
    }

    private fun clearSideloadPackage() {
        if (operationObservation.active?.kind == OperationCoordinator.Kind.ADB_SIDELOAD) return
        sideloadPayloadStore.clear()
        sideloadPayloadSnapshot = null
        sideloadMessage = null
    }

    private fun startSideload() {
        if (!entrySessionGate.isSessionAuthorized()) {
            sideloadMessage = getString(R.string.sideload_session_ended)
            return
        }
        val payload = sideloadPayloadStore.take()
        if (payload == null) {
            sideloadPayloadSnapshot = null
            sideloadMessage = getString(R.string.sideload_package_missing)
            return
        }
        sideloadPayloadSnapshot = null
        sideloadMessage = null
        if (!usbSessionCoordinator.startSideload(payload)) {
            sideloadMessage = getString(R.string.sideload_start_rejected)
        }
    }

    private fun chooseQuickFlashImage() {
        if (
            !entrySessionGate.isSessionAuthorized() ||
            quickFlashPayloadPreparing ||
            operationObservation.active != null
        ) return
        quickFlashMessage = null
        quickFlashPayloadPreparing = true
        runCatching { quickFlashImageLauncher.launch(arrayOf("*/*")) }
            .onFailure {
                quickFlashPayloadPreparing = false
                quickFlashMessage = getString(R.string.quick_flash_image_failed)
            }
    }

    private fun clearQuickFlashImage() {
        if (operationObservation.active?.kind == OperationCoordinator.Kind.FASTBOOT_FLASH) return
        quickFlashPayloadStore.clear()
        quickFlashPayloadSnapshot = null
        quickFlashMessage = null
    }

    private fun startQuickFlash(partition: String, slotMode: QuickFlashSlotMode) {
        if (!entrySessionGate.isSessionAuthorized()) {
            quickFlashMessage = getString(R.string.quick_flash_session_ended)
            return
        }
        val payload = quickFlashPayloadStore.take()
        if (payload == null) {
            quickFlashPayloadSnapshot = null
            quickFlashMessage = getString(R.string.quick_flash_image_missing)
            return
        }
        quickFlashPayloadSnapshot = null
        quickFlashMessage = null
        if (!usbSessionCoordinator.startQuickFlash(partition, slotMode, payload)) {
            quickFlashMessage = getString(R.string.quick_flash_start_rejected)
        }
    }

    private fun cancelActiveOperation() {
        val activeKind = operationObservation.active?.kind
        if (!usbSessionCoordinator.cancelActiveOperation()) {
            if (activeKind == OperationCoordinator.Kind.ADB_SIDELOAD) {
                sideloadMessage = getString(R.string.sideload_cancel_rejected)
            } else {
                quickFlashMessage = getString(R.string.quick_flash_cancel_rejected)
            }
        }
    }

    private fun requestDiagnosticsExport() {
        if (!entrySessionGate.isSessionAuthorized() || diagnosticsExportInProgress) return
        diagnosticsExportInProgress = true
        diagnosticsExportMessage = null
        runCatching {
            diagnosticsArchiveLauncher.launch(
                usbSessionCoordinator.suggestedDiagnosticsArchiveFileName(),
            )
        }.onFailure {
            diagnosticsExportInProgress = false
            diagnosticsExportMessage = getString(R.string.diagnostics_export_failed)
        }
    }

    private fun exportDiagnosticsTo(uri: Uri) {
        diagnosticsExportMessage = getString(R.string.diagnostics_export_saving)
        val executor = Executors.newSingleThreadExecutor()
        executor.execute {
            try {
                val result = runCatching {
                    val output = contentResolver.openOutputStream(uri, "w")
                        ?: error("Document provider returned no output stream")
                    output.use { stream ->
                        usbSessionCoordinator.exportDiagnosticsArchive(stream)
                    }
                }
                runOnUiThread {
                    if (!isDestroyed) {
                        diagnosticsExportInProgress = false
                        diagnosticsExportMessage = result.fold(
                            onSuccess = { exported ->
                                getString(R.string.diagnostics_export_saved, exported.sourceFileCount)
                            },
                            onFailure = {
                                getString(R.string.diagnostics_export_failed)
                            },
                        )
                    }
                }
            } finally {
                executor.shutdown()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (entrySessionGate.isSessionAuthorized()) {
            usbSessionCoordinator.onActivityNewIntent(intent)
        }
    }

    override fun onDestroy() {
        usbSessionCoordinator.cancelManualUsbPrompt()
        usbManualScanPrompt = null
        usbUiEntryGeneration?.let { usbSessionCoordinator.onActivityDestroyed(it) }
        usbUiEntryGeneration = null
        usbObservationListenerGeneration?.let(usbSessionCoordinator::clearObservationListener)
        usbObservationListenerGeneration = null
        operationObservationListenerGeneration?.let(operationCoordinator::clearObservationListener)
        operationObservationListenerGeneration = null
        quickFlashPayloadListenerGeneration?.let(quickFlashPayloadStore::clearSnapshotListener)
        quickFlashPayloadListenerGeneration = null
        sideloadPayloadListenerGeneration?.let(sideloadPayloadStore::clearSnapshotListener)
        sideloadPayloadListenerGeneration = null
        quickFlashDocumentExecutor.shutdown()
        sideloadDocumentExecutor.shutdown()
        if (!isChangingConfigurations) {
            quickFlashPayloadStore.clear()
            sideloadPayloadStore.clear()
            entrySessionGate.endSession()
            usbSessionCoordinator.stop()
        }
        super.onDestroy()
    }

    private companion object {
        const val DIAGNOSTICS_ARCHIVE_MIME_TYPE = "application/zip"
    }
}
