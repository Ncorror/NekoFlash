package io.github.ncorror.nekoflash.operation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SideloadOperationCoordinatorTest {
    @Test
    fun verificationPendingIsDistinctFromSucceeded() {
        val coordinator = OperationCoordinator()
        val metadata = OperationCoordinator.Metadata(
            fileName = "update.zip",
            totalBytes = 1234L,
            sha256 = "a".repeat(64),
        )
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.ADB_SIDELOAD, metadata)!!

        assertTrue(lease.complete(OperationCoordinator.Outcome.VERIFICATION_PENDING, "verify recovery"))

        val completed = coordinator.currentObservation().lastCompleted
        assertNull(coordinator.currentObservation().active)
        assertEquals(OperationCoordinator.Kind.ADB_SIDELOAD, completed?.kind)
        assertEquals(OperationCoordinator.Outcome.VERIFICATION_PENDING, completed?.outcome)
        assertFalse(completed?.outcome == OperationCoordinator.Outcome.SUCCEEDED)
        assertEquals(metadata, completed?.metadata)
    }

    @Test
    fun sideloadCancellationIsAcceptedDuringTransferAndWaitsForOwnerCleanup() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.ADB_SIDELOAD)!!
        var cleanupCalls = 0
        assertTrue(lease.setCancellationHandler { cleanupCalls++ })
        assertTrue(lease.updateStage(OperationCoordinator.Stage.RUNNING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.TRANSFERRING))

        assertTrue(coordinator.requestCancellation())

        val active = coordinator.currentObservation().active
        assertEquals(1, cleanupCalls)
        assertEquals(OperationCoordinator.Stage.CANCELLING, active?.stage)
        assertTrue(active?.cancellationRequested == true)
        assertNull(coordinator.currentObservation().lastCompleted)

        assertTrue(lease.complete(OperationCoordinator.Outcome.ABORTED, "transport closed"))
        assertEquals(OperationCoordinator.Outcome.ABORTED, coordinator.currentObservation().lastCompleted?.outcome)
    }

    @Test
    fun sideloadPayloadMutationBoundaryRejectsCancellation() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.ADB_SIDELOAD)!!
        var cleanupCalls = 0
        assertTrue(lease.setCancellationHandler { cleanupCalls++ })
        assertTrue(lease.updateStage(OperationCoordinator.Stage.RUNNING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.TRANSFERRING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.WRITING))

        assertFalse(coordinator.requestCancellation())

        val active = coordinator.currentObservation().active
        assertEquals(0, cleanupCalls)
        assertEquals(OperationCoordinator.Stage.WRITING, active?.stage)
        assertFalse(active?.cancellationRequested == true)
    }

    @Test
    fun sideloadFinalizingRejectsLateCancellation() {
        val coordinator = OperationCoordinator()
        val lease = coordinator.tryBegin(OperationCoordinator.Kind.ADB_SIDELOAD)!!
        assertTrue(lease.updateStage(OperationCoordinator.Stage.RUNNING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.TRANSFERRING))
        assertTrue(lease.updateStage(OperationCoordinator.Stage.FINALIZING))

        assertFalse(coordinator.requestCancellation())
        assertFalse(lease.isCancellationRequested())
        assertEquals(OperationCoordinator.Stage.FINALIZING, coordinator.currentObservation().active?.stage)
    }
    @Test
    fun restoredVerificationPendingBlocksNewOperationsUntilMatchingRecoveryVerdict() {
        val coordinator = OperationCoordinator()
        val pending = SideloadVerificationStore.Pending(
            operationGeneration = 7L,
            deviceLabel = "vayu",
            fileName = "update.zip",
            totalBytes = 4096L,
            sha256 = "a".repeat(64),
            startedAtEpochMs = 1000L,
            transferFinishedAtEpochMs = 2000L,
            message = "verify Recovery",
        )

        assertTrue(coordinator.restoreVerificationPending(pending))
        assertNull(coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH))
        assertFalse(
            coordinator.resolveSideloadVerification(
                expectedSha256 = "b".repeat(64),
                outcome = OperationCoordinator.Outcome.SUCCEEDED,
                message = "wrong package",
            ),
        )
        assertEquals(
            OperationCoordinator.Outcome.VERIFICATION_PENDING,
            coordinator.currentObservation().lastCompleted?.outcome,
        )

        assertTrue(
            coordinator.resolveSideloadVerification(
                expectedSha256 = pending.sha256,
                outcome = OperationCoordinator.Outcome.SUCCEEDED,
                message = "Recovery status=0",
            ),
        )
        assertEquals(
            OperationCoordinator.Outcome.SUCCEEDED,
            coordinator.currentObservation().lastCompleted?.outcome,
        )
        assertTrue(coordinator.tryBegin(OperationCoordinator.Kind.FASTBOOT_FLASH) != null)
    }

    @Test
    fun verificationResolverRejectsAbortedAsARecoveryVerdict() {
        val coordinator = OperationCoordinator()
        val pending = SideloadVerificationStore.Pending(
            operationGeneration = 3L,
            deviceLabel = null,
            fileName = "update.zip",
            totalBytes = 1L,
            sha256 = "c".repeat(64),
            startedAtEpochMs = 10L,
            transferFinishedAtEpochMs = 11L,
            message = null,
        )
        assertTrue(coordinator.restoreVerificationPending(pending))

        assertFalse(
            coordinator.resolveSideloadVerification(
                expectedSha256 = pending.sha256,
                outcome = OperationCoordinator.Outcome.ABORTED,
                message = "not a Recovery verdict",
            ),
        )
        assertEquals(
            OperationCoordinator.Outcome.VERIFICATION_PENDING,
            coordinator.currentObservation().lastCompleted?.outcome,
        )
    }

}
