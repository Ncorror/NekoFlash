# NekoFlash — Founding Decisions Log

Короткий журнал решений, которые нельзя потерять между чатами/итерациями.

## D001 — Clean repository
Новая кодовая база строится отдельно. Legacy/A2 — reference/evidence, не фундамент целиком.

## D002 — Product identity
Продукт остаётся **NekoFlash**. Сохраняем бренд, Legacy Welcome identity и иконку как visual reference.

## D003 — Professional capabilities
Нет искусственного урезания ADB/Fastboot/Recovery/Terminal capabilities. Risk warnings не являются authorization системой.

## D004 — Correctness is strict
Transport/protocol invariants, ownership, exact byte accounting, stale generation protection и честный Unknown не ослабляются ради «полной свободы».

## D005 — One generic core
GUI, raw terminal, Quick Flash и Mi Unlock используют общие ADB/Fastboot/USB engines.

## D006 — ADB is multi-stream
Новый ADB foundation сразу проектируется с настоящим stream router/demux. Не допускается single-stream architecture как permanent base.

## D007 — Fastboot is one transaction engine
Raw и typed commands проходят через один engine. Host preflight — advisory, если wire operation валидна.

## D008 — Mi Unlock is first-class
Mi Unlock не забывается в «потом vendor tools». Это значимая часть финального NekoFlash, реализуемая после стабильного generic core.

## D009 — Welcome remains
Welcome не удаляется. Убирается только старая модель «accept risks / permissions = authorization to use app».

## D010 — Device-centered UI
Главный UX объект — target device/session. Target identity видна постоянно во время работы.

## D011 — Terminal is real
Нужен настоящий terminal emulator и полноценный shell/raw console, а не TextField-симуляция.

## D012 — Operations outlive screens
Flash/Sideload/transfers принадлежат application-scoped operation layer/foreground service, не Activity/ViewModel.

## D013 — Large files are streaming
64-bit sizes, ArtifactSource/Sink, никакого whole-file buffering. SAF seekability не предполагается.

## D014 — Clean tree
Никаких `.orig`, parallel old/new paths, production stubs и obsolete normative docs.

## D015 — Hardware evidence
Hardware-sensitive core changes закрываются реальным evidence, а не только unit tests.

## D016 — Current A2 work is bounded
Перед freeze закрываем только pending `vayu` inbound framing gate (и минимально необходимый evidence), не продолжаем feature development A2.
