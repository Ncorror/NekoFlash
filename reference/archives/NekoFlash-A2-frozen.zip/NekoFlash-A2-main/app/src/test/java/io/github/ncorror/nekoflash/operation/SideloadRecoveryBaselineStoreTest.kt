package io.github.ncorror.nekoflash.operation

import io.github.ncorror.nekoflash.adb.sideload.RecoveryEvidenceCorrelator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SideloadRecoveryBaselineStoreTest {
    @Test
    fun `matching baseline requires same device and capture before pending start`() {
        val persistence = FakePersistence()
        val store = SideloadRecoveryBaselineStore(persistence)
        val record = record(device = "vayu", capturedAt = 1_000L)
        assertTrue(store.record(record))

        assertEquals(record, store.matchingFor("VAYU", 1_001L))
        assertNull(store.matchingFor("onyx", 1_001L))
        assertNull(store.matchingFor("vayu", 999L))
    }

    @Test
    fun `latest recovery baseline intentionally replaces older one`() {
        val persistence = FakePersistence()
        val store = SideloadRecoveryBaselineStore(persistence)
        val first = record(device = "vayu", capturedAt = 1_000L, hash = "a".repeat(64))
        val second = record(device = "vayu", capturedAt = 2_000L, hash = "b".repeat(64))

        assertTrue(store.record(first))
        assertTrue(store.record(second))
        assertEquals(second, store.current())
    }

    @Test
    fun `baseline clears only on exact match`() {
        val persistence = FakePersistence()
        val store = SideloadRecoveryBaselineStore(persistence)
        val expected = record(device = "vayu", capturedAt = 1_000L)
        val different = expected.copy(capturedAtEpochMs = 2_000L)
        store.record(expected)

        assertTrue(!store.clearIfMatches(different))
        assertEquals(expected, store.current())
        assertTrue(store.clearIfMatches(expected))
        assertNull(store.current())
    }

    private fun record(
        device: String,
        capturedAt: Long,
        hash: String = "a".repeat(64),
    ) = SideloadRecoveryBaselineStore.Record(
        deviceCodename = device,
        path = RecoveryEvidenceCorrelator.PRIMARY_PATH,
        prefixCharacters = 42,
        prefixSha256 = hash,
        capturedAtEpochMs = capturedAt,
    )

    private class FakePersistence : SideloadRecoveryBaselineStore.Persistence {
        private var value: SideloadRecoveryBaselineStore.Record? = null
        override fun read(): SideloadRecoveryBaselineStore.Record? = value
        override fun write(record: SideloadRecoveryBaselineStore.Record): Boolean {
            value = record
            return true
        }
        override fun clear(): Boolean {
            value = null
            return true
        }
    }
}
