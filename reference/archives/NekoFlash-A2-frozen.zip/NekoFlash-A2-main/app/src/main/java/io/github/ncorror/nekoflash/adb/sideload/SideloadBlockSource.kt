package io.github.ncorror.nekoflash.adb.sideload

/** Random-access payload contract required by the request-driven sideload-host protocol. */
internal interface SideloadBlockSource {
    val sizeBytes: Long

    /** Returns exactly [length] bytes beginning at [offset], or throws on local source failure. */
    fun readAt(offset: Long, length: Int): ByteArray
}
