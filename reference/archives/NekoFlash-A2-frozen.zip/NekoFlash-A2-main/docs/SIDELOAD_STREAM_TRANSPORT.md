# ADB Sideload request-driven transport

Original base contract: `8b73e3de843ac15cccb2dc434a1a5e1443fd8ba8`.

The request-driven `sideload-host:<size>:65536` transport remains the wire foundation. Its result and
cancellation semantics were tightened after hardware validation; see
`docs/SIDELOAD_SAFETY_BOUNDARY.md`.

## Wire invariants

- Sideload starts only on an already-connected ADB peer classified as `SIDELOAD`.
- The service OPEN is exactly `sideload-host:<payloadBytes>:65536\0`.
- All inbound ADB packets continue through the existing single-reader `AdbPacketDispatcher`.
- Recovery `WRTE` block requests are ACKed before random-access payload I/O is performed.
- Block offsets and final partial-block lengths are bounded against the selected payload size.
- Every host `WRTE` payload must receive the matching stream `OKAY` before that request contributes
  to acknowledged traffic.
- Recovery may request the same block repeatedly. Duplicate requests count in cumulative
  `servedBytes` diagnostics but not in unique progress/coverage.
- `-1` sends an empty host `WRTE` and remains non-terminal until `DONEDONE` or close.
- `DONEDONE` remains host-transfer completion only and still requires the independent Recovery
  verifier.
- The first non-empty payload WRTE is an explicit mutation boundary. Normal cancellation exists only
  before it.
- Any ambiguous close/failure after that boundary requires Recovery verification, even below 95%
  unique coverage.
- The historical >=95% near-complete close distinction is computed from unique acknowledged bytes.
- A retired Sideload transport generation is not reopened until a real physical detach/attach.
- There is no hidden automatic retry/reopen inside `AdbUsbTransport`.

## Verification

Unit tests cover exact service construction, request ACK ordering, 64 KiB addressing, final partial
blocks, `-1`, `DONEDONE`, duplicate-block accounting, unique coverage, pre-payload cancellation,
post-payload cancellation rejection, stale packet isolation, and post-mutation interruption
classification.
