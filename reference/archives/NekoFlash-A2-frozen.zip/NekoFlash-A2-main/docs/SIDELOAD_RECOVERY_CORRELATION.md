# ADB Sideload Recovery evidence correlation

## Why this slice exists

`DONEDONE`, 100% host transfer and a readable Recovery log are not install success by themselves.
A Recovery log may contain results from an older operation. NekoFlash therefore must not resolve a
pending Sideload from a line that merely *looks* current.

## Pre-Sideload baseline

When NekoFlash is connected to normal ADB `RECOVERY` and there is no unresolved Sideload result, it
reads the existing fixed Recovery evidence whitelist and captures a fingerprint of
`/tmp/recovery.log`:

- `ro.product.device` codename from the existing read-only identity probe;
- normalized character count of `/tmp/recovery.log`;
- SHA-256 of that exact normalized prefix;
- capture time.

The log text itself is not persisted. Only the fingerprint is stored.

## Post-Sideload correlation

After Sideload ends as `VERIFICATION_PENDING` and a fresh ADB `RECOVERY` generation reconnects,
NekoFlash accepts install evidence only when:

1. the current `ro.product.device` matches the baseline device;
2. the baseline was captured no later than the pending operation start;
3. `/tmp/recovery.log` is at least as long as the captured prefix;
4. SHA-256 of the current log prefix exactly matches the captured baseline SHA-256;
5. the appended text contains a recognized ADB Sideload session-start marker.

Only the latest recognized Sideload session inside text appended after that verified prefix is passed to
`RecoveryInstallVerifier`. Historical fallback files and unrelated post-baseline Recovery actions are
still diagnostic material but are not allowed to manufacture a verdict for the correlated path.

If the log was rotated, truncated, rewritten, the baseline is missing, or no new text was appended,
the result stays `VERIFICATION_PENDING`.

## UNKNOWN diagnostics

A bounded tail excerpt is recorded in diagnostics when correlation cannot produce an eligible source
or when the correlated delta has no recognized verdict. The excerpt is diagnostic only and never
changes `UNKNOWN` into success/failure.

## Hardware gate

The next hardware proof on a stable reference device must show:

1. normal Recovery connection -> `ADB_SIDELOAD_RECOVERY_BASELINE_CAPTURED`;
2. Sideload payload SHA-256 and mutation boundary;
3. transfer terminal -> durable `VERIFICATION_PENDING`;
4. physical reconnect -> new ADB `RECOVERY` generation;
5. exact baseline prefix correlation;
6. only appended `/tmp/recovery.log` text enters the verifier;
7. explicit current-session evidence resolves `SUCCEEDED` or `FAILED`, otherwise state remains pending.
