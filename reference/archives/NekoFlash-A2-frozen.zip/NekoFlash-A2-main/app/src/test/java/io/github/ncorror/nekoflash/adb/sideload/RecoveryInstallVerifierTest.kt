package io.github.ncorror.nekoflash.adb.sideload

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RecoveryInstallVerifierTest {
    @Test
    fun `DONEDONE alone never proves install success`() {
        val result = RecoveryInstallVerifier.evaluate(
            listOf(
                RecoveryInstallVerifier.LogSource(
                    "/tmp/recovery.log",
                    "Starting ADB sideload\nDONEDONE\n",
                ),
            ),
        )
        assertEquals(RecoveryInstallVerifier.Verdict.UNKNOWN, result.verdict)
    }

    @Test
    fun `explicit install from ADB status maps to final verdict`() {
        val success = RecoveryInstallVerifier.evaluate(
            listOf(
                RecoveryInstallVerifier.LogSource(
                    "/tmp/recovery.log",
                    "Starting ADB sideload\nInstall from ADB complete (status: 0)\n",
                ),
            ),
        )
        assertEquals(RecoveryInstallVerifier.Verdict.SUCCESS, success.verdict)

        val failed = RecoveryInstallVerifier.evaluate(
            listOf(
                RecoveryInstallVerifier.LogSource(
                    "/tmp/recovery.log",
                    "Starting ADB sideload\nInstall from ADB complete (status: 1)\n",
                ),
            ),
        )
        assertEquals(RecoveryInstallVerifier.Verdict.FAILED, failed.verdict)
    }

    @Test
    fun `latest recognized session wins over older result in the same log`() {
        val result = RecoveryInstallVerifier.evaluate(
            listOf(
                RecoveryInstallVerifier.LogSource(
                    "/tmp/recovery.log",
                    """
                    Starting ADB sideload
                    Install completed successfully
                    Starting ADB sideload
                    Installation aborted
                    """.trimIndent(),
                ),
            ),
        )
        assertEquals(RecoveryInstallVerifier.Verdict.FAILED, result.verdict)
    }

    @Test
    fun `current recovery log has priority over historical fallback`() {
        val result = RecoveryInstallVerifier.evaluate(
            listOf(
                RecoveryInstallVerifier.LogSource(
                    "/cache/recovery/last_install",
                    "Starting ADB sideload\nInstall completed successfully\n",
                ),
                RecoveryInstallVerifier.LogSource(
                    "/tmp/recovery.log",
                    "Starting ADB sideload\nInstallation aborted\n",
                ),
            ),
        )
        assertEquals(RecoveryInstallVerifier.Verdict.FAILED, result.verdict)
        assertEquals("/tmp/recovery.log", result.source)
    }

    @Test
    fun `operation end status is accepted only inside a recognized sideload session`() {
        val unrelated = RecoveryInstallVerifier.evaluate(
            listOf(
                RecoveryInstallVerifier.LogSource(
                    "/tmp/recovery.log",
                    "I:operation_end - status=0\n",
                ),
            ),
        )
        assertEquals(RecoveryInstallVerifier.Verdict.UNKNOWN, unrelated.verdict)

        val sideload = RecoveryInstallVerifier.evaluate(
            listOf(
                RecoveryInstallVerifier.LogSource(
                    "/tmp/recovery.log",
                    "Starting ADB sideload\nI:operation_end - status=0\n",
                ),
            ),
        )
        assertEquals(RecoveryInstallVerifier.Verdict.SUCCESS, sideload.verdict)
        assertTrue(sideload.evidence.orEmpty().contains("operation_end"))
    }

    @Test
    fun `missing logs remain unknown`() {
        val result = RecoveryInstallVerifier.evaluate(emptyList())
        assertEquals(RecoveryInstallVerifier.Verdict.UNKNOWN, result.verdict)
    }
}
