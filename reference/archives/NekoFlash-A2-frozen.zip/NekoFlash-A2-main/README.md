# NekoFlash A2

Clean implementation of NekoFlash using Architecture A2 while preserving hardware-proven USB,
ADB, Fastboot, Sideload, Mi Unlock, and device-operation behavior from the existing application.

## Current direction

A2 is moving from narrow migration slices to capability-complete protocol engines without
app-side command allowlists or arbitrary migration budgets. Real protocol/USB invariants remain:
one coherent Fastboot transaction lane per session, correct ADB stream flow control, explicit
transport ownership, and correct native USB lifecycle.

The current Fastboot foundation uses one transaction engine for qualification, diagnostics,
`getvar:all`, and future DATA-backed operations. `INFO`/`TEXT` refresh inactivity, `OKAY`/`FAIL`
complete a command, and `DATA` is represented explicitly for the next transfer phase. The old
24-query metadata cap and duplicate transport-local parser/inventory/planner paths are removed.

ADB currently still exposes the existing identity-probe slice; generic ADB service/stream work is
a later refactor.

## Verification status

Base repository checkpoint before the current Fastboot refactor:

`f23c9d2bcf9750dc2c383ca2008f49c1717232a7` — `add operation stage and result observation`

Recorded checkpoint evidence: 196/196 unit tests passed, lint 0 errors with 4 known warnings, and
`assembleDebug` passed. Exact-build hardware evidence confirmed the 6D2 operation failure path on
`marble` and `vayu`; an exact-build `SUCCEEDED` observation was not recorded.

The Fastboot transaction-foundation patch has local model/unit/fake-USB verification, but still
requires repository-wide Gradle CI and exact hardware validation after application. It must not be
called CI-verified or hardware-verified before those checks are recorded.

## Documentation

- `docs/KNOWN_USB_DEVICE_QUIRKS.md` — device-specific USB exceptions and validation policy; POCO F7 /
  Redmi Turbo 4 Pro (`onyx`) is explicitly recorded as a known unstable USB stress patient rather
  than a reference pass/fail device.
- `docs/FASTBOOT_TRANSACTION_ENGINE.md` — current Fastboot architecture and validation boundary.
- `docs/DEVELOPMENT_CHECKPOINT_TEMPORARY.md` — active recovery/development state.
- staged documents such as `docs/FASTBOOT_TRANSPORT_READ_ONLY.md` are historical verification
  records; their old staged restrictions are not current architecture policy.
