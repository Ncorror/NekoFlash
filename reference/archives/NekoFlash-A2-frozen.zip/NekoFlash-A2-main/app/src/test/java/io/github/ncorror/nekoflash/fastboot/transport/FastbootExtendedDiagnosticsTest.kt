package io.github.ncorror.nekoflash.fastboot.transport

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FastbootExtendedDiagnosticsTest {
    @Test
    fun `extended diagnostic recipe keeps expected order`() {
        assertEquals(
            listOf(
                "getvar:slot-suffix",
                "getvar:secure",
                "getvar:serialno",
                "getvar:version-bootloader",
                "getvar:anti",
                "getvar:is-userspace",
                "getvar:super-partition-name",
                "getvar:snapshot-update-status",
                "getvar:max-fetch-size",
            ),
            FastbootExtendedDiagnosticsPlan.fixedCommandOrderWithoutFallback,
        )
    }

    @Test
    fun `extended getvars use the common query timing model`() {
        val variables = FastbootExtendedDiagnosticsPlan.beforeAnti +
            FastbootExtendedDiagnosticsPlan.antiPrimary +
            FastbootExtendedDiagnosticsPlan.afterAnti +
            FastbootExtendedDiagnosticsPlan.antiFallback
        assertTrue(
            variables.all {
                it.writeTimeoutMs == FastbootCoreDiagnosticsPlan.GETVAR_WRITE_TIMEOUT_MS &&
                    it.inactivityTimeoutMs == FastbootCoreDiagnosticsPlan.GETVAR_INACTIVITY_TIMEOUT_MS
            },
        )
    }

    @Test
    fun `antirollback fallback is used only when anti is unreported`() {
        assertTrue(FastbootExtendedDiagnosticsPlan.shouldQueryAntiRollback(null))
        assertTrue(FastbootExtendedDiagnosticsPlan.shouldQueryAntiRollback("  "))
        assertFalse(FastbootExtendedDiagnosticsPlan.shouldQueryAntiRollback("1"))
    }

    @Test
    fun `antirollback fallback command remains explicit`() {
        assertEquals("getvar:antirollback", FastbootExtendedDiagnosticsPlan.antiFallback.command)
    }

    @Test
    fun `serial query is marked sensitive and redacted from events`() {
        val serial = FastbootExtendedDiagnosticsPlan.beforeAnti.single { it.name == "serialno" }
        assertTrue(serial.sensitive)
        assertEquals("<redacted>", serial.valueForEvent("ABC123"))
        assertEquals("<redacted>", serial.payloadForEvent("serialno: ABC123"))
    }

    @Test
    fun `non sensitive values remain observable`() {
        val secure = FastbootExtendedDiagnosticsPlan.beforeAnti.single { it.name == "secure" }
        assertEquals("yes", secure.valueForEvent("yes"))
        assertEquals("secure: yes", secure.payloadForEvent("secure: yes"))
    }

    @Test
    fun `max fetch size reuses the common fastboot size parser`() {
        assertEquals(805_306_368L, FastbootCoreDiagnosticsPlan.parseFastbootSize("805306368"))
        assertEquals(0x30000000L, FastbootCoreDiagnosticsPlan.parseFastbootSize("0x30000000"))
    }
}
