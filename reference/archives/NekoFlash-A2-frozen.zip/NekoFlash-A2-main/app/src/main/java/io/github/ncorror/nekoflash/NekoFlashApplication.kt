package io.github.ncorror.nekoflash

import android.app.Application
import io.github.ncorror.nekoflash.entry.EntrySessionGate
import io.github.ncorror.nekoflash.entry.SharedPreferencesEntrySessionPersistence
import io.github.ncorror.nekoflash.operation.OperationCoordinator
import io.github.ncorror.nekoflash.operation.QuickFlashPayloadStore
import io.github.ncorror.nekoflash.operation.SideloadPayloadStore
import io.github.ncorror.nekoflash.operation.SharedPreferencesSideloadRecoveryBaselinePersistence
import io.github.ncorror.nekoflash.operation.SideloadRecoveryBaselineStore
import io.github.ncorror.nekoflash.operation.SharedPreferencesSideloadVerificationPersistence
import io.github.ncorror.nekoflash.operation.SideloadVerificationStore
import io.github.ncorror.nekoflash.usb.session.UsbSessionCoordinator

class NekoFlashApplication : Application() {
    lateinit var entrySessionGate: EntrySessionGate
        private set

    lateinit var operationCoordinator: OperationCoordinator
        private set

    lateinit var quickFlashPayloadStore: QuickFlashPayloadStore
        private set

    lateinit var sideloadPayloadStore: SideloadPayloadStore
        private set

    private lateinit var sideloadRecoveryBaselineStore: SideloadRecoveryBaselineStore
        private set

    lateinit var sideloadVerificationStore: SideloadVerificationStore
        private set

    lateinit var usbSessionCoordinator: UsbSessionCoordinator
        private set

    override fun onCreate() {
        super.onCreate()
        entrySessionGate = EntrySessionGate(SharedPreferencesEntrySessionPersistence(this))
        operationCoordinator = OperationCoordinator()
        quickFlashPayloadStore = QuickFlashPayloadStore(contentResolver)
        sideloadPayloadStore = SideloadPayloadStore(contentResolver)
        sideloadRecoveryBaselineStore = SideloadRecoveryBaselineStore(
            SharedPreferencesSideloadRecoveryBaselinePersistence(this),
        )
        sideloadVerificationStore = SideloadVerificationStore(
            SharedPreferencesSideloadVerificationPersistence(this),
        )
        sideloadVerificationStore.currentPending()?.let(operationCoordinator::restoreVerificationPending)
        usbSessionCoordinator = UsbSessionCoordinator(
            this,
            operationCoordinator,
            sideloadRecoveryBaselineStore,
            sideloadVerificationStore,
        )
    }
}
