package io.github.ncorror.nekoflash.fastboot.transport

/** One Fastboot response frame decoded from the bulk IN endpoint. */
internal data class FastbootPacket(
    val type: String,
    val payload: String,
    val raw: String,
) {
    /** DATA carries a hexadecimal byte count. Unknown/invalid sizes stay unparsed. */
    fun dataSizeBytes(): Long? {
        if (type != "DATA") return null
        val token = payload.trim().removePrefix("0x").removePrefix("0X")
        if (token.isBlank()) return null
        return token.toLongOrNull(16)?.takeIf { it >= 0L }
    }
}

/** Wire decoding only; command policy belongs above the protocol layer. */
internal object FastbootPacketCodec {
    fun parse(bytes: ByteArray, length: Int = bytes.size): FastbootPacket {
        require(length in 0..bytes.size) { "length is outside byte array" }
        val raw = String(bytes, 0, length, Charsets.US_ASCII)
            .replace("\u0000", "")
            .trim()
        if (raw.length < 4) return FastbootPacket(type = "UNKNOWN", payload = raw, raw = raw)
        return FastbootPacket(
            type = raw.take(4),
            payload = raw.drop(4).trim(),
            raw = raw,
        )
    }
}

/**
 * State of the single synchronous transaction lane owned by one Fastboot USB session.
 * STALLED means a command was sent but no terminal response was observed; issuing a
 * second command on that same lane would lose protocol framing and therefore requires
 * an explicit reconnect/resynchronization first.
 */
internal enum class FastbootTransactionState {
    DISCONNECTED,
    IDLE,
    AWAITING_FINAL,
    AWAITING_DATA,
    SENDING_DATA,
    AWAITING_DATA_FINAL,
    STALLED,
    CLOSED,
}

/** Terminal observation from one command exchange. */
internal sealed interface FastbootTransactionResult {
    data class Completed(
        val finalType: String,
        val finalPayload: String,
    ) : FastbootTransactionResult

    data class DataRequested(
        val sizeBytes: Long?,
        val payload: String,
    ) : FastbootTransactionResult

    data class TimedOut(
        val inactivityMs: Long,
    ) : FastbootTransactionResult

    data class NotReady(
        val state: FastbootTransactionState,
    ) : FastbootTransactionResult

    data object Closed : FastbootTransactionResult
}


/** Result of continuing a command after the device has entered its DATA OUT phase. */
internal sealed interface FastbootDataContinuationResult {
    data class Completed(
        val finalType: String,
        val finalPayload: String,
        val bytesTransferred: Long,
        val mode: FastbootDataTransfer.Mode,
    ) : FastbootDataContinuationResult

    data class SizeMismatch(
        val expectedBytes: Long,
        val advertisedBytes: Long?,
    ) : FastbootDataContinuationResult

    data class TransferFailed(
        val message: String,
        val bytesTransferred: Long,
        val cancelled: Boolean,
        val mode: FastbootDataTransfer.Mode,
    ) : FastbootDataContinuationResult

    data class TimedOut(
        val inactivityMs: Long,
        val bytesTransferred: Long,
        val mode: FastbootDataTransfer.Mode,
    ) : FastbootDataContinuationResult

    data class NotReady(
        val state: FastbootTransactionState,
    ) : FastbootDataContinuationResult

    data object Closed : FastbootDataContinuationResult
}

/**
 * Inactivity budget used by Fastboot reads. Every received packet refreshes the budget,
 * so a long-running but active INFO/TEXT stream is not mistaken for a dead transaction.
 */
internal class FastbootInactivityBudget(
    private val timeoutMs: Long,
    startedAtNs: Long,
) {
    init {
        require(timeoutMs > 0L) { "timeoutMs must be positive" }
    }

    private var lastActivityNs: Long = startedAtNs

    fun markActivity(nowNs: Long) {
        if (nowNs > lastActivityNs) lastActivityNs = nowNs
    }

    fun remainingMs(nowNs: Long): Long {
        val elapsedNs = (nowNs - lastActivityNs).coerceAtLeast(0L)
        val elapsedMs = elapsedNs / 1_000_000L
        return (timeoutMs - elapsedMs).coerceAtLeast(0L)
    }
}

internal object FastbootTransactionTiming {
    const val HANDSHAKE_SETTLE_MS = 350L
    const val HANDSHAKE_WRITE_TIMEOUT_MS = 7_000
    const val HANDSHAKE_INACTIVITY_TIMEOUT_MS = 7_000
    const val READ_SLICE_MS = 900

    fun nextReadTimeoutMs(remainingMs: Long): Int =
        minOf(READ_SLICE_MS.toLong(), remainingMs.coerceAtLeast(1L)).toInt()
}

internal object FastbootGetVarAllRequest {
    const val COMMAND = "getvar:all"
    const val WRITE_TIMEOUT_MS = 10_000
    const val INACTIVITY_TIMEOUT_MS = 30_000
}

internal object FastbootGetVarValue {
    fun normalize(name: String, raw: String): String? {
        val cleaned = raw.trim().removePrefix("INFO").trim()
        val variants = listOf(name, name.replace('-', '_'))
        variants.forEach { variant ->
            val prefix = "$variant:"
            if (cleaned.startsWith(prefix, ignoreCase = true)) {
                return cleaned.substring(prefix.length).trim().ifBlank { null }
            }
        }
        return cleaned.substringAfter(':', cleaned).trim().ifBlank { null }
    }
}
