package io.github.ncorror.nekoflash.operation

import android.annotation.SuppressLint
import android.content.Context
import io.github.ncorror.nekoflash.adb.sideload.RecoveryEvidenceCorrelator

/** Durable fingerprint of /tmp/recovery.log captured before entering ADB Sideload. */
internal class SideloadRecoveryBaselineStore(
    private val persistence: Persistence,
) {
    data class Record(
        val deviceCodename: String,
        val path: String,
        val prefixCharacters: Int,
        val prefixSha256: String,
        val capturedAtEpochMs: Long,
    ) {
        init {
            require(deviceCodename.isNotBlank()) { "Recovery baseline device codename must not be blank" }
            require(path == RecoveryEvidenceCorrelator.PRIMARY_PATH) {
                "Recovery baseline must use ${RecoveryEvidenceCorrelator.PRIMARY_PATH}"
            }
            require(prefixCharacters >= 0) { "Recovery baseline prefix length must not be negative" }
            require(SHA256_REGEX.matches(prefixSha256)) { "Recovery baseline SHA-256 must be lowercase hex" }
            require(capturedAtEpochMs > 0L) { "Recovery baseline capture time must be positive" }
        }

        fun verifierBaseline(): RecoveryEvidenceCorrelator.Baseline = RecoveryEvidenceCorrelator.Baseline(
            path = path,
            prefixCharacters = prefixCharacters,
            prefixSha256 = prefixSha256,
        )
    }

    interface Persistence {
        fun read(): Record?
        fun write(record: Record): Boolean
        fun clear(): Boolean
    }

    private val lock = Any()

    fun current(): Record? = synchronized(lock) { persistence.read() }

    /** Latest no-pending Recovery connection intentionally replaces an older baseline. */
    fun record(record: Record): Boolean = synchronized(lock) { persistence.write(record) }

    /** Returns only a baseline captured for this device no later than the pending operation start. */
    fun matchingFor(deviceCodename: String, pendingStartedAtEpochMs: Long): Record? = synchronized(lock) {
        val current = persistence.read() ?: return@synchronized null
        current.takeIf {
            it.deviceCodename.equals(deviceCodename.trim(), ignoreCase = true) &&
                it.capturedAtEpochMs <= pendingStartedAtEpochMs
        }
    }

    fun clearIfMatches(expected: Record): Boolean = synchronized(lock) {
        val current = persistence.read() ?: return@synchronized true
        if (current != expected) return@synchronized false
        persistence.clear()
    }

    private companion object {
        val SHA256_REGEX = Regex("^[0-9a-f]{64}$")
    }
}

internal class SharedPreferencesSideloadRecoveryBaselinePersistence(context: Context) :
    SideloadRecoveryBaselineStore.Persistence {
    private val preferences = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    override fun read(): SideloadRecoveryBaselineStore.Record? {
        if (!preferences.getBoolean(KEY_PRESENT, false)) return null
        return runCatching {
            SideloadRecoveryBaselineStore.Record(
                deviceCodename = preferences.getString(KEY_DEVICE_CODENAME, null).orEmpty(),
                path = preferences.getString(KEY_PATH, null).orEmpty(),
                prefixCharacters = preferences.getInt(KEY_PREFIX_CHARACTERS, -1),
                prefixSha256 = preferences.getString(KEY_PREFIX_SHA256, null).orEmpty(),
                capturedAtEpochMs = preferences.getLong(KEY_CAPTURED_AT, 0L),
            )
        }.getOrNull()
    }

    @SuppressLint("ApplySharedPref")
    @Suppress("UseKtx")
    override fun write(record: SideloadRecoveryBaselineStore.Record): Boolean =
        preferences.edit()
            .putBoolean(KEY_PRESENT, true)
            .putString(KEY_DEVICE_CODENAME, record.deviceCodename.trim())
            .putString(KEY_PATH, record.path)
            .putInt(KEY_PREFIX_CHARACTERS, record.prefixCharacters)
            .putString(KEY_PREFIX_SHA256, record.prefixSha256)
            .putLong(KEY_CAPTURED_AT, record.capturedAtEpochMs)
            .commit()

    @SuppressLint("ApplySharedPref")
    @Suppress("UseKtx")
    override fun clear(): Boolean = preferences.edit().clear().commit()

    private companion object {
        const val PREFS_NAME = "nekoflash_sideload_recovery_baseline"
        const val KEY_PRESENT = "present"
        const val KEY_DEVICE_CODENAME = "device_codename"
        const val KEY_PATH = "path"
        const val KEY_PREFIX_CHARACTERS = "prefix_characters"
        const val KEY_PREFIX_SHA256 = "prefix_sha256"
        const val KEY_CAPTURED_AT = "captured_at_epoch_ms"
    }
}
