package io.github.ncorror.nekoflash.operation

import android.content.ContentResolver
import android.database.Cursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.system.Os
import android.system.OsConstants
import io.github.ncorror.nekoflash.adb.sideload.SideloadBlockSource
import java.security.MessageDigest

/**
 * Application-scoped owner of the single SAF package selected for ADB Sideload.
 *
 * The descriptor stays open outside Activity lifetime and is validated for positional reads before
 * admission. The package SHA-256 is computed locally from the exact selected bytes, so provenance
 * does not depend on a recovery/project publishing its own checksum.
 */
class SideloadPayloadStore(
    private val contentResolver: ContentResolver,
) {
    data class Snapshot(
        val displayName: String,
        val sizeBytes: Long,
        val sha256: String,
    )

    internal class Payload internal constructor(
        val displayName: String,
        override val sizeBytes: Long,
        val sha256: String,
        descriptor: ParcelFileDescriptor,
    ) : SideloadBlockSource, AutoCloseable {
        private val lock = Any()
        private var descriptor: ParcelFileDescriptor? = descriptor

        override fun readAt(offset: Long, length: Int): ByteArray = synchronized(lock) {
            val owned = descriptor ?: error("ADB Sideload payload descriptor is no longer available")
            require(offset >= 0L) { "Sideload read offset must be non-negative" }
            require(length >= 0) { "Sideload read length must be non-negative" }
            val end = offset + length.toLong()
            require(end >= offset && end <= sizeBytes) {
                "Sideload read exceeds payload: offset=$offset length=$length size=$sizeBytes"
            }
            if (length == 0) return@synchronized ByteArray(0)

            val output = ByteArray(length)
            var filled = 0
            while (filled < length) {
                val count = Os.pread(
                    owned.fileDescriptor,
                    output,
                    filled,
                    length - filled,
                    offset + filled.toLong(),
                )
                check(count > 0) {
                    "Unexpected EOF while reading sideload payload at offset=${offset + filled}"
                }
                filled += count
            }
            output
        }

        override fun close() {
            val owned = synchronized(lock) {
                descriptor.also { descriptor = null }
            }
            runCatching { owned?.close() }
        }
    }

    private val lock = Any()
    private var selected: Payload? = null
    private var selectionGeneration = 0L
    private var listenerGeneration = 0L
    private var snapshotListener: ((Snapshot?) -> Unit)? = null

    fun currentSnapshot(): Snapshot? = synchronized(lock) { selected?.snapshot() }

    fun replaceSnapshotListener(listener: (Snapshot?) -> Unit): Long {
        val generation: Long
        val snapshot: Snapshot?
        synchronized(lock) {
            generation = ++listenerGeneration
            snapshotListener = listener
            snapshot = selected?.snapshot()
        }
        listener(snapshot)
        return generation
    }

    fun clearSnapshotListener(generation: Long) {
        synchronized(lock) {
            if (listenerGeneration == generation) snapshotListener = null
        }
    }

    /**
     * Replaces the current package only after size, random access and SHA-256 are all confirmed.
     * This is expected to run on a background executor because hashing reads the entire package.
     */
    fun replaceFromUri(uri: Uri): Result<Snapshot> = runCatching {
        require(uri.scheme == ContentResolver.SCHEME_CONTENT) { "Only content:// documents are supported" }
        val generation = synchronized(lock) { ++selectionGeneration }
        val descriptor = contentResolver.openFileDescriptor(uri, "r")
            ?: error("Document provider returned no file descriptor")
        try {
            val metadata = queryMetadata(uri)
            val statSize = runCatching { descriptor.statSize }.getOrDefault(-1L)
            val size = statSize.takeIf { it > 0L }
                ?: metadata.sizeBytes?.takeIf { it > 0L }
                ?: error("Selected package does not expose a stable file size")
            val displayName = metadata.displayName
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
                ?.take(MAX_DISPLAY_NAME_CHARS)
                ?: DEFAULT_DISPLAY_NAME

            verifyRandomAccess(descriptor, size)
            val sha256 = computeSha256(descriptor, size)
            val payload = Payload(
                displayName = displayName,
                sizeBytes = size,
                sha256 = sha256,
                descriptor = descriptor,
            )
            val snapshot = payload.snapshot()
            val previous: Payload?
            val listener: ((Snapshot?) -> Unit)?
            synchronized(lock) {
                check(generation == selectionGeneration) { "Package selection was superseded or cleared" }
                previous = selected
                selected = payload
                listener = snapshotListener
            }
            previous?.close()
            listener?.invoke(snapshot)
            snapshot
        } catch (error: Throwable) {
            runCatching { descriptor.close() }
            throw error
        }
    }

    /** Transfers ownership to one admitted Sideload operation. */
    internal fun take(): Payload? {
        val payload: Payload?
        val listener: ((Snapshot?) -> Unit)?
        synchronized(lock) {
            selectionGeneration++
            payload = selected
            selected = null
            listener = snapshotListener
        }
        listener?.invoke(null)
        return payload
    }

    fun clear() {
        val previous: Payload?
        val listener: ((Snapshot?) -> Unit)?
        synchronized(lock) {
            selectionGeneration++
            previous = selected
            selected = null
            listener = snapshotListener
        }
        previous?.close()
        listener?.invoke(null)
    }

    private fun Payload.snapshot(): Snapshot = Snapshot(
        displayName = displayName,
        sizeBytes = sizeBytes,
        sha256 = sha256,
    )

    private data class Metadata(
        val displayName: String?,
        val sizeBytes: Long?,
    )

    private fun queryMetadata(uri: Uri): Metadata {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null,
            )
            val found = cursor ?: return Metadata(null, null)
            if (!found.moveToFirst()) return Metadata(null, null)
            val nameIndex = found.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = found.getColumnIndex(OpenableColumns.SIZE)
            Metadata(
                displayName = if (nameIndex >= 0 && !found.isNull(nameIndex)) found.getString(nameIndex) else null,
                sizeBytes = if (sizeIndex >= 0 && !found.isNull(sizeIndex)) found.getLong(sizeIndex) else null,
            )
        } catch (_: RuntimeException) {
            Metadata(null, null)
        } finally {
            runCatching { cursor?.close() }
        }
    }

    private fun verifyRandomAccess(descriptor: ParcelFileDescriptor, sizeBytes: Long) {
        require(sizeBytes > 0L)
        val probe = ByteArray(1)
        val count = Os.pread(descriptor.fileDescriptor, probe, 0, 1, 0L)
        check(count == 1) { "Selected package is not readable with positional I/O" }
    }

    private fun computeSha256(descriptor: ParcelFileDescriptor, expectedBytes: Long): String {
        val digest = MessageDigest.getInstance("SHA-256")
        var total = 0L
        val duplicate = ParcelFileDescriptor.dup(descriptor.fileDescriptor)
        ParcelFileDescriptor.AutoCloseInputStream(duplicate).use { input ->
            Os.lseek(duplicate.fileDescriptor, 0L, OsConstants.SEEK_SET)
            val buffer = ByteArray(HASH_BUFFER_BYTES)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count == 0) continue
                digest.update(buffer, 0, count)
                total += count.toLong()
                check(total <= expectedBytes) { "Selected package grew while SHA-256 was being computed" }
            }
        }
        check(total == expectedBytes) {
            "Selected package size changed while SHA-256 was being computed: expected=$expectedBytes actual=$total"
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }

    private companion object {
        const val MAX_DISPLAY_NAME_CHARS = 256
        const val DEFAULT_DISPLAY_NAME = "package.zip"
        const val HASH_BUFFER_BYTES = 256 * 1024
    }
}
