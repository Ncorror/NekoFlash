# Known USB device quirks

This document records hardware/device-specific behavior that must not be confused with a generic
NekoFlash transport regression. It separates **project field evidence** from **public external
corroboration** so that a difficult device does not silently redefine the acceptance baseline for
all other hardware.

## POCO F7 / Redmi Turbo 4 Pro (`onyx`)

> [!CAUTION]
> **POCO F7 / Redmi Turbo 4 Pro (`onyx`) — KNOWN USB-UNSTABLE PATIENT. DO NOT USE THIS DEVICE AS A
> REFERENCE PASS/FAIL DEVICE FOR NEKOFLASH USB, ADB, SIDELOAD, OR FASTBOOT ACCEPTANCE.**
>
> **Для NekoFlash этот аппарат зафиксирован как известный проблемный USB-пациент. Его нестабильное
> поведение нельзя использовать как эталонный провал транспорта на других устройствах.**

### Project field status

Status: **KNOWN PROBLEMATIC / EXCLUDED FROM REFERENCE HARDWARE GATES**.

Project testing has repeatedly observed physical USB detach/re-enumeration on `onyx`, including
very short ADB/Sideload connection lifetimes. This behavior existed in the legacy NekoFlash line
and remained observable in the Architecture A2 line after extensive transport changes.

Current captured A2 evidence:

- diagnostics archive: `NekoFlash-A2-diagnostics-20260826-191444Z.zip`;
- peer identity repeatedly reported `ro.product.device=onyx` and
  `ro.product.model=RedmiTurbo4Pro`;
- the approximately 10 minute capture contains `23` `USB_ATTACHED` events, `56` `USB_DETACHED`
  events, and `22` successful `ADB_CONNECTED` handshakes;
- several physical connection windows lasted only a few seconds, including approximately `4.54 s`,
  `6.35 s`, `6.39 s`, `3.16 s`, `1.20 s`, and `1.11 s` before a matching current-device detach;
- when the link remained alive long enough, request-driven ADB Sideload made normal forward
  progress, which is evidence that the ADB/Sideload protocol path itself can operate on `onyx`;
- repeated detach/reconnect behavior therefore remains a device/USB-stack/host compatibility
  concern, not proof by itself of an NekoFlash protocol failure.

Historical operator record, accumulated during legacy development:

- the same `onyx` instability was seen before the A2 rewrite;
- the project spent roughly a month trying code-side mitigations and transport variations without
  eliminating the underlying disconnect/reconnect pattern;
- multiple other test devices used with legacy NekoFlash behaved normally while this model remained
  the outlier;
- **among host phones tested by this project so far, Xiaomi Mi 8 is the only known model that has
  repeatedly completed flashing reliably against this specific problematic `onyx` patient when
  other tested hosts could not.**

The Mi 8 observation is an internal empirical compatibility result. It is **not** a claim that every
Mi 8 will always work, that every other host will fail, or that Xiaomi specifies the Mi 8 as a
special-purpose host.

### Public external corroboration

Public sources do **not** prove the exact root cause of the project's 1-6 second detach/reconnect
pattern. They do, however, independently show that the `onyx` recovery/USB ecosystem has had
real USB/OTG maturity problems across different custom-recovery builds:

1. Xiaomi's official POCO F7 FAQ states that the device supports USB Type-C and OTG, including
   external USB storage. Therefore a persistent detach/re-enumeration loop is not normal advertised
   OTG behavior.
2. An early public TWRP build for POCO F7 / Redmi Turbo 4 Pro explicitly listed **ADB Sideload as
   working while USB OTG was broken**.
3. A later OrangeFox 14.1 `onyx` release still listed **OTG still not working** as a known bug.
4. Later OrangeFox R12-era reports/changelogs then described USB OTG support as added/fixed, and at
   least one field report described successful backup to external storage. This variation across
   recovery revisions is consistent with a recovery/kernel/device-tree-sensitive USB stack.

These external reports corroborate that USB/OTG behavior on `onyx` has been recovery-version
sensitive. They do **not** establish whether the NekoFlash field failure is caused by the phone's
physical Type-C port, USB PHY, power/role negotiation, device firmware, recovery gadget driver,
host controller, cable, or an interaction among them.

### NekoFlash validation policy

For release and protocol acceptance:

- do not use `onyx` as the sole or primary hardware gate;
- a failure observed only on `onyx` must be reproduced on a stable reference device before being
  classified as a generic NekoFlash transport regression;
- successful behavior on a stable reference device remains the acceptance baseline;
- `onyx` may be used only as an optional **stress/failure-tolerance patient** when the test is
  explicitly designed for unstable detach/re-enumeration;
- do not keep changing protocol semantics only to hide `onyx` physical detach events;
- each physical detach invalidates the current transport generation; a later attach is a new USB
  generation and must be treated as such;
- destructive operations must remain fail-closed when the link disappears, regardless of whether
  the root cause is NekoFlash, recovery, cable, host, or device hardware.

### Engineering history note

The long `onyx` investigation was still valuable. Its repeated failures exposed weak assumptions in
USB reconnect, generation ownership, timeout handling, stale-session rejection, and Fastboot
recovery behavior. Hardening performed while chasing this outlier materially improved the general
NekoFlash transport design. In that sense, the problematic F7 patient contributed to the current
much stronger Fastboot implementation even though its own underlying USB instability was not fixed
by application code.

### Public references

- Xiaomi POCO F7 FAQ (official): https://www.mi.com/pl/support/faq/details/KA-909695/
- POCO F7 / Redmi Turbo 4 Pro public update channel, early TWRP note (`ADB sideload working`,
  `Usb Otg broken`): https://t.me/s/PocoF7_Global_Updates?before=389&q=%23PocoF7
- POCO F7 / Redmi Turbo 4 Pro public update channel, OrangeFox note (`OTG still not working`):
  https://t.me/s/PocoF7_Global_Updates/240
- 4PDA `onyx` recovery thread, initial TWRP OTG-known-issue and later recovery builds:
  https://4pda.to/forum/index.php?showtopic=1107761
- 4PDA later OrangeFox R12 discussion describing added/fixed USB OTG support:
  https://4pda.to/forum/index.php?showtopic=1107761&st=3720
- Public `onyx` recovery device tree: https://github.com/onyx-oss/android_device_xiaomi_onyx_recovery

## Evidence discipline

A device-specific quirk entry must distinguish:

- **captured project evidence** — diagnostics/logs produced by NekoFlash;
- **operator history** — repeated field observations that may predate the current diagnostics
  format;
- **external corroboration** — third-party/public reports that show related symptoms or subsystem
  instability but do not prove NekoFlash's exact root cause.

Do not upgrade correlation into causation. In particular, the `onyx` record intentionally does not
claim a proven physical-port defect even though hardware/firmware-level causes remain plausible.
