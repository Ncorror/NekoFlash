# ADB Sideload Recovery verification persistence

This slice closes the semantic gap between host-transfer completion and a verified Recovery install
result without adding a generic shell-command surface.

## Durable pending identity

When ADB Sideload reaches `DONEDONE` or the pinned near-complete close boundary, NekoFlash still does
not report install success. Before publishing `VERIFICATION_PENDING` in memory it durably records the
exact selected package identity: locally computed SHA-256, byte size, display name, operation
generation and transfer timestamps.

On process start the pending identity is restored into `OperationCoordinator`. While it remains
unresolved a new operation lease is rejected so another operation cannot overwrite the only pending
install verdict.

## Fresh Recovery connection

The Sideload peer itself is never used as install-result evidence. Verification is attempted only
after ADB reconnects with peer mode `RECOVERY`. The existing fixed `ro.product.device` probe remains
read-only. After it, NekoFlash reads only this closed whitelist of Recovery paths:

- `/tmp/recovery.log`
- `/cache/recovery/last_install`
- `/cache/recovery/last_log`
- `/tmp/install.log`

Each path maps to an exact built-in `shell:cat ...` service and a bounded output cap. There is no API
that accepts caller-supplied shell text or file paths.

The collected sources are passed to `RecoveryInstallVerifier`, which prioritizes the current
`/tmp/recovery.log`, isolates the latest recognized install/Sideload session, and returns
`SUCCESS`, `FAILED`, or `UNKNOWN`.

- `SUCCESS` resolves the matching SHA-256 pending result to operation `SUCCEEDED`.
- `FAILED` resolves it to operation `FAILED`.
- `UNKNOWN`, unreadable logs, a stale transport, a wrong SHA-256, or persistence mismatch leave the
  result `VERIFICATION_PENDING`.

The durable pending record is cleared only after the matching in-memory result was successfully
resolved. A crash or storage failure therefore remains conservative and cannot manufacture install
success.

## Hardware gate after CI

Do not call this slice proven merely because unit tests pass. The next hardware gate must capture a
single diagnostic archive showing:

1. Sideload transfer terminal -> durable `VERIFICATION_PENDING`;
2. Sideload ADB generation closes/re-enumerates;
3. a later ADB `RECOVERY` generation connects;
4. fixed Recovery evidence reads occur, with no arbitrary shell service;
5. verifier identifies a source/evidence line for the current install;
6. operation resolves from `VERIFICATION_PENDING` to `SUCCEEDED` or `FAILED` only from that evidence;
7. locally computed package SHA-256 is identical across selection, pending persistence and final
   resolution.

## Correlated pre-Sideload baseline

Before entering ADB Sideload, a normal ADB `RECOVERY` connection now captures a durable fingerprint
of `/tmp/recovery.log` when no install result is pending. The fingerprint contains the Recovery device
codename, normalized prefix length, prefix SHA-256 and capture timestamp; the log text is not persisted.

After Sideload, verification is fail-closed unless the fresh `/tmp/recovery.log` still begins with the
exact captured prefix for the same `ro.product.device`. Only appended text is eligible for
`RecoveryInstallVerifier`. Log rotation, truncation, rewrite, a missing baseline, or no appended text
leave the operation `VERIFICATION_PENDING` and emit a bounded diagnostic excerpt instead of accepting
historical evidence.

See `SIDELOAD_RECOVERY_CORRELATION.md` for the exact correlation contract.
