# ADB Sideload contract foundation

This slice started Sideload migration after the Fastboot Quick Flash and Native USBFS cancellation
milestones were hardware-closed on `vayu`.

> **Hardware correction:** the first real Sideload campaign later proved that Recovery can request
> the same block repeatedly and can begin mutation after the first payload block. The original
> cumulative-served-byte interpretation below was superseded by
> `docs/SIDELOAD_SAFETY_BOUNDARY.md`.

## Original scope

Pure Kotlin only. No new USB writes, no sideload service OPEN, no file picker, and no hardware claim
were introduced by the foundation patch.

The legacy reference was `legacy2.zip`, specifically `AdbProtocol.sideloadZip(...)`,
`RecoveryInstallVerifier`, and the pending-verification behavior in `DeviceViewModel.runSideload(...)`.

## Current pinned invariants

- Sideload starts only with a connected ADB transport already classified as SIDELOAD.
- Empty payloads fail before protocol work.
- The request block size remains 65536 bytes.
- Cumulative `servedBytes` is diagnostic traffic only; unique acknowledged blocks drive coverage.
- A close before any payload block is an ordinary transport/protocol failure.
- Once the first payload block is attempted, any ambiguous close/failure requires Recovery
  verification regardless of percentage.
- The historical >=95% close distinction remains only as a near-complete label and is calculated
  from unique acknowledged bytes.
- `DONEDONE` means transfer complete only. It is never install success.
- Recovery verification is a separate SUCCESS / FAILED / UNKNOWN result.
- `/tmp/recovery.log` has priority over historical fallback logs.
- Only the latest recognized install/sideload session slice contributes the final evidence.
- Sideload-specific `operation_end status=N` is accepted only inside a recognized Sideload session.

## Current safety reference

For cancellation, mutation-boundary, unique progress and reconnect rules, the authoritative contract
is `docs/SIDELOAD_SAFETY_BOUNDARY.md`.
