# NekoFlash — Protocol & Safety Invariants

## 1. Главная граница

**Correctness protection не является capability restriction.**

NekoFlash защищает целостность transport/protocol state и честность результата. Он не защищает профессионального пользователя от доступа к валидным protocol capabilities.

## 2. Четыре класса решений

### A. Hard invariant
Примеры:
- malformed/truncated protocol frame;
- stale USB generation;
- потерян stream/transaction ownership;
- peer DATA length не соответствует договорённому payload;
- ambiguous mutating write;
- source изменился так, что exact byte promise больше нельзя доказать.

Действие: stop/fail/unknown. Override пользователем здесь недопустим, потому что нарушается техническая достоверность.

### B. Device authority
Примеры:
- locked bootloader;
- AVB/OEM restriction;
- ADB authorization отсутствует;
- Fastboot `FAIL`;
- Recovery не поддерживает service;
- vendor server отклоняет Mi Unlock.

Действие: показать реальный ответ/ограничение устройства. Не подменять его собственной authorization системой.

### C. Advisory
Примеры:
- `unlocked=unknown/no` перед guided flash;
- неизвестный `max-download-size`;
- неизвестный partition size;
- unusual/critical partition;
- низкая батарея;
- нестабильный device quirk;
- неизвестная slot topology.

Действие: warning/preflight/override. Не hidden deny.

### D. User intent
Примеры:
- erase userdata;
- flash critical partition;
- raw OEM command;
- destructive shell command.

Действие: в guided UI — один точный confirmation при необходимости. В raw console — команда остаётся доступной.

## 3. USB invariants

- Один physical transport owner на claimed interface/generation.
- Detach/re-enumeration инвалидирует generation.
- Stale endpoint/handle не переиспользуется.
- Shutdown/cancel должен иметь доказуемые semantics.
- Native async I/O после cancel должен drain/reap или явно poison backend.
- Silent backend switch посреди mutating operation запрещён.
- Retry после ambiguous write запрещён, пока нельзя доказать, что previous attempt не мутировал peer.

## 4. ADB invariants

- Один physical IN reader допустим и предпочтителен; logical streams multiplex/demultiplex отдельно.
- ADB packet header/payload framing проверяется строго.
- Packet чужого stream не считается автоматически stale.
- Per-stream IDs и lifecycle сохраняются корректно.
- Backpressure ограничен и наблюдаем.
- `shell,v2` channels/exit status не смешиваются.
- Feature negotiation влияет на выбранный typed client, но отсутствие feature не превращается в общий ban: используется корректный fallback, если он существует.

### Сохранить из A2 после hardware proof
Текущая inbound USB framing policy: payload, объявленный ADB header, должен завершиться в рамках одной receive operation; positive short read для такого frame считается incomplete и fail-closed, а не продолжается как обычный stream fragment. Этот конкретный invariant окончательно переносится только после PASS текущего `vayu` gate.

## 5. Fastboot invariants

- Transaction ownership один на конкретный Fastboot transport.
- Реальные peer statuses `INFO/TEXT/OKAY/FAIL/DATA` сохраняются без semantic подмены.
- DATA byte accounting точный.
- Для DATA OUT source не меняется во время передачи.
- Для DATA IN sink использует partial/commit semantics, когда возможно.
- Mid-DATA transport ambiguity после возможной mutation не ретраится автоматически.
- `max-download-size`, `partition-size`, `unlocked` — diagnostics/advisories, а не host authorization, кроме случая, когда конкретный wire request физически невозможно корректно представить.

## 6. Sideload invariants, доказанные A2

Сохранить как correctness contract:

1. `DONEDONE` / terminal transfer signal **не равен Recovery install success**.
2. После передачи outcome может оставаться `VERIFICATION_PENDING/UNKNOWN` до Recovery evidence.
3. Mutation boundary — первая попытка отправить payload block.
4. Обычный Cancel разрешён только до irreversible boundary.
5. После mutation transport close не превращается искусственно в `ABORTED`; результат может быть неизвестен.
6. Duplicate block requests не увеличивают unique progress.
7. Cumulative served traffic и unique coverage логируются раздельно.
8. Terminal/cancelled Sideload generation quarantined; требуется реальный detach/attach/new generation, когда это необходимо для корректной correlation.
9. Recovery evidence persistent across reconnect/process restart.
10. Correlation строится относительно pre-Sideload baseline и нового session evidence.
11. Local package SHA-256 доказывает выбранные local bytes, но не является автоматически Recovery-log correlation.

## 7. Cancellation model

`Cancel` не означает «отменить физически всё уже случившееся».

Outcome vocabulary:
- `Success` — завершение доказано;
- `Failed` — peer/device/protocol доказал failure;
- `Cancelled` — операция прекращена до boundary, где можно доказать отсутствие требуемой mutation;
- `Unknown` — mutation могла произойти, а final state доказать нельзя.

Unknown — профессионально честный результат, а не UX failure.

## 8. Что core никогда не должен делать

- `if (dangerous) reject` без protocol invariant;
- скрывать `FAIL` и возвращать generic local error без peer text;
- считать transport completion business success;
- возобновлять operation на новой generation без специально определённого recovery protocol;
- автоматически переповторять mutating request после неопределённого write;
- отдавать UI право «владеть» USB transaction lifetime.
