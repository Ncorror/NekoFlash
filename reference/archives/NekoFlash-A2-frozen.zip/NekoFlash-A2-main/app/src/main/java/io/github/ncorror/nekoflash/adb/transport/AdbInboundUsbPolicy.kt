package io.github.ncorror.nekoflash.adb.transport

/**
 * Host-side ADB receive framing policy.
 *
 * ADB device -> host traffic is framed as one USB transfer for the 24-byte header and one
 * separate USB transfer for the declared payload. The host must therefore arm one receive
 * transfer large enough for the whole payload; splitting one ADB payload into several smaller
 * USB IN transactions can terminate/discard the device transfer and desynchronize aprotocol.
 *
 * Android's public USB Host APIs could not accept transfers larger than 16 KiB before API 28.
 * On those hosts we advertise 16 KiB in CNXN so the peer is contractually required to keep
 * WRTE payloads within a single supported receive transfer.
 */
internal object AdbInboundUsbPolicy {
    const val PRE_P_MAX_PAYLOAD_BYTES: Int = 16 * 1024
    const val MODERN_MAX_PAYLOAD_BYTES: Int = 1_048_576
    const val ANDROID_P_API_LEVEL: Int = 28

    fun advertisedMaxPayload(apiLevel: Int): Int =
        if (apiLevel >= ANDROID_P_API_LEVEL) {
            MODERN_MAX_PAYLOAD_BYTES
        } else {
            PRE_P_MAX_PAYLOAD_BYTES
        }

    fun payloadReadIsComplete(expectedBytes: Int, actualBytes: Int): Boolean =
        expectedBytes >= 0 && actualBytes == expectedBytes
}
