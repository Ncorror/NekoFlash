package io.github.ncorror.nekoflash.fastboot.transport

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FastbootTransactionTest {
    @Test
    fun `packet codec decodes INFO OKAY FAIL TEXT and DATA uniformly`() {
        assertEquals("INFO", packet("INFOhello").type)
        assertEquals("OKAY", packet("OKAYdone").type)
        assertEquals("FAIL", packet("FAILnope").type)
        assertEquals("TEXT", packet("TEXTline").type)
        assertEquals("DATA", packet("DATA00001000").type)
    }

    @Test
    fun `DATA size is hexadecimal and invalid payload remains unparsed`() {
        assertEquals(0x1000L, packet("DATA00001000").dataSizeBytes())
        assertEquals(0x20L, packet("DATA0x20").dataSizeBytes())
        assertNull(packet("DATAnot-a-size").dataSizeBytes())
    }

    @Test
    fun `inactivity budget refreshes on protocol activity`() {
        val budget = FastbootInactivityBudget(timeoutMs = 30_000L, startedAtNs = 0L)
        assertEquals(1_000L, budget.remainingMs(29_000_000_000L))
        budget.markActivity(29_000_000_000L)
        assertEquals(1_000L, budget.remainingMs(58_000_000_000L))
        assertEquals(0L, budget.remainingMs(59_000_000_000L))
    }

    @Test
    fun `read slices never become a total transaction deadline`() {
        assertEquals(900, FastbootTransactionTiming.nextReadTimeoutMs(30_000L))
        assertEquals(250, FastbootTransactionTiming.nextReadTimeoutMs(250L))
        assertTrue(FastbootGetVarAllRequest.INACTIVITY_TIMEOUT_MS > FastbootTransactionTiming.READ_SLICE_MS)
    }

    @Test
    fun `getvar normalization accepts dash and underscore variants`() {
        assertEquals(
            "1234",
            FastbootGetVarValue.normalize("max-download-size", "max_download_size: 1234"),
        )
    }

    @Test
    fun `getvar all request has write timing separate from response inactivity`() {
        assertEquals("getvar:all", FastbootGetVarAllRequest.COMMAND)
        assertEquals(10_000, FastbootGetVarAllRequest.WRITE_TIMEOUT_MS)
        assertEquals(30_000, FastbootGetVarAllRequest.INACTIVITY_TIMEOUT_MS)
    }

    @Test
    fun `handshake write timing is explicit and separate from response inactivity`() {
        assertEquals(7_000, FastbootTransactionTiming.HANDSHAKE_WRITE_TIMEOUT_MS)
        assertEquals(7_000, FastbootTransactionTiming.HANDSHAKE_INACTIVITY_TIMEOUT_MS)
    }

    private fun packet(raw: String): FastbootPacket =
        FastbootPacketCodec.parse(raw.toByteArray(Charsets.US_ASCII))
}
