package io.github.ncorror.nekoflash.operation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SideloadVerificationStoreTest {
    @Test
    fun pendingIdentityIsDurableAndClearsOnlyOnExactMatch() {
        val persistence = FakePersistence()
        val store = SideloadVerificationStore(persistence)
        val pending = pending(sha = "a".repeat(64))

        assertTrue(store.recordPending(pending))
        assertEquals(pending, store.currentPending())
        assertFalse(store.clearIfMatches(pending(sha = "b".repeat(64))))
        assertEquals(pending, store.currentPending())
        assertTrue(store.clearIfMatches(pending))
        assertNull(store.currentPending())
    }

    @Test
    fun differentUnresolvedIdentityCannotBeOverwritten() {
        val persistence = FakePersistence()
        val store = SideloadVerificationStore(persistence)
        val first = pending(sha = "c".repeat(64))
        val second = pending(sha = "d".repeat(64), operationGeneration = 2L)

        assertTrue(store.recordPending(first))
        assertFalse(store.recordPending(second))
        assertEquals(first, store.currentPending())
    }

    @Test
    fun persistenceFailureDoesNotPretendPendingWasCommitted() {
        val persistence = FakePersistence(writeSucceeds = false)
        val store = SideloadVerificationStore(persistence)

        assertFalse(store.recordPending(pending(sha = "e".repeat(64))))
        assertNull(store.currentPending())
    }

    private fun pending(
        sha: String,
        operationGeneration: Long = 1L,
    ) = SideloadVerificationStore.Pending(
        operationGeneration = operationGeneration,
        deviceLabel = "vayu",
        fileName = "update.zip",
        totalBytes = 1234L,
        sha256 = sha,
        startedAtEpochMs = 1000L,
        transferFinishedAtEpochMs = 2000L,
        message = "verify Recovery",
    )

    private class FakePersistence(
        private val writeSucceeds: Boolean = true,
    ) : SideloadVerificationStore.Persistence {
        private var pending: SideloadVerificationStore.Pending? = null

        override fun readPending(): SideloadVerificationStore.Pending? = pending

        override fun writePending(pending: SideloadVerificationStore.Pending): Boolean {
            if (!writeSucceeds) return false
            this.pending = pending
            return true
        }

        override fun clearPending(): Boolean {
            pending = null
            return true
        }
    }
}
