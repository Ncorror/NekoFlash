package io.github.ncorror.nekoflash.fastboot.transport

/** Public-to-module result model for one safety-gated Fastboot flash transaction. */
internal enum class FastbootFlashStage {
    VALIDATION,
    AUTHORIZATION,
    SEND_DOWNLOAD,
    WAIT_DATA,
    DATA_TRANSFER,
    WAIT_DOWNLOAD_FINAL,
    SEND_FLASH,
    WAIT_FLASH_FINAL,
    COMPLETE,
}

internal enum class FastbootFlashFailureKind {
    NONE,
    VALIDATION,
    SAFETY,
    PROTOCOL,
    TRANSPORT,
    CANCELLED,
    SESSION_UNAVAILABLE,
}

internal data class FastbootFlashResult(
    val success: Boolean,
    val stage: FastbootFlashStage,
    val failureKind: FastbootFlashFailureKind,
    val message: String = "",
    val partition: String? = null,
    val dataBytesTransferred: Long = 0L,
    val sessionCorrupted: Boolean = false,
) {
    companion object {
        fun ok(partition: String, dataBytesTransferred: Long): FastbootFlashResult = FastbootFlashResult(
            success = true,
            stage = FastbootFlashStage.COMPLETE,
            failureKind = FastbootFlashFailureKind.NONE,
            partition = partition,
            dataBytesTransferred = dataBytesTransferred,
        )

        fun fail(
            stage: FastbootFlashStage,
            kind: FastbootFlashFailureKind,
            message: String,
            partition: String? = null,
            dataBytesTransferred: Long = 0L,
            sessionCorrupted: Boolean = false,
        ): FastbootFlashResult = FastbootFlashResult(
            success = false,
            stage = stage,
            failureKind = kind,
            message = message,
            partition = partition,
            dataBytesTransferred = dataBytesTransferred,
            sessionCorrupted = sessionCorrupted,
        )
    }
}
