package io.github.ncorror.nekoflash.operation

import android.annotation.SuppressLint
import android.content.Context

/**
 * Durable owner of the single ADB Sideload result that still requires Recovery-side verification.
 *
 * Transfer completion is not install success. Once the host stream reaches a verification-pending
 * terminal, the exact package identity is committed here before the in-memory operation publishes
 * VERIFICATION_PENDING. A process restart can therefore restore the pending result and verify it
 * only after a later Recovery ADB connection.
 */
class SideloadVerificationStore(
    private val persistence: Persistence,
) {
    data class Pending(
        val operationGeneration: Long,
        val deviceLabel: String?,
        val fileName: String,
        val totalBytes: Long,
        val sha256: String,
        val startedAtEpochMs: Long,
        val transferFinishedAtEpochMs: Long,
        val message: String?,
    ) {
        init {
            require(operationGeneration > 0L) { "Operation generation must be positive" }
            require(fileName.isNotBlank()) { "Sideload file name must not be blank" }
            require(totalBytes > 0L) { "Sideload payload size must be positive" }
            require(SHA256_REGEX.matches(sha256)) { "Sideload SHA-256 must be 64 lowercase hex characters" }
            require(startedAtEpochMs > 0L) { "Sideload start time must be positive" }
            require(transferFinishedAtEpochMs >= startedAtEpochMs) {
                "Sideload transfer finish time precedes start time"
            }
        }
    }

    interface Persistence {
        fun readPending(): Pending?

        /** Returns true only after the exact pending identity is durably committed. */
        fun writePending(pending: Pending): Boolean

        /** Returns true only after durable removal succeeds. */
        fun clearPending(): Boolean
    }

    private val lock = Any()

    fun currentPending(): Pending? = synchronized(lock) { persistence.readPending() }

    /** Never overwrites a different unresolved package identity. */
    fun recordPending(pending: Pending): Boolean = synchronized(lock) {
        val current = persistence.readPending()
        if (current != null && current != pending) return false
        persistence.writePending(pending)
    }

    /** Clears only when the durable record still equals the result that was actually verified. */
    fun clearIfMatches(expected: Pending): Boolean = synchronized(lock) {
        val current = persistence.readPending() ?: return true
        if (current != expected) return false
        persistence.clearPending()
    }

    companion object {
        private val SHA256_REGEX = Regex("^[0-9a-f]{64}$")
    }
}

/** SharedPreferences persistence for [SideloadVerificationStore]. */
class SharedPreferencesSideloadVerificationPersistence(context: Context) :
    SideloadVerificationStore.Persistence {
    private val preferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE,
    )

    override fun readPending(): SideloadVerificationStore.Pending? {
        if (!preferences.getBoolean(KEY_PRESENT, false)) return null
        return runCatching {
            SideloadVerificationStore.Pending(
                operationGeneration = preferences.getLong(KEY_OPERATION_GENERATION, 0L),
                deviceLabel = preferences.getString(KEY_DEVICE_LABEL, null),
                fileName = preferences.getString(KEY_FILE_NAME, null).orEmpty(),
                totalBytes = preferences.getLong(KEY_TOTAL_BYTES, 0L),
                sha256 = preferences.getString(KEY_SHA256, null).orEmpty(),
                startedAtEpochMs = preferences.getLong(KEY_STARTED_AT, 0L),
                transferFinishedAtEpochMs = preferences.getLong(KEY_FINISHED_AT, 0L),
                message = preferences.getString(KEY_MESSAGE, null),
            )
        }.getOrNull()
    }

    @SuppressLint("ApplySharedPref")
    @Suppress("UseKtx")
    override fun writePending(pending: SideloadVerificationStore.Pending): Boolean =
        preferences.edit()
            .putBoolean(KEY_PRESENT, true)
            .putLong(KEY_OPERATION_GENERATION, pending.operationGeneration)
            .putString(KEY_DEVICE_LABEL, pending.deviceLabel)
            .putString(KEY_FILE_NAME, pending.fileName)
            .putLong(KEY_TOTAL_BYTES, pending.totalBytes)
            .putString(KEY_SHA256, pending.sha256)
            .putLong(KEY_STARTED_AT, pending.startedAtEpochMs)
            .putLong(KEY_FINISHED_AT, pending.transferFinishedAtEpochMs)
            .putString(KEY_MESSAGE, pending.message)
            .commit()

    @SuppressLint("ApplySharedPref")
    @Suppress("UseKtx")
    override fun clearPending(): Boolean = preferences.edit().clear().commit()

    private companion object {
        const val PREFS_NAME = "nekoflash_sideload_verification"
        const val KEY_PRESENT = "present"
        const val KEY_OPERATION_GENERATION = "operation_generation"
        const val KEY_DEVICE_LABEL = "device_label"
        const val KEY_FILE_NAME = "file_name"
        const val KEY_TOTAL_BYTES = "total_bytes"
        const val KEY_SHA256 = "sha256"
        const val KEY_STARTED_AT = "started_at_epoch_ms"
        const val KEY_FINISHED_AT = "transfer_finished_at_epoch_ms"
        const val KEY_MESSAGE = "message"
    }
}
