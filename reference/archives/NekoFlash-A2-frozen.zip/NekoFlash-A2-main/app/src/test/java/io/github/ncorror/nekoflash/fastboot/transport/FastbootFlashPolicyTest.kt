package io.github.ncorror.nekoflash.fastboot.transport

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FastbootFlashPolicyTest {
    @Test
    fun `flash authorization fails closed for locked and unknown bootloader state`() {
        assertEquals(
            FastbootFlashPolicy.Authorization.Allowed,
            FastbootFlashPolicy.authorize("yes"),
        )
        assertEquals(
            FastbootFlashPolicy.Authorization.Blocked(FastbootFlashPolicy.BlockReason.BOOTLOADER_LOCKED),
            FastbootFlashPolicy.authorize("no"),
        )
        assertEquals(
            FastbootFlashPolicy.Authorization.Blocked(FastbootFlashPolicy.BlockReason.UNLOCK_STATE_UNKNOWN),
            FastbootFlashPolicy.authorize(null),
        )
        assertEquals(
            FastbootFlashPolicy.Authorization.Blocked(FastbootFlashPolicy.BlockReason.UNLOCK_STATE_UNKNOWN),
            FastbootFlashPolicy.authorize("FAIL variable not found"),
        )
    }

    @Test
    fun `flash plan normalizes partition and creates fixed width download command`() {
        val result = FastbootFlashPolicy.plan(
            partitionRaw = " Boot_A ",
            payloadBytes = 0x1234L,
            maxDownloadSizeBytes = 0x4000L,
        )
        assertTrue(result is FastbootFlashPolicy.PlanResult.Ready)
        val plan = (result as FastbootFlashPolicy.PlanResult.Ready).plan
        assertEquals("boot_a", plan.partition)
        assertEquals(0x1234L, plan.payloadBytes)
        assertEquals("download:00001234", plan.downloadCommand)
    }

    @Test
    fun `device download limit requires fresh okay and a positive parseable size`() {
        assertEquals(
            FastbootFlashPolicy.DeviceLimitResult.Available(0x10000000L),
            FastbootFlashPolicy.requireDeviceLimit("OKAY", "0x10000000"),
        )
        assertEquals(
            FastbootFlashPolicy.DeviceLimitResult.Unavailable,
            FastbootFlashPolicy.requireDeviceLimit("FAIL", "0x10000000"),
        )
        assertEquals(
            FastbootFlashPolicy.DeviceLimitResult.Unavailable,
            FastbootFlashPolicy.requireDeviceLimit("OKAY", null),
        )
        assertEquals(
            FastbootFlashPolicy.DeviceLimitResult.Unavailable,
            FastbootFlashPolicy.requireDeviceLimit("OKAY", "garbage"),
        )
        assertEquals(
            FastbootFlashPolicy.DeviceLimitResult.Unavailable,
            FastbootFlashPolicy.requireDeviceLimit("OKAY", "size=0x1000"),
        )
        assertEquals(
            FastbootFlashPolicy.DeviceLimitResult.Unavailable,
            FastbootFlashPolicy.requireDeviceLimit("OKAY", "0"),
        )
    }

    @Test
    fun `partition capacity requires fresh okay and a positive parseable size`() {
        assertEquals(
            FastbootFlashPolicy.PartitionCapacityResult.Available(0x08000000L),
            FastbootFlashPolicy.requirePartitionCapacity("OKAY", "0x08000000"),
        )
        assertEquals(
            FastbootFlashPolicy.PartitionCapacityResult.Available(134217728L),
            FastbootFlashPolicy.requirePartitionCapacity("OKAY", "134217728"),
        )
        assertEquals(
            FastbootFlashPolicy.PartitionCapacityResult.Unavailable,
            FastbootFlashPolicy.requirePartitionCapacity("FAIL", "0x08000000"),
        )
        assertEquals(
            FastbootFlashPolicy.PartitionCapacityResult.Unavailable,
            FastbootFlashPolicy.requirePartitionCapacity("OKAY", "garbage"),
        )
        assertEquals(
            FastbootFlashPolicy.PartitionCapacityResult.Unavailable,
            FastbootFlashPolicy.requirePartitionCapacity("OKAY", "0"),
        )
    }

    @Test
    fun `flash plan rejects payload larger than target partition`() {
        assertRejected(
            FastbootFlashPolicy.RejectReason.PAYLOAD_EXCEEDS_PARTITION,
            FastbootFlashPolicy.plan(
                partitionRaw = "recovery",
                payloadBytes = 0x08000001L,
                maxDownloadSizeBytes = 0x30000000L,
                partitionCapacityBytes = 0x08000000L,
            ),
        )
        val ready = FastbootFlashPolicy.plan(
            partitionRaw = "recovery",
            payloadBytes = 0x08000000L,
            maxDownloadSizeBytes = 0x30000000L,
            partitionCapacityBytes = 0x08000000L,
        )
        assertTrue(ready is FastbootFlashPolicy.PlanResult.Ready)
    }

    @Test
    fun `flash plan rejects invalid empty oversized and device limited payloads`() {
        assertRejected(
            FastbootFlashPolicy.RejectReason.INVALID_PARTITION,
            FastbootFlashPolicy.plan("../boot", 1L, null),
        )
        assertRejected(
            FastbootFlashPolicy.RejectReason.EMPTY_PAYLOAD,
            FastbootFlashPolicy.plan("boot", 0L, null),
        )
        assertRejected(
            FastbootFlashPolicy.RejectReason.PAYLOAD_TOO_LARGE_FOR_PROTOCOL,
            FastbootFlashPolicy.plan("boot", FastbootFlashPolicy.PROTOCOL_MAX_DOWNLOAD_BYTES + 1L, null),
        )
        assertRejected(
            FastbootFlashPolicy.RejectReason.PAYLOAD_EXCEEDS_DEVICE_LIMIT,
            FastbootFlashPolicy.plan("boot", 4096L, 2048L),
        )
    }

    private fun assertRejected(
        expected: FastbootFlashPolicy.RejectReason,
        actual: FastbootFlashPolicy.PlanResult,
    ) {
        assertTrue(actual is FastbootFlashPolicy.PlanResult.Rejected)
        assertEquals(expected, (actual as FastbootFlashPolicy.PlanResult.Rejected).reason)
    }
}
