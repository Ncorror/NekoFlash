package io.github.ncorror.nekoflash.operation

/** Quick Flash target interpretation chosen explicitly in the review flow. */
enum class QuickFlashSlotMode {
    /** For a slotted base partition, resolve and flash the device's current slot. */
    CURRENT,

    /** Use the reviewed explicit partition token after validation; do not add a slot suffix. */
    EXACT,
}
