# Fastboot transaction engine

This document describes the current Fastboot architecture after the transaction-foundation
refactor at A2 commit `70d422bc6545f83cb192b74b296326ac6672a741` and the DATA/flash continuation layered on that foundation.

The older staged document `FASTBOOT_TRANSPORT_READ_ONLY.md` is retained only as historical
verification evidence. Its read-only command surface, failed-read counters, total response
budgets, query-count cap, and staged CLOSED lists are not current architecture policy.

## Goal

Fastboot capability is built on one protocol-correct transaction engine rather than separate
read-only, terminal, inventory, and future mutation transports. Product policy belongs in
workflows/UI; the transport layer only enforces wire and ownership invariants required to keep
the session coherent.

## Transaction lane

One physical Fastboot session owns one synchronous transaction lane:

`DISCONNECTED -> IDLE -> AWAITING_FINAL -> IDLE`

For a command that enters DATA OUT, the same lane continues as:

`AWAITING_FINAL -> AWAITING_DATA -> SENDING_DATA -> AWAITING_DATA_FINAL -> IDLE`

A command may receive zero or more `INFO` / `TEXT` packets before terminal `OKAY` or `FAIL`.
Both terminal statuses complete that command and return the lane to `IDLE`.

`FAIL` is a device/protocol result, not a USB transport failure.

When the device returns `DATA`, the lane becomes `AWAITING_DATA` and the transaction returns a
`DataRequested` result containing the advertised hexadecimal byte count when it can be parsed.
A caller can then continue that exact exchange with `continueDataOut`. The advertised DATA size,
the expected payload size, and the current file size must agree before any payload byte is sent.

DATA OUT supports the legacy-proven Java `UsbRequest` path and an explicit synchronous
`bulkTransfer` mode. The mode is selected before DATA begins. A failed/ambiguous DATA write is
never retried using another transport in the same Fastboot exchange because the host can no
longer prove how many bytes the bootloader accepted. Such a failure invalidates the session.
After the exact payload is sent, the lane waits for a terminal `OKAY`/`FAIL` using the same rolling
inactivity semantics as command responses.

If no protocol activity is observed for the configured inactivity interval after a command was
sent, the lane becomes `STALLED`. The physical USB handle may still be open, but a second command
must not be written onto an unresolved synchronous Fastboot exchange. Reconnect/resynchronization
is therefore a protocol-framing requirement, not an application command restriction.

## Timeout semantics

Short USB IN reads are polling slices for responsiveness only. They are not retry counters and
do not create a total command deadline.

A transaction has:

- a USB write timeout for the command OUT transfer;
- an inactivity timeout measured from the most recent protocol packet.

Every received packet refreshes inactivity. A long `getvar:all` stream that continues producing
`INFO` or `TEXT` therefore remains alive for as long as the bootloader is making progress.

The old `MAX_FAILED_READS`, retry-delay/minimum-patience logic, and the old total 30-second
`getvar:all` response budget are not part of the new engine.

## Transport failure versus command result

Transport failure is reserved for failures that invalidate the USB transport itself, such as:

- interface/endpoints cannot be resolved;
- USB device cannot be opened;
- interface cannot be claimed;
- command OUT transfer is short;
- an ambiguous/failed DATA OUT transfer;
- timeout after an already-sent DATA payload;
- a response that makes DATA framing impossible to prove;
- an unexpected local transport exception prevents continued framing.

The following are transaction/operation results and do not automatically call the transport
failure callback:

- terminal `FAIL`;
- a valid `DATA` request before payload transfer;
- ordinary command inactivity timeout in the generic transaction primitive;
- partial `getvar:all` data before an incomplete terminal outcome.

A destructive flash workflow treats unresolved safety/download/flash exchanges more strictly and
invalidates the session when continuing could cross an unproven protocol boundary.

## Diagnostics and inventory

Qualification, core diagnostics, extended diagnostics, `getvar:all`, and point-query backfill
all consume the same transaction engine.

The canonical implementations are:

- `fastboot.codec.FastbootGetVarAllParser`;
- `fastboot.partition.FastbootPartitionInventoryBuilder`;
- `fastboot.partition.FastbootPartitionProbePlanner`.

Transport-local duplicate parser/inventory/planner implementations are removed.

The planner has no application-level `24`-query budget and no omitted-query counter. It builds a
full deterministic request plan from observed metadata and discovery hypotheses. Partition-name
validation and evidence rules remain because they protect inventory correctness, not because they
limit Fastboot capability.

## Privacy

Raw broad diagnostic values remain local to the collection operation. Exported transport events
redact `getvar:all` payloads and sensitive point-query payloads. The coordinator receives aggregate
snapshot/inventory facts, not a raw serial-number map.

Generic command execution is an internal protocol primitive in this patch and accepts
`redactCommand = true` so a caller can keep sensitive command text out of transport events.
Callers that later expose secret-bearing vendor commands must use that event-redaction path.

## Operation integration

`OperationCoordinator` owns one active application operation and now distinguishes
`FASTBOOT_DIAGNOSTIC_REFRESH` from `FASTBOOT_FLASH`. A flash lease carries immutable review
metadata plus monotonic byte progress and explicit stages for authorization, DATA transfer,
bootloader write completion, finalization, and cancellation.

Cancellation is generation-safe and non-terminal: requesting it moves the active operation to
`CANCELLING` and invokes cleanup for that exact generation, but the coordinator does not publish
terminal `ABORTED` until the USB/file owner has actually unwound and completes its lease. A late
cancellation is rejected once the operation atomically crosses into `WRITING`: at that point the
device-side `flash:` mutation may be committed and closing USB would only destroy knowledge of the
terminal result. The final safe boundary is after DATA has completed but before `flash:` is sent;
the owner-level transition to `WRITING` and cancellation request are serialized so exactly one can
win that race.

A completed `OKAY` broad refresh is a successful diagnostic operation. Terminal `FAIL`, timeout,
or other incomplete broad-refresh outcomes are failures. Timeout/DATA can additionally leave the
transaction lane unavailable until reconnect, while terminal `FAIL` leaves it reusable.

The coordinator remains an ownership/state primitive, not a Fastboot command allowlist.

## Flash safety

`flashPartitionDetailed` is fail-closed before `download:`. It refreshes `getvar:unlocked`
immediately before the destructive flow and proceeds only when the fresh value explicitly parses
as unlocked (`yes`/`true`/`1`). `unlocked=no`, unsupported/`FAIL`, missing, or unparseable values
all block the operation before DATA. `secure=yes` is not used as a substitute lock signal.

The plan also validates the partition token, rejects empty or >4 GiB protocol payloads, and
requires a fresh terminal `OKAY` with a positive strictly numeric/hex `max-download-size`.
Missing, failed, zero, or malformed size metadata blocks before DATA rather than silently assuming
an unlimited device. The flow is `download:<8hex>` -> exact DATA transfer -> download terminal `OKAY` ->
`flash:<partition>` -> terminal `OKAY`. A terminal Fastboot `FAIL` is reported as a protocol
result and does not by itself mean the USB transport failed.

Quick Flash uses a SAF-backed one-shot `FastbootDataSource`: the application owns the selected
read-only file descriptor until an operation atomically takes it, then the operation closes it on
every terminal path. Snapshot observation is generation-safe across Activity recreation and never
transfers descriptor ownership to the UI. The image is not copied into broad shared storage or duplicated into a
private multi-gigabyte staging file. Selection is fail-closed unless the opened descriptor itself
reports a positive stable size; provider metadata alone is not trusted for the Fastboot DATA
length. DATA reads are hard-capped at that advertised size so a changing source can never send
bytes past the negotiated DATA boundary. Cancellation closes both the USB request/transport and
the active payload stream so a blocked provider read cannot retain operation ownership forever.
Current-slot mode freshly queries `has-slot:<partition>` and `current-slot`; exact mode uses the
reviewed concrete partition token after normal validation/normalization and does not add a slot
suffix automatically.

The legacy2 source contains a diagnostic warning saying `unlocked=no` will be blocked, but the
examined `flashPartitionDetailed` implementation does not actually enforce that warning before
`download:`. A2 intentionally implements the real guard rather than copying that gap.

## Validation status

The current exact verified baseline before the Native USBFS overlay is
`3863cbc407052b177d82889714491ef0de03de97` (`guard fastboot target capacity`). Exact Android
CI run `32888432420` passed unit tests, lint, debug assembly, APK upload, and reports.

That exact build also passed the first real destructive A2 Fastboot hardware gate on an unlocked
`vayu`: fresh unlock/max-download/target-capacity checks passed, `download:08000000` negotiated
128 MiB, Java `ASYNC_USB_REQUEST` transferred exactly 134217728 confirmed bytes in about 4.437 s,
the download terminal response was `OKAY`, `flash:recovery` returned terminal `OKAY`, and the
operation finished `SUCCEEDED` with `sessionCorrupted=false`. The device then detached from
Fastboot, re-enumerated as ADB Recovery, and the read-only ADB probe returned `vayu`.

The Java `UsbRequest` DATA path at `3863cbc` is therefore the hardware-proven fallback baseline.
Native USBFS remains unverified until the native overlay passes exact repository Android CI and a
controlled real-device DATA/flash run. `marble` is no longer available and is not a current gate.

## Next implementation step

Port and validate the bounded Native USBFS two-URB DATA pipeline without weakening SAF ownership,
Fastboot transaction boundaries, or USB shutdown safety. Native-vs-Java mode selection must be
resolved before `download:`. No transport switch/retry is allowed after DATA negotiation begins.
If native drain cannot be proven complete, the backend/USB process is blocked fail-closed until a
full app process restart rather than closing the physical connection under kernel-owned URBs.

After exact CI for the native overlay, repeat the already-proven `vayu` `recovery.img -> recovery`
transaction once using the exact CI-built APK. Export diagnostics immediately afterward so the
selected mode, native submit/reap progress, terminal download/flash results, and drain state can be
compared with the 4.437 s Java baseline.

## Fresh target-capacity gate

Immediately before DATA, destructive Quick Flash now requires a terminal `OKAY` from `getvar:partition-size:<target>` with a positive parseable size. The payload must fit inside that target capacity. `FAIL`, an unknown/zero size, or an oversized payload blocks before `download:`. This is separate from and in addition to the fresh `unlocked` and `max-download-size` checks.


## Native USBFS DATA phase

The Java `ASYNC_USB_REQUEST` path is now hardware-proven by the first real A2 `DATA -> flash:recovery`
transaction at commit `3863cbc407052b177d82889714491ef0de03de97`: 128 MiB was protocol-confirmed
in about 4.437 s, the download and `flash:recovery` exchanges both ended in `OKAY`, and the target
subsequently re-enumerated as ADB Recovery.

The next transport phase ports the legacy bounded Native USBFS pipeline with these A2 rules:

- mode selection occurs before `download:`; AUTO may choose Native USBFS only after library, USB fd,
  endpoint and duplicated regular payload-fd preflight all pass; otherwise it selects the already-proven
  Java `UsbRequest` path before DATA starts;
- explicit Native mode fails closed on preflight failure and never silently switches after DATA negotiation;
- native DATA uses a two-URB pipeline with 256 KiB blocks and adaptive ENOMEM block reduction;
- progress and success count only normally reaped/confirmed URB bytes, not merely submitted bytes;
- cancellation is tokenized and uses DISCARDURB followed by REAP; submitted URB memory is never freed
  while usbfs may still own it;
- an unproven drain poisons/blocks native transport for the process; physical `UsbDeviceConnection` close
  is refused when native ownership cannot be proven idle;
- the native reader consumes a duplicated descriptor from the already-owned SAF payload. The selected image
  is not copied to shared storage or to an unbounded private staging file;
- the Java `UsbRequest` and synchronous bulk paths remain separate preselected modes and are never used as
  inline retries for an ambiguous native DATA exchange.

Exact CI and a real native hardware run are required before Native USBFS can be called hardware-verified.
