# ADB Sideload operation wiring

Original base commit: `0637a6d264cb2225b7e7fece15153004a32250e2`.

This document describes operation ownership. The later hardware-derived safety correction is
`docs/SIDELOAD_SAFETY_BOUNDARY.md` and supersedes the original cancellation/served-byte assumptions.

## Admission and payload ownership

- Package selection uses SAF and keeps one read-only descriptor outside Activity lifetime.
- The descriptor must expose a stable positive size and support positional reads before admission.
- NekoFlash computes SHA-256 locally from the exact selected bytes before the package can be sent.
- The operation atomically takes payload ownership; all rejection and terminal paths close the
  descriptor.
- Sideload is admitted only on the exact active ADB transport generation when the observed peer mode
  is `SIDELOAD`.

## Operation semantics

- `OperationCoordinator.Kind.ADB_SIDELOAD` shares the existing single-operation slot.
- UI progress is unique acknowledged package coverage. Cumulative USB payload traffic remains in
  diagnostics because Recovery can request duplicate blocks.
- `DONEDONE`, the unique-coverage >=95% near-complete close case, and every ambiguous interruption
  after the first payload block terminate as `VERIFICATION_PENDING`, never `SUCCEEDED`.
- The selected package SHA-256 is retained in operation metadata and diagnostics.

## Cancellation after hardware correction

- Cancellation is allowed while the operation is preparing and before the first payload block.
- Immediately before the first payload WRTE, the operation atomically advances to `WRITING`.
- `WRITING` is the Sideload mutation boundary: ordinary cancellation is rejected from that point.
- A cancellation accepted before that boundary retires the exact ADB transport generation and may
  finish as `ABORTED` only after cleanup.
- After payload start, transport loss is not called cancellation; it becomes
  `VERIFICATION_PENDING` because device mutation may already have happened.
- A retired Sideload generation cannot be reopened on the same physical USB candidate until an
  actual detach/attach is observed.

## Verification gate

Recovery verification remains independent of host transfer completion. Hardware installation
success must never be inferred from 100% transport, `DONEDONE`, or connection close alone.
