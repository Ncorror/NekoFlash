package io.github.ncorror.nekoflash.usb.session

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SideloadReconnectPolicyTest {
    @Test
    fun `retired stable key blocks only the same physical candidate`() {
        assertTrue(SideloadReconnectPolicy.shouldBlock("adb:7:1", "adb:7:1"))
        assertFalse(SideloadReconnectPolicy.shouldBlock("adb:7:1", "adb:8:1"))
        assertFalse(SideloadReconnectPolicy.shouldBlock(null, "adb:7:1"))
    }

    @Test
    fun `only matching detach clears retired sideload quarantine`() {
        assertEquals(
            "adb:7:1",
            SideloadReconnectPolicy.afterDetach("adb:7:1", "adb:8:1"),
        )
        assertNull(SideloadReconnectPolicy.afterDetach("adb:7:1", "adb:7:1"))
        assertNull(SideloadReconnectPolicy.afterDetach(null, "adb:7:1"))
    }
}
