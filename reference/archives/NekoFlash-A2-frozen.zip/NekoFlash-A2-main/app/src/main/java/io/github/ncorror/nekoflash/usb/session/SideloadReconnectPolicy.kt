package io.github.ncorror.nekoflash.usb.session

/**
 * Pure stable-key quarantine policy for retired ADB Sideload generations.
 *
 * A retired Sideload endpoint may still have stale stream packets queued. Reopening the same
 * physical candidate without a real detach risks treating that stale endpoint as a fresh Recovery
 * transport. Only a matching USB detach clears the quarantine.
 */
internal object SideloadReconnectPolicy {
    fun shouldBlock(requiredStableKey: String?, candidateStableKey: String): Boolean =
        requiredStableKey != null && requiredStableKey == candidateStableKey

    fun afterDetach(requiredStableKey: String?, detachedStableKey: String?): String? =
        if (requiredStableKey != null && detachedStableKey == requiredStableKey) null else requiredStableKey
}
