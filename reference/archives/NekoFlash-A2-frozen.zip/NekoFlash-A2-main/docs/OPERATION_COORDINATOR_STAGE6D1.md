# Stage 6D1 — OperationCoordinator foundation

Stage 6D1 begins the Application-scoped operation ownership required by the A2
architecture without widening the protocol surface.

## First owned operation

The first real operation is the already CI- and hardware-proven explicit manual
Fastboot read-only refresh:

`manual getvar:all -> local inventory -> bounded legacy metadata backfill`

No new Fastboot command is introduced by this stage.

## Ownership boundary

`OperationCoordinator` owns:

- admission to the single active-operation slot;
- immutable active/last-result observation;
- operation generation;
- terminal outcome (`SUCCEEDED`, `FAILED`, `ABORTED`);
- generation-safe UI listener replacement.

`UsbSessionCoordinator` continues to own:

- Android USB discovery/permission/lifecycle;
- Fastboot transport generation;
- the actual manual read-only Fastboot wire sequence;
- transport failure and stale-generation decisions;
- USB/Fastboot diagnostics.

The UI observes operation state but does not own the operation or protocol.

## Verified Stage 6D1 invariants

Exact implementation commit:

`5add86c438397fa3107aafbfb4fb86fa2640639d`

Exact-head CI evidence:

- reports: `NekoFlash-5add86c438397fa3107aafbfb4fb86fa2640639d-reports.zip`;
- reports SHA-256:
  `cdf8bb8dffef85999aa781b6d05ae651950945cb716e05b2937e58d07014aa9d`;
- 191/191 unit tests passed;
- lint: 0 errors / 4 known baseline warnings;
- `assembleDebug`: success.

Hardware evidence proved all of the following around the unchanged manual Fastboot
read-only refresh:

- only one operation owns the slot at a time;
- successful operations finish `SUCCEEDED` and release the slot;
- real Fastboot timeout/transport failures finish `FAILED` and release the slot;
- detach while the operation is `RUNNING` closes the Fastboot transport and the
  operation reaches a terminal outcome instead of remaining stuck active;
- after terminal completion Home returns to no active operation;
- no hidden automatic transport retry was introduced;
- after a valid target-side Fastboot re-entry/re-enumeration, a later operation lease
  can be accepted and complete successfully;
- no new USB/Fastboot wire command was added by the operation layer.

Primary cumulative success/failure campaign:

- `NekoFlash-A2-diagnostics-20260822-203119Z.zip`;
- SHA-256:
  `a701bfaab8768a2f4e0274c457b0ebf027922f2df4dcf01cbdd54f6ed663df5d`.

Detach-during-operation campaign:

- `NekoFlash-A2-diagnostics-20260822-204358Z.zip`;
- SHA-256:
  `ebb38b961b896dcb61dad8dc60ac9b6e0adfc251149921cb548c6735c01e0e47`.

## `marble` recovery observation

The tested `marble` bootloader exposed a device-specific recovery requirement after a
real Fastboot failure/detach campaign:

- repeated host-side `Refresh USB` attempts could rediscover and claim the Fastboot
  interface, but `getvar:product` repeatedly short-wrote with `sent=-1 expected=14`;
- those manual host retries correctly stayed fail-closed and did not auto-loop;
- leaving and re-entering Fastboot on the target caused a real USB detach/attach
  re-enumeration;
- the fresh generation then wrote `getvar:product` as `14/14`, requalified `marble`,
  and accepted a new read-only operation which completed `SUCCEEDED`.

Refresh-only failure evidence:

- `NekoFlash-A2-diagnostics-20260822-205332Z.zip`;
- SHA-256:
  `309709ccbd2f51447f1aaa623fb4e39867bae1a417db5ede338566763e94d8a0`.

Target Fastboot re-entry recovery evidence:

- `NekoFlash-A2-diagnostics-20260822-205516Z.zip`;
- SHA-256:
  `459d0c43757d72fd92827acba0b1dc03c66c60e94ab92d41a131423ac70ac6ba`.

This is hardware evidence for the tested `marble` device. It is not a universal rule
for all Fastboot devices and must not be converted into a hidden retry/reboot policy.

## Deliberately deferred after 6D1

Stage 6D1 does not implement:

- user cancellation;
- operation-owned USB re-enumeration leases;
- granular byte/query progress;
- foreground service / wake-lock ownership;
- DATA/download;
- flash, erase, set_active, reboot;
- OEM/unlock;
- generic Fastboot command entry;
- generic ADB shell.

Stage 6D2 may extend only the operation observation/result contract around the same
already-proven read-only operation. Protocol and destructive semantics remain closed.
