package io.github.ncorror.nekoflash.fastboot.transport

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FastbootDataTransferTest {
    @Test
    fun `progress is based only on confirmed bytes and never reports 100 early`() {
        val progress = FastbootDataTransfer.calculateProgress(
            confirmedBytes = 512L,
            totalBytes = 1024L,
            elapsedMs = 1000L,
        )
        assertEquals(512L, progress.confirmedBytes)
        assertEquals(1024L, progress.totalBytes)
        assertEquals(50, progress.percent)
        assertEquals(512.0, progress.averageBytesPerSecond, 0.001)
        assertEquals(1000L, progress.etaMs)
    }

    @Test
    fun `progress clamps impossible confirmed counts and reaches 100 only at total`() {
        val almost = FastbootDataTransfer.calculateProgress(
            confirmedBytes = 999L,
            totalBytes = 1000L,
            elapsedMs = 1L,
        )
        assertTrue(almost.percent < 100)

        val complete = FastbootDataTransfer.calculateProgress(
            confirmedBytes = 5000L,
            totalBytes = 1000L,
            elapsedMs = 1000L,
        )
        assertEquals(1000L, complete.confirmedBytes)
        assertEquals(100, complete.percent)
        assertEquals(0L, complete.etaMs)
    }

    @Test
    fun `progress has no fabricated rate or eta before confirmed movement`() {
        val progress = FastbootDataTransfer.calculateProgress(
            confirmedBytes = 0L,
            totalBytes = 4096L,
            elapsedMs = 0L,
        )
        assertEquals(0, progress.percent)
        assertEquals(0.0, progress.averageBytesPerSecond, 0.0)
        assertNull(progress.etaMs)
    }
}
