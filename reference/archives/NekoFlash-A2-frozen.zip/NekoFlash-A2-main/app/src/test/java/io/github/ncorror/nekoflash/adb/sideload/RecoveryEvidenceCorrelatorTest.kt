package io.github.ncorror.nekoflash.adb.sideload

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RecoveryEvidenceCorrelatorTest {
    @Test
    fun `only content appended after exact baseline is eligible for verdict`() {
        val before = RecoveryInstallVerifier.LogSource(
            RecoveryEvidenceCorrelator.PRIMARY_PATH,
            "Starting ADB sideload\nInstall completed successfully\nidle marker\n",
        )
        val baseline = RecoveryEvidenceCorrelator.capture(before)
        val after = before.text + "Starting ADB sideload\nInstallation aborted\n"

        val correlation = RecoveryEvidenceCorrelator.correlate(
            listOf(RecoveryInstallVerifier.LogSource(RecoveryEvidenceCorrelator.PRIMARY_PATH, after)),
            baseline,
        ) as RecoveryEvidenceCorrelator.Correlation.Correlated

        assertFalse(correlation.source.text.contains("Install completed successfully"))
        assertTrue(correlation.source.text.contains("Installation aborted"))
        assertEquals(
            RecoveryInstallVerifier.Verdict.FAILED,
            RecoveryInstallVerifier.evaluate(listOf(correlation.source)).verdict,
        )
    }

    @Test
    fun `rewritten or rotated log fails closed instead of accepting fresh looking historical text`() {
        val baseline = RecoveryEvidenceCorrelator.capture(
            RecoveryInstallVerifier.LogSource(
                RecoveryEvidenceCorrelator.PRIMARY_PATH,
                "boot A\npre sideload\n",
            ),
        )
        val rewritten = "boot B\nStarting ADB sideload\nInstall completed successfully\n"

        val correlation = RecoveryEvidenceCorrelator.correlate(
            listOf(RecoveryInstallVerifier.LogSource(RecoveryEvidenceCorrelator.PRIMARY_PATH, rewritten)),
            baseline,
        ) as RecoveryEvidenceCorrelator.Correlation.Unavailable

        assertTrue(correlation.reason.contains("baseline", ignoreCase = true) || correlation.reason.contains("truncated"))
        assertTrue(correlation.diagnosticExcerpt.orEmpty().contains("Install completed successfully"))
    }

    @Test
    fun `missing baseline never manufactures a verdict and still exposes bounded diagnostics`() {
        val current = "Starting ADB sideload\ncustom recovery message\nInstall completed successfully\n"
        val correlation = RecoveryEvidenceCorrelator.correlate(
            listOf(RecoveryInstallVerifier.LogSource(RecoveryEvidenceCorrelator.PRIMARY_PATH, current)),
            baseline = null,
        ) as RecoveryEvidenceCorrelator.Correlation.Unavailable

        assertTrue(correlation.reason.contains("baseline", ignoreCase = true))
        assertTrue(correlation.diagnosticExcerpt.orEmpty().contains("custom recovery message"))
        assertTrue(correlation.diagnosticExcerpt.orEmpty().length <= 1_600)
    }

    @Test
    fun `empty post baseline delta remains unknown`() {
        val source = RecoveryInstallVerifier.LogSource(
            RecoveryEvidenceCorrelator.PRIMARY_PATH,
            "Recovery boot\n",
        )
        val baseline = RecoveryEvidenceCorrelator.capture(source)
        val correlation = RecoveryEvidenceCorrelator.correlate(listOf(source), baseline)
        assertTrue(correlation is RecoveryEvidenceCorrelator.Correlation.Unavailable)
    }
    @Test
    fun `appended text without a sideload session marker is diagnostic only`() {
        val before = RecoveryInstallVerifier.LogSource(
            RecoveryEvidenceCorrelator.PRIMARY_PATH,
            "Recovery idle\n",
        )
        val baseline = RecoveryEvidenceCorrelator.capture(before)
        val unrelated = before.text + "Install completed successfully\nmanual recovery action\n"

        val correlation = RecoveryEvidenceCorrelator.correlate(
            listOf(RecoveryInstallVerifier.LogSource(RecoveryEvidenceCorrelator.PRIMARY_PATH, unrelated)),
            baseline,
        ) as RecoveryEvidenceCorrelator.Correlation.Unavailable

        assertTrue(correlation.reason.contains("session marker", ignoreCase = true))
        assertTrue(correlation.diagnosticExcerpt.orEmpty().contains("Install completed successfully"))
    }

}
