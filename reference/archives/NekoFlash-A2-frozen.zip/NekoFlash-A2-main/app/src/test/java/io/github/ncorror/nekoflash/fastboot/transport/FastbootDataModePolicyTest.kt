package io.github.ncorror.nekoflash.fastboot.transport

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FastbootDataModePolicyTest {
    @Test
    fun `auto selects native only when preflight is clean`() {
        val selected = FastbootDataTransfer.chooseMode(
            FastbootDataTransfer.Mode.AUTO,
            nativePreflightError = null,
        )
        assertTrue(selected is FastbootDataTransfer.ModeSelection.Ready)
        assertEquals(
            FastbootDataTransfer.Mode.NATIVE_USBFS,
            (selected as FastbootDataTransfer.ModeSelection.Ready).mode,
        )
    }

    @Test
    fun `auto falls back before DATA when native preflight is unavailable`() {
        val selected = FastbootDataTransfer.chooseMode(
            FastbootDataTransfer.Mode.AUTO,
            nativePreflightError = "payload source is not a regular file",
        )
        assertTrue(selected is FastbootDataTransfer.ModeSelection.Ready)
        assertEquals(
            FastbootDataTransfer.Mode.ASYNC_USB_REQUEST,
            (selected as FastbootDataTransfer.ModeSelection.Ready).mode,
        )
    }

    @Test
    fun `explicit native mode fails closed instead of silently switching transport`() {
        val selected = FastbootDataTransfer.chooseMode(
            FastbootDataTransfer.Mode.NATIVE_USBFS,
            nativePreflightError = "backend poisoned",
        )
        assertTrue(selected is FastbootDataTransfer.ModeSelection.Rejected)
    }

    @Test
    fun `explicit Java mode never depends on native preflight`() {
        val selected = FastbootDataTransfer.chooseMode(
            FastbootDataTransfer.Mode.ASYNC_USB_REQUEST,
            nativePreflightError = "backend unavailable",
        )
        assertEquals(
            FastbootDataTransfer.Mode.ASYNC_USB_REQUEST,
            (selected as FastbootDataTransfer.ModeSelection.Ready).mode,
        )
    }
}
