package io.github.ncorror.nekoflash.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import io.github.ncorror.nekoflash.R
import io.github.ncorror.nekoflash.operation.OperationCoordinator
import io.github.ncorror.nekoflash.operation.QuickFlashPayloadStore
import io.github.ncorror.nekoflash.operation.QuickFlashSlotMode
import io.github.ncorror.nekoflash.operation.SideloadPayloadStore
import io.github.ncorror.nekoflash.ui.components.StatusCard
import io.github.ncorror.nekoflash.ui.components.StatusTone
import io.github.ncorror.nekoflash.ui.theme.NekoFlashSpacing
import io.github.ncorror.nekoflash.usb.session.AdbObservedPeerMode
import io.github.ncorror.nekoflash.usb.session.AdbTransportObservation
import io.github.ncorror.nekoflash.usb.session.FastbootTransportObservation
import io.github.ncorror.nekoflash.usb.session.UsbCandidateSummary
import io.github.ncorror.nekoflash.usb.session.UsbManualScanPrompt
import io.github.ncorror.nekoflash.usb.session.UsbObservedMode
import io.github.ncorror.nekoflash.usb.session.UsbSessionObservation
import java.util.Locale

private data class HomeStatusItem(
    val label: String,
    val value: String,
    val tone: StatusTone = StatusTone.Neutral,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    observation: UsbSessionObservation,
    operationObservation: OperationCoordinator.Observation,
    manualScanPrompt: UsbManualScanPrompt?,
    diagnosticsExportInProgress: Boolean,
    diagnosticsExportMessage: String?,
    sideloadPayload: SideloadPayloadStore.Snapshot?,
    sideloadPayloadPreparing: Boolean,
    sideloadMessage: String?,
    quickFlashPayload: QuickFlashPayloadStore.Snapshot?,
    quickFlashPayloadPreparing: Boolean,
    quickFlashMessage: String?,
    onRefreshUsb: () -> Unit,
    onRefreshFastbootDiagnostics: () -> Unit,
    onManualCandidateChosen: (String) -> Unit,
    onConfirmGenericFastboot: (String) -> Unit,
    onDismissManualPrompt: () -> Unit,
    onExportDiagnostics: () -> Unit,
    onChooseSideloadPackage: () -> Unit,
    onClearSideloadPackage: () -> Unit,
    onStartSideload: () -> Unit,
    onChooseQuickFlashImage: () -> Unit,
    onClearQuickFlashImage: () -> Unit,
    onStartQuickFlash: (String, QuickFlashSlotMode) -> Unit,
    onCancelActiveOperation: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val candidate = observation.candidate
    val statusItems = listOf(
        HomeStatusItem(
            label = stringResource(R.string.status_device),
            value = candidate?.deviceLabel ?: stringResource(R.string.device_not_detected),
        ),
        HomeStatusItem(
            label = stringResource(R.string.status_mode),
            value = candidate?.mode?.localizedLabel() ?: stringResource(R.string.usb_status_not_detected),
        ),
        HomeStatusItem(
            label = stringResource(R.string.status_usb),
            value = observation.status.localizedLabel(),
            tone = if (observation.status == UsbSessionObservation.Status.CANDIDATE_READY) {
                StatusTone.Positive
            } else {
                StatusTone.Neutral
            },
        ),
        HomeStatusItem(
            label = stringResource(R.string.status_adb),
            value = observation.adbTransport.localizedLabel(),
            tone = if (observation.adbTransport.status == AdbTransportObservation.Status.CONNECTED) {
                StatusTone.Positive
            } else {
                StatusTone.Neutral
            },
        ),
        HomeStatusItem(
            label = stringResource(R.string.status_fastboot),
            value = observation.fastbootTransport.localizedLabel(),
            tone = if (observation.fastbootTransport.status == FastbootTransportObservation.Status.CONNECTED) {
                StatusTone.Positive
            } else {
                StatusTone.Neutral
            },
        ),
        HomeStatusItem(
            label = stringResource(R.string.status_operation),
            value = operationObservation.localizedLabel(),
            tone = StatusTone.Neutral,
        ),
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(text = stringResource(R.string.app_name)) },
            )
        },
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = NekoFlashSpacing.statusCardMinWidth),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(
                start = NekoFlashSpacing.screenHorizontal,
                end = NekoFlashSpacing.screenHorizontal,
                bottom = NekoFlashSpacing.screenBottom,
            ),
            horizontalArrangement = Arrangement.spacedBy(NekoFlashSpacing.cardGap),
            verticalArrangement = Arrangement.spacedBy(NekoFlashSpacing.cardGap),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(NekoFlashSpacing.section),
                ) {
                    Text(
                        text = stringResource(R.string.home_heading),
                        style = MaterialTheme.typography.headlineSmall,
                    )
                    Text(
                        text = stringResource(R.string.home_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedButton(
                        onClick = onRefreshUsb,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = operationObservation.active == null,
                    ) {
                        Text(text = stringResource(R.string.usb_refresh_button))
                    }
                    OutlinedButton(
                        onClick = onRefreshFastbootDiagnostics,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = observation.fastbootTransport.status == FastbootTransportObservation.Status.CONNECTED &&
                            operationObservation.active == null,
                    ) {
                        Text(text = stringResource(R.string.fastboot_refresh_diagnostics_button))
                    }

                    SideloadSection(
                        observation = observation,
                        operationObservation = operationObservation,
                        payload = sideloadPayload,
                        payloadPreparing = sideloadPayloadPreparing,
                        message = sideloadMessage,
                        onChoosePackage = onChooseSideloadPackage,
                        onClearPackage = onClearSideloadPackage,
                        onStart = onStartSideload,
                        onCancelActiveOperation = onCancelActiveOperation,
                    )

                    QuickFlashSection(
                        observation = observation,
                        operationObservation = operationObservation,
                        payload = quickFlashPayload,
                        payloadPreparing = quickFlashPayloadPreparing,
                        message = quickFlashMessage,
                        onChooseImage = onChooseQuickFlashImage,
                        onClearImage = onClearQuickFlashImage,
                        onStart = onStartQuickFlash,
                        onCancelActiveOperation = onCancelActiveOperation,
                    )

                    OutlinedButton(
                        onClick = onExportDiagnostics,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !diagnosticsExportInProgress,
                    ) {
                        Text(
                            text = stringResource(
                                if (diagnosticsExportInProgress) {
                                    R.string.diagnostics_export_saving
                                } else {
                                    R.string.diagnostics_export_button
                                },
                            ),
                        )
                    }
                    if (diagnosticsExportMessage != null) {
                        Text(
                            text = diagnosticsExportMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            items(statusItems) { item ->
                StatusCard(
                    label = item.label,
                    value = item.value,
                    tone = item.tone,
                )
            }
        }
    }

    manualScanPrompt?.let { prompt ->
        when (prompt) {
            is UsbManualScanPrompt.Choose -> UsbCandidateChooserDialog(
                candidates = prompt.candidates,
                onChosen = onManualCandidateChosen,
                onDismiss = onDismissManualPrompt,
            )

            is UsbManualScanPrompt.ConfirmGenericFastboot -> GenericFastbootConfirmationDialog(
                candidate = prompt.candidate,
                onConfirm = onConfirmGenericFastboot,
                onDismiss = onDismissManualPrompt,
            )
        }
    }
}

@Composable
private fun SideloadSection(
    observation: UsbSessionObservation,
    operationObservation: OperationCoordinator.Observation,
    payload: SideloadPayloadStore.Snapshot?,
    payloadPreparing: Boolean,
    message: String?,
    onChoosePackage: () -> Unit,
    onClearPackage: () -> Unit,
    onStart: () -> Unit,
    onCancelActiveOperation: () -> Unit,
) {
    var showConfirmation by rememberSaveable { mutableStateOf(false) }
    val adb = observation.adbTransport
    val active = operationObservation.active
    val activeSideload = active?.takeIf { it.kind == OperationCoordinator.Kind.ADB_SIDELOAD }
    val sideloadReady = adb.status == AdbTransportObservation.Status.CONNECTED &&
        adb.peerMode == AdbObservedPeerMode.SIDELOAD
    val canReview = payload != null && !payloadPreparing && active == null && sideloadReady

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(NekoFlashSpacing.section),
            verticalArrangement = Arrangement.spacedBy(NekoFlashSpacing.inline),
        ) {
            Text(
                text = stringResource(R.string.sideload_title),
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                text = stringResource(R.string.sideload_description),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (activeSideload == null) {
                OutlinedButton(
                    onClick = onChoosePackage,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = active == null && !payloadPreparing,
                ) {
                    Text(
                        text = stringResource(
                            if (payloadPreparing) R.string.sideload_package_preparing else R.string.sideload_choose_package,
                        ),
                    )
                }
                if (payload != null) {
                    Text(
                        text = stringResource(
                            R.string.sideload_selected_package,
                            payload.displayName,
                            formatBytes(payload.sizeBytes),
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        text = stringResource(R.string.sideload_sha256, payload.sha256),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    TextButton(onClick = onClearPackage, enabled = active == null) {
                        Text(text = stringResource(R.string.sideload_clear_package))
                    }
                }

                Text(
                    text = stringResource(
                        if (sideloadReady) R.string.sideload_mode_ready else R.string.sideload_mode_required,
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (sideloadReady) {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    } else {
                        MaterialTheme.colorScheme.error
                    },
                )

                OutlinedButton(
                    onClick = { showConfirmation = true },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = canReview,
                ) {
                    Text(text = stringResource(R.string.sideload_review_button))
                }
            } else {
                SideloadProgress(
                    active = activeSideload,
                    onCancel = onCancelActiveOperation,
                )
            }

            if (message != null) {
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (activeSideload == null) {
                operationObservation.lastCompleted
                    ?.takeIf { it.kind == OperationCoordinator.Kind.ADB_SIDELOAD }
                    ?.let { completed ->
                        Text(
                            text = completedSideloadLabel(completed),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
            }
        }
    }

    if (showConfirmation && payload != null) {
        AlertDialog(
            onDismissRequest = { showConfirmation = false },
            title = { Text(stringResource(R.string.sideload_confirm_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(NekoFlashSpacing.inline)) {
                    Text(
                        stringResource(
                            R.string.sideload_confirm_summary,
                            payload.displayName,
                            formatBytes(payload.sizeBytes),
                            payload.sha256,
                        ),
                    )
                    Text(
                        text = stringResource(R.string.sideload_confirm_warning),
                        color = MaterialTheme.colorScheme.error,
                    )
                    Text(
                        text = stringResource(R.string.sideload_confirm_semantics),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmation = false
                        onStart()
                    },
                    enabled = canReview,
                ) {
                    Text(stringResource(R.string.sideload_confirm_send))
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmation = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}

@Composable
private fun SideloadProgress(
    active: OperationCoordinator.ActiveOperation,
    onCancel: () -> Unit,
) {
    Text(
        text = stringResource(R.string.sideload_active, active.metadata.fileName ?: "?"),
        style = MaterialTheme.typography.titleSmall,
    )
    Text(
        text = active.stage.localizedSideloadStage(),
        style = MaterialTheme.typography.bodyMedium,
    )
    active.progress?.let { progress ->
        LinearProgressIndicator(
            progress = { progress.percent / 100f },
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text = stringResource(
                R.string.sideload_progress,
                progress.percent,
                formatBytes(progress.confirmedBytes),
                formatBytes(progress.totalBytes),
                formatRate(progress.averageBytesPerSecond),
                formatEta(progress.etaMs),
            ),
            style = MaterialTheme.typography.bodySmall,
        )
    }
    Text(
        text = stringResource(R.string.sideload_progress_not_success),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    val cancellationLocked = active.stage == OperationCoordinator.Stage.WRITING ||
        active.stage == OperationCoordinator.Stage.FINALIZING
    if (cancellationLocked) {
        Text(
            text = stringResource(R.string.sideload_cancel_locked_after_payload),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
        )
    }
    OutlinedButton(
        onClick = onCancel,
        modifier = Modifier.fillMaxWidth(),
        enabled = !cancellationLocked && !active.cancellationRequested,
    ) {
        Text(
            text = stringResource(
                if (active.cancellationRequested) R.string.sideload_cancelling else R.string.sideload_cancel,
            ),
        )
    }
}

@Composable
private fun completedSideloadLabel(completed: OperationCoordinator.CompletedOperation): String {
    val base = stringResource(
        when (completed.outcome) {
            OperationCoordinator.Outcome.SUCCEEDED -> R.string.sideload_last_succeeded
            OperationCoordinator.Outcome.FAILED -> R.string.sideload_last_failed
            OperationCoordinator.Outcome.ABORTED -> R.string.sideload_last_aborted
            OperationCoordinator.Outcome.VERIFICATION_PENDING -> R.string.sideload_last_verification_pending
        },
    )
    return completed.message?.takeIf { it.isNotBlank() }?.let { "$base · $it" } ?: base
}

@Composable
private fun OperationCoordinator.Stage.localizedSideloadStage(): String = stringResource(
    when (this) {
        OperationCoordinator.Stage.STARTING -> R.string.sideload_stage_starting
        OperationCoordinator.Stage.RUNNING -> R.string.sideload_stage_running
        OperationCoordinator.Stage.AUTHORIZING -> R.string.sideload_stage_running
        OperationCoordinator.Stage.TRANSFERRING -> R.string.sideload_stage_transferring
        OperationCoordinator.Stage.WRITING -> R.string.sideload_stage_transferring
        OperationCoordinator.Stage.FINALIZING -> R.string.sideload_stage_finalizing
        OperationCoordinator.Stage.CANCELLING -> R.string.sideload_stage_cancelling
    },
)

@Composable
private fun QuickFlashSection(
    observation: UsbSessionObservation,
    operationObservation: OperationCoordinator.Observation,
    payload: QuickFlashPayloadStore.Snapshot?,
    payloadPreparing: Boolean,
    message: String?,
    onChooseImage: () -> Unit,
    onClearImage: () -> Unit,
    onStart: (String, QuickFlashSlotMode) -> Unit,
    onCancelActiveOperation: () -> Unit,
) {
    // Destructive target selection is deliberate: never prefill a partition name.
    var partition by rememberSaveable { mutableStateOf("") }
    var slotModeName by rememberSaveable { mutableStateOf(QuickFlashSlotMode.CURRENT.name) }
    var showConfirmation by rememberSaveable { mutableStateOf(false) }
    val slotMode = runCatching { QuickFlashSlotMode.valueOf(slotModeName) }
        .getOrDefault(QuickFlashSlotMode.CURRENT)
    val fastboot = observation.fastbootTransport
    val active = operationObservation.active
    val activeFlash = active?.takeIf { it.kind == OperationCoordinator.Kind.FASTBOOT_FLASH }
    val unlockState = fastboot.unlocked.toObservedBoolean()
    val partitionValid = PARTITION_PATTERN.matches(partition.trim())
    val withinProtocolLimit = payload?.sizeBytes?.let { it in 1..PROTOCOL_MAX_DOWNLOAD_BYTES } ?: false
    val deviceLimit = fastboot.maxDownloadSizeBytes?.takeIf { it > 0L }
    val deviceLimitKnown = deviceLimit != null
    val withinDeviceLimit = payload?.sizeBytes?.let { size ->
        deviceLimit?.let { size <= it } ?: false
    } ?: false
    val canReview = payload != null &&
        !payloadPreparing &&
        active == null &&
        fastboot.status == FastbootTransportObservation.Status.CONNECTED &&
        unlockState == true &&
        partitionValid &&
        withinProtocolLimit &&
        deviceLimitKnown &&
        withinDeviceLimit

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(NekoFlashSpacing.section),
            verticalArrangement = Arrangement.spacedBy(NekoFlashSpacing.inline),
        ) {
            Text(
                text = stringResource(R.string.quick_flash_title),
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                text = stringResource(R.string.quick_flash_description),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (activeFlash == null) {
                OutlinedButton(
                    onClick = onChooseImage,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = active == null && !payloadPreparing,
                ) {
                    Text(
                        text = stringResource(
                            if (payloadPreparing) R.string.quick_flash_image_preparing else R.string.quick_flash_choose_image,
                        ),
                    )
                }
                if (payload != null) {
                    Text(
                        text = stringResource(
                            R.string.quick_flash_selected_image,
                            payload.displayName,
                            formatBytes(payload.sizeBytes),
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    TextButton(onClick = onClearImage, enabled = active == null) {
                        Text(text = stringResource(R.string.quick_flash_clear_image))
                    }
                }

                OutlinedTextField(
                    value = partition,
                    onValueChange = { partition = it.take(128) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = active == null,
                    singleLine = true,
                    label = { Text(stringResource(R.string.quick_flash_partition)) },
                    supportingText = {
                        if (!partitionValid) {
                            Text(stringResource(R.string.quick_flash_partition_invalid))
                        }
                    },
                )

                Text(
                    text = stringResource(R.string.quick_flash_slot_mode),
                    style = MaterialTheme.typography.labelLarge,
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(NekoFlashSpacing.inline),
                ) {
                    Row(modifier = Modifier.weight(1f)) {
                        RadioButton(
                            selected = slotMode == QuickFlashSlotMode.CURRENT,
                            onClick = { slotModeName = QuickFlashSlotMode.CURRENT.name },
                            enabled = active == null,
                        )
                        Text(
                            text = stringResource(R.string.quick_flash_slot_current),
                            modifier = Modifier.padding(top = NekoFlashSpacing.inline),
                        )
                    }
                    Row(modifier = Modifier.weight(1f)) {
                        RadioButton(
                            selected = slotMode == QuickFlashSlotMode.EXACT,
                            onClick = { slotModeName = QuickFlashSlotMode.EXACT.name },
                            enabled = active == null,
                        )
                        Text(
                            text = stringResource(R.string.quick_flash_slot_exact),
                            modifier = Modifier.padding(top = NekoFlashSpacing.inline),
                        )
                    }
                }
                Text(
                    text = if (slotMode == QuickFlashSlotMode.CURRENT) {
                        stringResource(
                            R.string.quick_flash_slot_current_detail,
                            fastboot.currentSlot ?: stringResource(R.string.quick_flash_unknown),
                        )
                    } else {
                        stringResource(R.string.quick_flash_slot_exact_detail)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                val safetyText = when (unlockState) {
                    true -> stringResource(R.string.quick_flash_unlock_ok)
                    false -> stringResource(R.string.quick_flash_unlock_locked)
                    null -> stringResource(R.string.quick_flash_unlock_unknown)
                }
                Text(
                    text = safetyText,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (unlockState == true) {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    } else {
                        MaterialTheme.colorScheme.error
                    },
                )
                if (!withinProtocolLimit && payload != null) {
                    Text(
                        text = stringResource(R.string.quick_flash_payload_protocol_too_large),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                } else if (!deviceLimitKnown && payload != null) {
                    Text(
                        text = stringResource(R.string.quick_flash_payload_device_limit_unknown),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                } else if (!withinDeviceLimit && payload != null) {
                    Text(
                        text = stringResource(
                            R.string.quick_flash_payload_device_too_large,
                            formatBytes(deviceLimit ?: 0L),
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }

                OutlinedButton(
                    onClick = { showConfirmation = true },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = canReview,
                ) {
                    Text(text = stringResource(R.string.quick_flash_review_button))
                }
            } else {
                QuickFlashProgress(
                    active = activeFlash,
                    onCancel = onCancelActiveOperation,
                )
            }

            if (message != null) {
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (activeFlash == null) {
                operationObservation.lastCompleted
                    ?.takeIf { it.kind == OperationCoordinator.Kind.FASTBOOT_FLASH }
                    ?.let { completed ->
                        Text(
                            text = completedQuickFlashLabel(completed),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
            }
        }
    }

    if (showConfirmation && payload != null) {
        AlertDialog(
            onDismissRequest = { showConfirmation = false },
            title = { Text(stringResource(R.string.quick_flash_confirm_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(NekoFlashSpacing.inline)) {
                    Text(
                        stringResource(
                            R.string.quick_flash_confirm_summary,
                            payload.displayName,
                            formatBytes(payload.sizeBytes),
                            partition.trim(),
                            if (slotMode == QuickFlashSlotMode.CURRENT) {
                                stringResource(R.string.quick_flash_slot_current)
                            } else {
                                stringResource(R.string.quick_flash_slot_exact)
                            },
                        ),
                    )
                    Text(
                        text = stringResource(R.string.quick_flash_confirm_warning),
                        color = MaterialTheme.colorScheme.error,
                    )
                    Text(
                        text = stringResource(R.string.quick_flash_confirm_safety),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmation = false
                        onStart(partition, slotMode)
                    },
                    enabled = canReview,
                ) {
                    Text(stringResource(R.string.quick_flash_confirm_flash))
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmation = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}

@Composable
private fun QuickFlashProgress(
    active: OperationCoordinator.ActiveOperation,
    onCancel: () -> Unit,
) {
    Text(
        text = stringResource(R.string.quick_flash_active, active.metadata.partition ?: "?"),
        style = MaterialTheme.typography.titleSmall,
    )
    Text(
        text = active.stage.localizedFlashStage(),
        style = MaterialTheme.typography.bodyMedium,
    )
    active.progress?.let { progress ->
        LinearProgressIndicator(
            progress = { progress.percent / 100f },
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text = stringResource(
                R.string.quick_flash_progress,
                progress.percent,
                formatBytes(progress.confirmedBytes),
                formatBytes(progress.totalBytes),
                formatRate(progress.averageBytesPerSecond),
                formatEta(progress.etaMs),
            ),
            style = MaterialTheme.typography.bodySmall,
        )
    }
    Text(
        text = stringResource(R.string.quick_flash_progress_not_success),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    OutlinedButton(
        onClick = onCancel,
        modifier = Modifier.fillMaxWidth(),
        enabled = active.stage != OperationCoordinator.Stage.WRITING &&
            active.stage != OperationCoordinator.Stage.FINALIZING &&
            !active.cancellationRequested,
    ) {
        Text(
            text = stringResource(
                if (active.cancellationRequested) R.string.quick_flash_cancelling else R.string.quick_flash_cancel,
            ),
        )
    }
}

@Composable
private fun completedQuickFlashLabel(completed: OperationCoordinator.CompletedOperation): String {
    val base = stringResource(
        when (completed.outcome) {
            OperationCoordinator.Outcome.SUCCEEDED -> R.string.quick_flash_last_succeeded
            OperationCoordinator.Outcome.FAILED -> R.string.quick_flash_last_failed
            OperationCoordinator.Outcome.ABORTED -> R.string.quick_flash_last_aborted
            OperationCoordinator.Outcome.VERIFICATION_PENDING -> R.string.operation_status_last_verification_pending
        },
    )
    return completed.message?.takeIf { it.isNotBlank() }?.let { "$base · $it" } ?: base
}

@Composable
private fun OperationCoordinator.Stage.localizedFlashStage(): String = stringResource(
    when (this) {
        OperationCoordinator.Stage.STARTING -> R.string.quick_flash_stage_starting
        OperationCoordinator.Stage.RUNNING -> R.string.quick_flash_stage_running
        OperationCoordinator.Stage.AUTHORIZING -> R.string.quick_flash_stage_authorizing
        OperationCoordinator.Stage.TRANSFERRING -> R.string.quick_flash_stage_transferring
        OperationCoordinator.Stage.WRITING -> R.string.quick_flash_stage_writing
        OperationCoordinator.Stage.FINALIZING -> R.string.quick_flash_stage_finalizing
        OperationCoordinator.Stage.CANCELLING -> R.string.quick_flash_stage_cancelling
    },
)

@Composable
private fun UsbCandidateChooserDialog(
    candidates: List<UsbCandidateSummary>,
    onChosen: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = stringResource(R.string.usb_choose_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(NekoFlashSpacing.inline)) {
                candidates.forEach { candidate ->
                    TextButton(
                        onClick = { onChosen(candidate.stableKey) },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(text = candidate.deviceLabel)
                            Text(
                                text = stringResource(
                                    R.string.usb_candidate_details,
                                    candidate.mode.localizedLabel(),
                                    candidate.interfaceIndex,
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.action_cancel))
            }
        },
    )
}

@Composable
private fun GenericFastbootConfirmationDialog(
    candidate: UsbCandidateSummary,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = stringResource(R.string.usb_generic_fastboot_title)) },
        text = {
            Text(
                text = stringResource(
                    R.string.usb_generic_fastboot_message,
                    candidate.deviceLabel,
                    candidate.interfaceIndex,
                ),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(candidate.stableKey) }) {
                Text(text = stringResource(R.string.action_continue))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.action_cancel))
            }
        },
    )
}

@Composable
private fun UsbObservedMode.localizedLabel(): String = when (this) {
    UsbObservedMode.ADB -> stringResource(R.string.usb_mode_adb)
    UsbObservedMode.FASTBOOT -> stringResource(R.string.usb_mode_fastboot)
}

@Composable
private fun UsbSessionObservation.Status.localizedLabel(): String = stringResource(
    when (this) {
        UsbSessionObservation.Status.INACTIVE -> R.string.usb_status_inactive
        UsbSessionObservation.Status.SCANNING -> R.string.usb_status_scanning
        UsbSessionObservation.Status.NO_DEVICE -> R.string.usb_status_not_detected
        UsbSessionObservation.Status.UNSUPPORTED_DEVICE -> R.string.usb_status_unsupported
        UsbSessionObservation.Status.MULTIPLE_CANDIDATES -> R.string.usb_status_multiple
        UsbSessionObservation.Status.PERMISSION_PENDING -> R.string.usb_status_permission_pending
        UsbSessionObservation.Status.PERMISSION_DENIED -> R.string.usb_status_permission_denied
        UsbSessionObservation.Status.PERMISSION_ERROR -> R.string.usb_status_permission_error
        UsbSessionObservation.Status.CANDIDATE_READY -> R.string.usb_status_detected
    },
)

@Composable
private fun AdbTransportObservation.localizedLabel(): String = when (status) {
    AdbTransportObservation.Status.INACTIVE -> stringResource(R.string.adb_status_inactive)
    AdbTransportObservation.Status.CONNECTING -> stringResource(R.string.adb_status_connecting)
    AdbTransportObservation.Status.AUTHORIZING -> stringResource(R.string.adb_status_authorizing)
    AdbTransportObservation.Status.ERROR -> stringResource(R.string.adb_status_error)
    AdbTransportObservation.Status.CONNECTED -> stringResource(
        R.string.adb_status_connected,
        peerMode.localizedLabel(),
    )
}

@Composable
private fun AdbObservedPeerMode?.localizedLabel(): String = when (this) {
    AdbObservedPeerMode.DEVICE -> stringResource(R.string.adb_peer_device)
    AdbObservedPeerMode.RECOVERY -> stringResource(R.string.adb_peer_recovery)
    AdbObservedPeerMode.SIDELOAD -> stringResource(R.string.adb_peer_sideload)
    AdbObservedPeerMode.UNKNOWN, null -> stringResource(R.string.adb_peer_unknown)
}

@Composable
private fun FastbootTransportObservation.localizedLabel(): String = when (status) {
    FastbootTransportObservation.Status.INACTIVE -> stringResource(R.string.fastboot_status_inactive)
    FastbootTransportObservation.Status.CONNECTING -> stringResource(R.string.fastboot_status_connecting)
    FastbootTransportObservation.Status.ERROR -> stringResource(R.string.fastboot_status_error)
    FastbootTransportObservation.Status.CONNECTED -> if (product.isNullOrBlank()) {
        stringResource(R.string.fastboot_status_connected_peer)
    } else {
        stringResource(R.string.fastboot_status_connected_product, product)
    }
}

@Composable
private fun OperationCoordinator.Observation.localizedLabel(): String {
    val activeOperation = active
    if (activeOperation != null) {
        return when (activeOperation.kind) {
            OperationCoordinator.Kind.FASTBOOT_FLASH -> activeOperation.stage.localizedFlashStage()
            OperationCoordinator.Kind.ADB_SIDELOAD -> activeOperation.stage.localizedSideloadStage()
            OperationCoordinator.Kind.FASTBOOT_DIAGNOSTIC_REFRESH -> stringResource(
                when (activeOperation.stage) {
                    OperationCoordinator.Stage.STARTING -> R.string.operation_status_fastboot_refresh_starting
                    OperationCoordinator.Stage.FINALIZING -> R.string.operation_status_fastboot_refresh_finalizing
                    OperationCoordinator.Stage.CANCELLING -> R.string.operation_status_cancelling
                    OperationCoordinator.Stage.RUNNING,
                    OperationCoordinator.Stage.AUTHORIZING,
                    OperationCoordinator.Stage.TRANSFERRING,
                    OperationCoordinator.Stage.WRITING,
                    -> R.string.operation_status_fastboot_refresh_running
                },
            )
        }
    }

    return stringResource(
        when (lastCompleted?.outcome) {
            OperationCoordinator.Outcome.SUCCEEDED -> R.string.operation_status_last_succeeded
            OperationCoordinator.Outcome.FAILED -> R.string.operation_status_last_failed
            OperationCoordinator.Outcome.ABORTED -> R.string.operation_status_last_aborted
            OperationCoordinator.Outcome.VERIFICATION_PENDING -> R.string.operation_status_last_verification_pending
            null -> R.string.operation_status_idle
        },
    )
}

private fun String?.toObservedBoolean(): Boolean? = when (this?.trim()?.lowercase(Locale.US)) {
    "yes", "true", "1" -> true
    "no", "false", "0" -> false
    else -> null
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val units = arrayOf("KiB", "MiB", "GiB", "TiB")
    var value = bytes.toDouble()
    var unitIndex = -1
    while (value >= 1024.0 && unitIndex < units.lastIndex) {
        value /= 1024.0
        unitIndex++
    }
    return String.format(Locale.US, "%.2f %s", value, units[unitIndex])
}

private fun formatRate(bytesPerSecond: Double): String = if (bytesPerSecond <= 0.0) {
    "—"
} else {
    "${formatBytes(bytesPerSecond.toLong())}/s"
}

private fun formatEta(etaMs: Long?): String = when {
    etaMs == null -> "—"
    etaMs < 1000L -> "<1s"
    else -> "${(etaMs + 999L) / 1000L}s"
}

private val PARTITION_PATTERN = Regex("^[A-Za-z0-9._:-]{1,128}$")
private const val PROTOCOL_MAX_DOWNLOAD_BYTES = 0xFFFF_FFFFL
