package ru.forum.adbfastboottool

import android.app.Activity
import android.content.res.ColorStateList
import android.view.View
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

/**
 * Управление переключением вкладок/страниц главного экрана.
 *
 * Вынесено из MainActivity (декомпозиция God-object): это чистая UI-логика,
 * не зависящая от состояния USB/прошивки — только показ/скрытие страниц
 * и подсветка кнопок-табов.
 *
 * Состояние:
 *  - [selectedWindow] — текущая видимая страница (home/fastboot/adb/unlock/settings);
 *  - [commandContext] — контекст для ручного ввода команд (adb/fastboot).
 *    Меняется только при входе в ADB/Fastboot-воркфлоу, не сбрасывается
 *    сервисным экраном settings. Console является persistent Bottom Sheet
 *    и не участвует в маршрутизации страниц.
 */
class TabController(private val activity: Activity) {

    var selectedWindow: String = "home"
        private set

    var commandContext: String = "fastboot"
        private set

    /** Страница (контент) для каждого таба. */
    private val pages = mapOf(
        "home" to R.id.pageHome,
        "fastboot" to R.id.containerFastboot,
        "adb" to R.id.containerAdb,
        "unlock" to R.id.pageUnlock,
        "settings" to R.id.pageSettings
    )

    /** Кнопки нижней навигации (5 табов с иконками). */
    private val tabButtons = mapOf(
        "home" to R.id.tabHome,
        "fastboot" to R.id.tabFastboot,
        "adb" to R.id.tabAdb,
        "unlock" to R.id.tabUnlock,
        "settings" to R.id.tabSettings
    )

    /** Переключение на одну из полноразмерных страниц [tab]. */
    fun switchTab(tab: String) {
        require(tab in pages) { "Unknown page: $tab" }
        val targetTab = tab
        selectedWindow = targetTab

        // Контекст команды меняется только при входе в ADB/Fastboot-воркфлоу.
        if (targetTab == "adb" || targetTab == "fastboot") {
            commandContext = targetTab
        }

        pages.forEach { (key, viewId) ->
            activity.findViewById<View>(viewId).visibility =
                if (key == targetTab) View.VISIBLE else View.GONE
        }

        tabButtons.forEach { (key, buttonId) ->
            val button = activity.findViewById<MaterialButton>(buttonId)
            val selected = key == targetTab
            button.alpha = if (selected) 1.0f else 0.7f
            button.setTextColor(
                ContextCompat.getColor(
                    activity,
                    if (selected) R.color.accent else R.color.text_muted
                )
            )
            button.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(
                    activity,
                    if (selected) R.color.bg_elevated else R.color.bg_header
                )
            )
        }
    }

}
