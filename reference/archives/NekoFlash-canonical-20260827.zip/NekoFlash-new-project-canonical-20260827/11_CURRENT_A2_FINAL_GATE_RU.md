# NekoFlash-A2 — Final Gate Before Freeze

Этот документ существует только чтобы не потерять **последнее полезное аппаратное доказательство** перед переходом в новый repository.

## Build

`a2479b333ee2f25b0bc86a530d948c48a3423a68`

## Target

Stable reference device: `vayu`.

`onyx` / POCO F7 / Redmi Turbo 4 Pro не использовать как reference gate.

## Процедура

1. Установить APK из `a2479b3...`.
2. Загрузить `vayu` в обычный Recovery.
3. **Не входить в ADB Sideload.**
4. Подключить к NekoFlash.
5. Оставить примерно на 10 секунд.
6. Экспортировать diagnostics ZIP.
7. Проанализировать ZIP до любых дальнейших Sideload тестов.

## PASS

Большой `/tmp/recovery.log` (>32768 bytes) должен быть прочитан полностью и baseline сохранён, с evidence эквивалентным:

`ADB_SIDELOAD_RECOVERY_BASELINE_CAPTURED ... persisted=true`

Не должно повториться:

`ADB_READER_FAILED ... after 32768/<larger size> bytes`

## После PASS

- сохранить diagnostics как historical A2 evidence;
- freeze/tag A2;
- при желании отдельно закончить уже запланированный normal Sideload correlation evidence, **только если это нужно как переносимое доказательство**, но не строить новые A2 product features;
- начать новый NekoFlash repository.

## После FAIL

- не начинать новый A2 roadmap;
- локализовать только lower-layer framing root cause;
- минимальный фикс;
- CI;
- повтор этого gate;
- после доказательства freeze.
