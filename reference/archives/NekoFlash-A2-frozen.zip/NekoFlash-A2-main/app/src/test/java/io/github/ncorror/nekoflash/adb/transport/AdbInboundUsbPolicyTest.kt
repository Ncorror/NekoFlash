package io.github.ncorror.nekoflash.adb.transport

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AdbInboundUsbPolicyTest {
    @Test
    fun `pre P host advertises one legacy usbfs receive buffer`() {
        assertEquals(
            16 * 1024,
            AdbInboundUsbPolicy.advertisedMaxPayload(apiLevel = 27),
        )
    }

    @Test
    fun `P and newer hosts may advertise modern adb payload`() {
        assertEquals(
            1_048_576,
            AdbInboundUsbPolicy.advertisedMaxPayload(apiLevel = 28),
        )
        assertEquals(
            1_048_576,
            AdbInboundUsbPolicy.advertisedMaxPayload(apiLevel = 36),
        )
    }

    @Test
    fun `payload usb transfer must complete in exactly one receive transfer`() {
        assertTrue(AdbInboundUsbPolicy.payloadReadIsComplete(expectedBytes = 53_283, actualBytes = 53_283))
        assertFalse(AdbInboundUsbPolicy.payloadReadIsComplete(expectedBytes = 53_283, actualBytes = 32_768))
        assertFalse(AdbInboundUsbPolicy.payloadReadIsComplete(expectedBytes = 53_283, actualBytes = -1))
    }
}
