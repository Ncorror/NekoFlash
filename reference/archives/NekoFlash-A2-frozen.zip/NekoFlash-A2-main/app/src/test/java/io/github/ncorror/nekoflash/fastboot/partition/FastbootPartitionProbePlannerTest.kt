package io.github.ncorror.nekoflash.fastboot.partition

import io.github.ncorror.nekoflash.fastboot.codec.FastbootGetVarAllParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FastbootPartitionProbePlannerTest {
    @Test
    fun `existing partition requests only missing metadata and unresolved slot binding`() {
        val source = FastbootGetVarAllParser.parse(listOf("INFOpartition-size:boot: 0x1000"))
        val inventory = FastbootPartitionInventoryBuilder.build(source)

        val plan = FastbootPartitionProbePlanner.plan(source, inventory)

        assertEquals(
            listOf(
                request("boot", FastbootGetVarAllParser.MetadataField.TYPE),
                request("boot", FastbootGetVarAllParser.MetadataField.LOGICAL),
                request("boot", FastbootGetVarAllParser.MetadataField.HAS_SLOT),
            ),
            plan.requests,
        )
        assertFalse(plan.discoveryFallbackUsed)
    }

    @Test
    fun `planner returns every deterministic request instead of applying a query budget`() {
        val source = FastbootGetVarAllParser.parse(
            buildList {
                add("INFOproduct: vayu")
                repeat(20) { index -> add("INFOpartition-size:p$index: 0x1000") }
            },
        )
        val inventory = FastbootPartitionInventoryBuilder.build(source)

        val plan = FastbootPartitionProbePlanner.plan(source, inventory)

        assertEquals(40, plan.requests.size)
        assertEquals(40, plan.requests.map { it.variableName }.distinct().size)
        assertFalse(plan.discoveryFallbackUsed)
    }

    @Test
    fun `discovery names are normalized validated deduplicated and all retained`() {
        val source = FastbootGetVarAllParser.parse(
            listOf(
                "INFOpartition-size:boot: 0x1000",
                "INFOpartition-type:boot: raw",
                "INFOis-logical:boot: no",
            ),
        )
        val inventory = FastbootPartitionInventoryBuilder.build(source)
        val plan = FastbootPartitionProbePlanner.plan(
            source = source,
            inventory = inventory,
            discoveryPartitions = listOf(" Vendor_Boot ", "../bad", "SUPER", "super", "bad name"),
        )

        val names = plan.requests.map { it.partition }.toSet()
        assertTrue("vendor_boot" in names)
        assertTrue("super" in names)
        assertFalse("../bad" in names)
        assertFalse("bad name" in names)
        assertEquals(plan.requests.size, plan.requests.distinct().size)
    }

    @Test
    fun `family positive slot metadata probes concrete a and b names`() {
        val source = FastbootGetVarAllParser.parse(
            listOf(
                "INFOslot-count: 2",
                "INFOhas-slot:boot: yes",
                "INFOpartition-size:vendor_boot_a: 0x1000",
                "INFOpartition-type:vendor_boot_a: raw",
                "INFOis-logical:vendor_boot_a: no",
            ),
        )
        val inventory = FastbootPartitionInventoryBuilder.build(source)
        val plan = FastbootPartitionProbePlanner.plan(source, inventory)
        val bootRequests = plan.requests.filter { it.partition.startsWith("boot") }

        assertEquals(setOf("boot_a", "boot_b"), bootRequests.map { it.partition }.toSet())
        assertTrue(bootRequests.none { it.field == FastbootGetVarAllParser.MetadataField.HAS_SLOT })
    }

    @Test
    fun `family negative slot metadata probes unsuffixed concrete name`() {
        val source = FastbootGetVarAllParser.parse(
            listOf(
                "INFOslot-count: 2",
                "INFOhas-slot:recovery: no",
                "INFOpartition-size:vendor_boot_a: 0x1000",
                "INFOpartition-type:vendor_boot_a: raw",
                "INFOis-logical:vendor_boot_a: no",
            ),
        )
        val inventory = FastbootPartitionInventoryBuilder.build(source)
        val plan = FastbootPartitionProbePlanner.plan(source, inventory)
        val recoveryRequests = plan.requests.filter { it.partition.startsWith("recovery") }

        assertEquals(setOf("recovery"), recoveryRequests.map { it.partition }.toSet())
        assertTrue(recoveryRequests.none { it.field == FastbootGetVarAllParser.MetadataField.HAS_SLOT })
    }

    @Test
    fun `empty unknown inventory uses the complete fallback request set`() {
        val source = FastbootGetVarAllParser.parse(emptyList())
        val inventory = FastbootPartitionInventoryBuilder.build(source)

        val plan = FastbootPartitionProbePlanner.plan(source, inventory)

        assertTrue(plan.discoveryFallbackUsed)
        assertEquals(32, plan.requests.size)
        assertEquals(
            setOf("boot", "init_boot", "vendor_boot", "vendor_kernel_boot", "recovery", "dtbo", "vbmeta", "super"),
            plan.requests.map { it.partition }.toSet(),
        )
    }

    @Test
    fun `a b fallback probes both concrete suffixes`() {
        val source = FastbootGetVarAllParser.parse(listOf("INFOslot-count: 2"))
        val inventory = FastbootPartitionInventoryBuilder.build(source)

        val plan = FastbootPartitionProbePlanner.plan(source, inventory)

        assertTrue(plan.discoveryFallbackUsed)
        assertEquals(48, plan.requests.size)
        assertTrue(plan.requests.all { it.partition.endsWith("_a") || it.partition.endsWith("_b") })
        assertTrue(plan.requests.none { it.field == FastbootGetVarAllParser.MetadataField.HAS_SLOT })
    }

    private fun request(
        partition: String,
        field: FastbootGetVarAllParser.MetadataField,
    ) = FastbootPartitionProbePlanner.Request(partition, field)
}
