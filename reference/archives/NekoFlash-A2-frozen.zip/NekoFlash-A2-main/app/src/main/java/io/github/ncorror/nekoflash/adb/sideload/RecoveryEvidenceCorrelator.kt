package io.github.ncorror.nekoflash.adb.sideload

import java.security.MessageDigest

/**
 * Correlates a post-Sideload Recovery log with a read-only baseline captured before Sideload.
 *
 * The baseline stores only the normalized prefix length and SHA-256, never the Recovery log itself.
 * A post-install verdict is eligible for [RecoveryInstallVerifier] only when /tmp/recovery.log still
 * begins with that exact prefix. Rotated, truncated or rewritten logs fail closed as UNKNOWN.
 */
internal object RecoveryEvidenceCorrelator {
    const val PRIMARY_PATH = "/tmp/recovery.log"

    data class Baseline(
        val path: String,
        val prefixCharacters: Int,
        val prefixSha256: String,
    ) {
        init {
            require(path == PRIMARY_PATH) { "Only $PRIMARY_PATH may be used as a Sideload baseline" }
            require(prefixCharacters >= 0) { "Baseline prefix length must not be negative" }
            require(SHA256_REGEX.matches(prefixSha256)) { "Baseline SHA-256 must be lowercase hex" }
        }
    }

    sealed interface Correlation {
        data class Correlated(
            val source: RecoveryInstallVerifier.LogSource,
            val appendedCharacters: Int,
            val diagnosticExcerpt: String,
        ) : Correlation

        data class Unavailable(
            val reason: String,
            val sourcePath: String? = null,
            val diagnosticExcerpt: String? = null,
        ) : Correlation
    }

    fun capture(source: RecoveryInstallVerifier.LogSource): Baseline {
        require(source.path == PRIMARY_PATH) { "Only $PRIMARY_PATH may be captured" }
        val normalized = normalize(source.text)
        return Baseline(
            path = PRIMARY_PATH,
            prefixCharacters = normalized.length,
            prefixSha256 = sha256Hex(normalized),
        )
    }

    fun correlate(
        sources: List<RecoveryInstallVerifier.LogSource>,
        baseline: Baseline?,
    ): Correlation {
        val current = sources.firstOrNull { it.path == PRIMARY_PATH }
        if (baseline == null) {
            return Correlation.Unavailable(
                reason = "No pre-Sideload Recovery baseline is available; install result cannot be safely correlated",
                sourcePath = current?.path,
                diagnosticExcerpt = current?.text?.let(::diagnosticExcerpt),
            )
        }
        if (baseline.path != PRIMARY_PATH) {
            return Correlation.Unavailable("Unsupported Recovery baseline path: ${baseline.path}")
        }
        if (current == null) {
            return Correlation.Unavailable(
                reason = "$PRIMARY_PATH is unavailable after Sideload; install result remains unknown",
                sourcePath = PRIMARY_PATH,
            )
        }

        val normalized = normalize(current.text)
        if (normalized.length < baseline.prefixCharacters) {
            return Correlation.Unavailable(
                reason = "$PRIMARY_PATH was truncated or rotated after the baseline; refusing historical evidence",
                sourcePath = PRIMARY_PATH,
                diagnosticExcerpt = diagnosticExcerpt(normalized),
            )
        }

        val prefix = normalized.substring(0, baseline.prefixCharacters)
        if (sha256Hex(prefix) != baseline.prefixSha256) {
            return Correlation.Unavailable(
                reason = "$PRIMARY_PATH no longer extends the captured baseline; refusing uncorrelated evidence",
                sourcePath = PRIMARY_PATH,
                diagnosticExcerpt = diagnosticExcerpt(normalized),
            )
        }

        val appended = normalized.substring(baseline.prefixCharacters)
        if (appended.isBlank()) {
            return Correlation.Unavailable(
                reason = "$PRIMARY_PATH contains no new content after the pre-Sideload baseline",
                sourcePath = PRIMARY_PATH,
            )
        }
        val sideloadStart = SIDELOAD_SESSION_START_PATTERNS
            .flatMap { regex -> regex.findAll(appended).map { it.range.first }.toList() }
            .maxOrNull()
        if (sideloadStart == null) {
            return Correlation.Unavailable(
                reason = "New $PRIMARY_PATH content has no recognized ADB Sideload session marker",
                sourcePath = PRIMARY_PATH,
                diagnosticExcerpt = diagnosticExcerpt(appended),
            )
        }
        val currentSideload = appended.substring(sideloadStart)

        return Correlation.Correlated(
            source = RecoveryInstallVerifier.LogSource(PRIMARY_PATH, currentSideload),
            appendedCharacters = currentSideload.length,
            diagnosticExcerpt = diagnosticExcerpt(currentSideload),
        )
    }

    private fun normalize(text: String): String = text.replace("\r", "")

    private fun sha256Hex(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray(Charsets.UTF_8))
        .joinToString("") { byte -> "%02x".format(byte) }

    private fun diagnosticExcerpt(text: String): String {
        val meaningful = normalize(text)
            .lineSequence()
            .map(String::trim)
            .filter(String::isNotEmpty)
            .toList()
        if (meaningful.isEmpty()) return ""
        return meaningful.takeLast(DIAGNOSTIC_LINES)
            .joinToString(" | ")
            .take(DIAGNOSTIC_CHARACTERS)
    }


    private val SIDELOAD_SESSION_START_PATTERNS = listOf(
        Regex("""(?im)^\s*Starting ADB sideload"""),
        Regex("""(?im)^\s*Starting sideload"""),
        Regex("""(?im)^\s*I:operation_start:\s*['\"]Sideload['\"]\s*$"""),
    )

    private const val DIAGNOSTIC_LINES = 24
    private const val DIAGNOSTIC_CHARACTERS = 1_600
    private val SHA256_REGEX = Regex("^[0-9a-f]{64}$")
}
