package io.github.ncorror.nekoflash.fastboot.transport

/**
 * Core Fastboot variables collected for device status and transfer planning.
 * This is a diagnostic recipe, not a command allowlist: the transaction layer itself
 * is generic and owns only Fastboot wire/state correctness.
 */
internal object FastbootCoreDiagnosticsPlan {
    data class Variable(
        val name: String,
        val writeTimeoutMs: Int = GETVAR_WRITE_TIMEOUT_MS,
        val inactivityTimeoutMs: Int = GETVAR_INACTIVITY_TIMEOUT_MS,
        val sensitive: Boolean = false,
    ) {
        val command: String = "getvar:$name"

        fun valueForEvent(value: String?): String? = when {
            value == null -> null
            sensitive -> "<redacted>"
            else -> value
        }

        fun payloadForEvent(payload: String): String = when {
            sensitive && payload.isNotBlank() -> "<redacted>"
            else -> payload
        }
    }

    val variables: List<Variable> = listOf(
        Variable("current-slot"),
        Variable("slot-count"),
        Variable("unlocked"),
        Variable("max-download-size"),
    )

    fun parseFastbootSize(raw: String?): Long? {
        if (raw.isNullOrBlank()) return null
        val token = Regex("0x[0-9A-Fa-f]+|[0-9]+").find(raw)?.value ?: return null
        return try {
            if (token.startsWith("0x", ignoreCase = true)) {
                token.removePrefix("0x").removePrefix("0X").toLong(16)
            } else {
                token.toLong()
            }
        } catch (_: NumberFormatException) {
            null
        }
    }

    const val GETVAR_WRITE_TIMEOUT_MS = 5_000
    const val GETVAR_INACTIVITY_TIMEOUT_MS = 5_000
}

internal data class FastbootCoreDiagnostics(
    val currentSlot: String? = null,
    val slotCount: String? = null,
    val unlocked: String? = null,
    val maxDownloadSizeRaw: String? = null,
    val maxDownloadSizeBytes: Long? = null,
)

/** Collects one getvar value across INFO/TEXT frames and the final OKAY/FAIL frame. */
internal class FastbootGetVarResponseCollector(
    private val variableName: String,
) {
    private var latestInfoValue: String? = null

    fun onProgress(packet: FastbootPacket) {
        if (packet.type == "INFO" || packet.type == "TEXT") {
            FastbootGetVarValue.normalize(variableName, packet.payload)
                ?.let { latestInfoValue = it }
        }
    }

    fun finish(result: FastbootTransactionResult.Completed): Value = when (result.finalType) {
        "OKAY" -> {
            val direct = result.finalPayload
                .takeIf { it.isNotBlank() }
                ?.let { FastbootGetVarValue.normalize(variableName, it) }
            Value(
                value = direct ?: latestInfoValue,
                finalType = result.finalType,
                finalPayload = result.finalPayload,
            )
        }

        "FAIL" -> Value(
            value = null,
            finalType = result.finalType,
            finalPayload = result.finalPayload,
        )

        else -> Value(
            value = latestInfoValue,
            finalType = result.finalType,
            finalPayload = result.finalPayload,
        )
    }

    data class Value(
        val value: String?,
        val finalType: String,
        val finalPayload: String,
    )
}
