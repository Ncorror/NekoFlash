package io.github.ncorror.nekoflash.fastboot.transport

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FastbootCoreDiagnosticsTest {
    @Test
    fun `core diagnostic recipe keeps expected getvars`() {
        assertEquals(
            listOf(
                "getvar:current-slot",
                "getvar:slot-count",
                "getvar:unlocked",
                "getvar:max-download-size",
            ),
            FastbootCoreDiagnosticsPlan.variables.map { it.command },
        )
    }

    @Test
    fun `core diagnostic queries separate write and inactivity timing`() {
        assertEquals(5_000, FastbootCoreDiagnosticsPlan.GETVAR_WRITE_TIMEOUT_MS)
        assertEquals(5_000, FastbootCoreDiagnosticsPlan.GETVAR_INACTIVITY_TIMEOUT_MS)
        assertTrue(FastbootCoreDiagnosticsPlan.variables.all { it.writeTimeoutMs == 5_000 })
        assertTrue(FastbootCoreDiagnosticsPlan.variables.all { it.inactivityTimeoutMs == 5_000 })
    }

    @Test
    fun `direct OKAY yields normalized diagnostic value`() {
        val collector = FastbootGetVarResponseCollector("current-slot")
        val value = collector.finish(
            FastbootTransactionResult.Completed(
                finalType = "OKAY",
                finalPayload = "current-slot: a",
            ),
        )
        assertEquals("a", value.value)
        assertEquals("OKAY", value.finalType)
    }

    @Test
    fun `INFO value followed by empty OKAY yields latest diagnostic value`() {
        val collector = FastbootGetVarResponseCollector("unlocked")
        collector.onProgress(packet("INFOunlocked: yes"))
        val value = collector.finish(FastbootTransactionResult.Completed("OKAY", ""))
        assertEquals("yes", value.value)
    }

    @Test
    fun `terminal FAIL leaves diagnostic unreported without poisoning protocol state`() {
        val collector = FastbootGetVarResponseCollector("slot-count")
        collector.onProgress(packet("INFOslot-count: 2"))
        val value = collector.finish(
            FastbootTransactionResult.Completed("FAIL", "Variable not found"),
        )
        assertNull(value.value)
        assertEquals("FAIL", value.finalType)
    }

    @Test
    fun `max download size accepts hexadecimal and decimal representations`() {
        assertEquals(0x10000000L, FastbootCoreDiagnosticsPlan.parseFastbootSize("0x10000000"))
        assertEquals(268_435_456L, FastbootCoreDiagnosticsPlan.parseFastbootSize("268435456 bytes"))
        assertNull(FastbootCoreDiagnosticsPlan.parseFastbootSize("unknown"))
    }

    private fun packet(raw: String): FastbootPacket =
        FastbootPacketCodec.parse(raw.toByteArray(Charsets.US_ASCII))
}
