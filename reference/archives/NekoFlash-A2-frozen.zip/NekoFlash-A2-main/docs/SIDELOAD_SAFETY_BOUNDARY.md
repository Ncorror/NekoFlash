# ADB Sideload post-hardware safety boundary

Base commit for this corrective slice: `fdb27d156f8e7d37fcaff298e9552d031081bbd8`.

This slice is a safety correction derived from the first real Recovery Sideload hardware campaign.
It deliberately does **not** change Recovery verdict parsing and does **not** add device-specific
`onyx` handling. Those are separate follow-up concerns.

## Hardware finding that changed the contract

ADB Sideload is request-driven. Recovery may request the same 64 KiB block more than once, so the
host's cumulative acknowledged traffic can exceed the ZIP size. Therefore cumulative `servedBytes`
is diagnostic traffic, not unique package coverage.

More importantly, once the host attempts the first non-empty payload block, Recovery may already be
executing updater logic that changes partitions. At that point a host-side disconnect cannot prove
that the device stayed unchanged.

## Pinned cancellation boundary

- Before the first payload block is attempted on USB, cancellation is allowed.
- The first payload block is an atomic mutation boundary owned by `OperationCoordinator`.
- The operation advances to `WRITING` immediately before that first payload WRTE.
- `OperationCoordinator.requestCancellation()` already rejects cancellation in `WRITING` and
  `FINALIZING`; the Sideload UI mirrors this by disabling its cancel action.
- If cancellation wins the race before `WRITING`, no payload block is sent and the result may be
  terminal `ABORTED` after cleanup.
- After `WRITING`, there is no normal user cancellation path.

## Interruption semantics after payload start

After the mutation boundary, all ambiguous stream loss is verification-pending:

- USB detach;
- dispatcher/transport failure;
- protocol close before `DONEDONE`;
- payload source/protocol failure after earlier payload blocks were already sent.

These outcomes are never downgraded to ordinary `FAILED` or `ABORTED` solely from the host view.
They become `VERIFICATION_PENDING`, because only fresh Recovery evidence can resolve the install
result.

The old >=95% close distinction is retained only as a diagnostic compatibility label. It now uses
**unique acknowledged payload bytes**, never cumulative served traffic. A post-payload close below
95% is still verification-pending as `TransferInterruptedAfterPayload`.

## Unique-block progress

`SideloadStreamSession` now tracks both:

- cumulative `servedBytes` for diagnostics/throughput evidence;
- `confirmedUniqueBytes` and unique block numbers for progress/safety coverage.

Duplicate Recovery requests increase `servedBytes` but do not advance the UI percentage or the 95%
coverage distinction.

## Retired ADB generation / physical reconnect

A Sideload transport generation is retired after:

- safe pre-payload cancellation; or
- any terminal result that requires Recovery verification.

The same physical ADB candidate is quarantined from manual/automatic reopen until Android reports a
real `USB_DEVICE_DETACHED` event. This prevents stale Sideload packets/stream IDs from being mistaken
for a fresh Recovery ADB generation.

A real detach clears the quarantine. A subsequent attach creates a normal new transport generation
and can be used for fixed read-only Recovery verification.

## Explicitly out of scope

This slice does not:

- expand `RecoveryInstallVerifier` patterns;
- add baseline/delta Recovery log correlation;
- add POCO F7 / `onyx` runtime blocking;
- claim install success from `DONEDONE`, 100% transfer, or connection close.

The next code slice after green CI is Recovery verification correlation/baseline work.
