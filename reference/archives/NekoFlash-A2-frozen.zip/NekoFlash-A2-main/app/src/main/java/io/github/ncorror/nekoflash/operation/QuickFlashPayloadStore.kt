package io.github.ncorror.nekoflash.operation

import android.content.ContentResolver
import android.database.Cursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import io.github.ncorror.nekoflash.fastboot.transport.FastbootDataSource
import java.io.FilterInputStream
import java.io.InputStream

/**
 * Application-scoped owner of the single SAF image selected for Quick Flash.
 *
 * The source descriptor is opened once and held outside Activity lifetime. Ownership is handed to
 * the operation atomically; the operation then closes it in all terminal paths. No broad storage
 * permission and no multi-gigabyte private-file copy are required.
 */
class QuickFlashPayloadStore(
    private val contentResolver: ContentResolver,
) {
    data class Snapshot(
        val displayName: String,
        val sizeBytes: Long,
    )

    internal class Payload internal constructor(
        val displayName: String,
        override val sizeBytes: Long,
        descriptor: ParcelFileDescriptor,
    ) : FastbootDataSource, AutoCloseable {
        private val lock = Any()
        private var descriptor: ParcelFileDescriptor? = descriptor
        private var activeStream: InputStream? = null

        override fun openNativeReadDescriptor(): ParcelFileDescriptor? = synchronized(lock) {
            val owned = descriptor ?: return@synchronized null
            runCatching { ParcelFileDescriptor.dup(owned.fileDescriptor) }.getOrNull()
        }

        override fun openInputStream(): InputStream = synchronized(lock) {
            val owned = descriptor ?: error("Quick Flash payload descriptor is no longer available")
            descriptor = null
            lateinit var tracked: InputStream
            tracked = object : FilterInputStream(ParcelFileDescriptor.AutoCloseInputStream(owned)) {
                override fun close() {
                    try {
                        super.close()
                    } finally {
                        synchronized(lock) {
                            if (activeStream === tracked) activeStream = null
                        }
                    }
                }
            }
            activeStream = tracked
            tracked
        }

        override fun cancel() {
            close()
        }

        override fun close() {
            val (ownedDescriptor, ownedStream) = synchronized(lock) {
                val descriptorToClose = descriptor
                val streamToClose = activeStream
                descriptor = null
                activeStream = null
                descriptorToClose to streamToClose
            }
            runCatching { ownedStream?.close() }
            runCatching { ownedDescriptor?.close() }
        }
    }

    private val lock = Any()
    private var selected: Payload? = null
    private var selectionGeneration = 0L
    private var listenerGeneration = 0L
    private var snapshotListener: ((Snapshot?) -> Unit)? = null

    fun currentSnapshot(): Snapshot? = synchronized(lock) { selected?.snapshot() }

    /** Replaces the Activity observer without transferring payload ownership out of the store. */
    fun replaceSnapshotListener(listener: (Snapshot?) -> Unit): Long {
        val generation: Long
        val snapshot: Snapshot?
        synchronized(lock) {
            generation = ++listenerGeneration
            snapshotListener = listener
            snapshot = selected?.snapshot()
        }
        listener(snapshot)
        return generation
    }

    fun clearSnapshotListener(generation: Long) {
        synchronized(lock) {
            if (listenerGeneration == generation) snapshotListener = null
        }
    }

    /** Replaces the current image only after the new descriptor and exact size are valid. */
    fun replaceFromUri(uri: Uri): Result<Snapshot> = runCatching {
        require(uri.scheme == ContentResolver.SCHEME_CONTENT) { "Only content:// documents are supported" }
        val generation = synchronized(lock) { ++selectionGeneration }
        val descriptor = contentResolver.openFileDescriptor(uri, "r")
            ?: error("Document provider returned no file descriptor")
        try {
            val metadata = queryMetadata(uri)
            val size = descriptor.statSize.takeIf { it > 0L }
                ?: error("Selected image does not expose a stable descriptor size")
            val displayName = metadata.displayName
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
                ?.take(MAX_DISPLAY_NAME_CHARS)
                ?: DEFAULT_DISPLAY_NAME
            val payload = Payload(displayName = displayName, sizeBytes = size, descriptor = descriptor)
            val snapshot = payload.snapshot()
            val previous: Payload?
            val listener: ((Snapshot?) -> Unit)?
            synchronized(lock) {
                check(generation == selectionGeneration) { "Image selection was superseded or cleared" }
                previous = selected
                selected = payload
                listener = snapshotListener
            }
            previous?.close()
            listener?.invoke(snapshot)
            snapshot
        } catch (error: Throwable) {
            runCatching { descriptor.close() }
            throw error
        }
    }

    /** Transfers ownership to the caller. A taken payload is no longer retained as UI draft. */
    internal fun take(): Payload? {
        val payload: Payload?
        val listener: ((Snapshot?) -> Unit)?
        synchronized(lock) {
            selectionGeneration++
            payload = selected
            selected = null
            listener = snapshotListener
        }
        listener?.invoke(null)
        return payload
    }

    fun clear() {
        val previous: Payload?
        val listener: ((Snapshot?) -> Unit)?
        synchronized(lock) {
            selectionGeneration++
            previous = selected
            selected = null
            listener = snapshotListener
        }
        previous?.close()
        listener?.invoke(null)
    }

    private fun Payload.snapshot(): Snapshot = Snapshot(displayName = displayName, sizeBytes = sizeBytes)

    private data class Metadata(
        val displayName: String?,
    )

    private fun queryMetadata(uri: Uri): Metadata {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null,
            )
            val found = cursor ?: return Metadata(null)
            if (!found.moveToFirst()) return Metadata(null)
            val nameIndex = found.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            Metadata(
                displayName = if (nameIndex >= 0 && !found.isNull(nameIndex)) found.getString(nameIndex) else null,
            )
        } catch (_: RuntimeException) {
            Metadata(null)
        } finally {
            runCatching { cursor?.close() }
        }
    }

    private companion object {
        const val MAX_DISPLAY_NAME_CHARS = 256
        const val DEFAULT_DISPLAY_NAME = "image.bin"
    }
}
