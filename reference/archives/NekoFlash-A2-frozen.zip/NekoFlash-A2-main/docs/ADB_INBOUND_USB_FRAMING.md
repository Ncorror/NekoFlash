# ADB device-to-host USB framing

## Why this exists

Hardware Recovery verification exposed a deterministic transport failure while reading large
`/tmp/recovery.log` output. The ADB header declared payloads around 50-65 KiB, while the previous
host implementation split each declared ADB payload into repeated 16 KiB `bulkTransfer()` reads.
On hardware this repeatedly failed after exactly 32768 bytes and retired the ADB transport before
a pre-Sideload Recovery baseline could be captured.

The problem is below Recovery correlation and below the OrangeFox verdict parser.

## Contract

ADB aprotocol device-to-host framing is treated as two USB transfers:

1. one 24-byte aprotocol header transfer;
2. one payload transfer whose expected size is declared by that header.

After the payload size is known, NekoFlash arms **one USB IN transfer for the complete payload**.
A positive short read is not continued with another USB read: a short USB transfer ended, so the
aprotocol byte stream can no longer be trusted and the generation fails closed.

This follows the AOSP host-side framing model. Splitting one device-to-host payload into arbitrary
smaller host IRPs is not a valid stream abstraction for this layer.

## Android API 26/27 compatibility

The public Android USB Host APIs before API 28 limit one USB request to 16 KiB. NekoFlash supports
API 26+, so hosts below API 28 advertise `maxdata=16384` in ADB `CNXN`. A peer must not send a WRTE
payload larger than the maxdata advertised by the receiver.

On API 28+ NekoFlash advertises 1 MiB and reads each declared payload in one receive transfer.

## Hardware gate

The next vayu Recovery gate must first prove that a large `/tmp/recovery.log` (>32 KiB) is read
without `ADB_READER_FAILED`, and that `ADB_SIDELOAD_RECOVERY_BASELINE_CAPTURED` is persisted.
Only then should another real Sideload be started.
