# Stage 6D2 — operation stage and terminal-result observation

Stage 6D2 extends the already hardware-proven single-operation ownership model without
changing USB or Fastboot wire behavior.

## Scope

The only admitted operation remains:

`FASTBOOT_READ_ONLY_REFRESH`

The existing wire sequence remains unchanged:

`manual getvar:all -> local inventory -> maximum-24 legacy metadata backfill`

Stage 6D2 adds an Application-scoped operation stage contract:

- `STARTING` — the operation lease is admitted but executor work has not yet taken
  ownership of the current Fastboot generation;
- `RUNNING` — the executor verified that the same Fastboot transport/generation is
  still owned and the existing read-only refresh is running;
- `FINALIZING` — protocol work has returned and the operation is publishing its terminal
  result/cleanup state.

The stage can move only forward for the current lease. A stale lease cannot mutate a
newer operation, and a stage cannot move backwards.

## Home result visibility

While an operation is active, Home reports its current stage. When there is no active
operation, Home reports the last terminal result if one exists:

- `SUCCEEDED`;
- `FAILED`;
- `ABORTED`.

This does not equate progress or protocol completion with success. The terminal outcome
is still published separately only after the operation finishes.

## Diagnostics

Stage changes are exported only as privacy-safe operation facts:

- operation generation;
- operation kind;
- stage;
- transport generation;
- whether the generation-safe stage update was accepted.

No raw Fastboot value, serial, partition payload, or broad `getvar:all` payload is added
to operation diagnostics.

## Protected invariants

Stage 6D2 must preserve all proven 6D1 behavior:

- exactly one active operation slot;
- no new Fastboot command;
- no automatic `getvar:all`;
- maximum 24 planner-generated metadata point queries after an explicit manual refresh;
- no hidden retry/reopen loop;
- detach/failure still reaches a terminal operation outcome;
- protocol ownership remains in `UsbSessionCoordinator`/Fastboot transport;
- UI observes operation state but never owns USB or protocol objects.

## Deliberately deferred

Stage 6D2 does not implement:

- user cancellation;
- operation-owned UI-exit/re-enumeration lifetime leases;
- byte-level transfer progress;
- foreground service / wake lock;
- DATA/download;
- flash, erase, set_active, reboot;
- OEM/unlock;
- generic Fastboot or ADB command entry.

These remain later evidence-focused slices. Cancellation in particular must preserve the
legacy rule that a cancellation request is not reported as terminally cancelled until
blocking USB/native cleanup has actually finished.
