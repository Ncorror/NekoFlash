package io.github.ncorror.nekoflash.adb.sideload

import io.github.ncorror.nekoflash.adb.transport.AdbPacketDispatcher

/**
 * Pure request-driven ADB Sideload stream state machine.
 *
 * USB I/O and file I/O stay outside this class. Incoming ADB packets are consumed from the
 * single-reader dispatcher; block reads are surfaced as [BlockRequest] so the caller can ACK the
 * Recovery WRTE before performing random-access payload I/O, matching the legacy wire ordering.
 *
 * Recovery may request the same block more than once. [servedBytes] is therefore cumulative host
 * traffic, while progress and close classification use unique acknowledged blocks only.
 */
internal class SideloadStreamSession(
    private val localId: Int,
    private val totalBytes: Long,
) {
    data class OutboundPacket(
        val command: Long,
        val arg0: Int,
        val arg1: Int,
        val payload: ByteArray,
    )

    data class BlockRequest(
        val blockNumber: Int,
        val offset: Long,
        val length: Int,
    )

    data class Progress(
        /** Cumulative acknowledged payload traffic, including duplicate Recovery requests. */
        val servedBytes: Long,
        /** Unique acknowledged bytes used for UI progress and safety classification. */
        val confirmedUniqueBytes: Long,
        val totalBytes: Long,
        val approximatePercent: Int,
        val confirmedUniqueBlocks: Int,
        val totalBlocks: Int,
    )

    enum class Transition {
        OPENED,
        BLOCK_REQUESTED,
        BLOCK_SENT,
        BLOCK_ACKNOWLEDGED,
        BLOCK_REQUESTS_COMPLETE,
        TRANSFER_COMPLETE,
        CLOSED_BEFORE_DONE_DONE,
        INTERRUPTED_AFTER_PAYLOAD,
        CANCELLATION_REJECTED_AFTER_PAYLOAD,
        STALE_PACKET,
        FAILED,
        CANCELLED,
    }

    data class Step(
        val transition: Transition,
        val outbound: List<OutboundPacket> = emptyList(),
        val blockRequest: BlockRequest? = null,
        val progress: Progress? = null,
        val result: SideloadContract.TransferResult? = null,
        val detail: String,
    )

    private enum class Phase {
        CREATED,
        OPEN_SENT,
        WAITING_REQUEST,
        WAITING_BLOCK_DATA,
        WAITING_ACK,
        TERMINAL,
    }

    private var phase = Phase.CREATED
    private var remoteId = 0
    private var servedBytes = 0L
    private var confirmedUniqueBytes = 0L
    private val confirmedBlocks = HashSet<Int>()
    private var pendingBlockRequest: BlockRequest? = null
    private var pendingPayloadBytes = 0
    private var pendingPayloadBlockNumber: Int? = null
    private var pendingEndMarker = false
    private var payloadTransmissionStarted = false

    init {
        require(localId > 0) { "localId must be positive" }
        require(totalBytes > 0L) { "totalBytes must be positive" }
    }

    fun openRequest(): OutboundPacket {
        check(phase == Phase.CREATED) { "sideload stream already started" }
        phase = Phase.OPEN_SENT
        return OutboundPacket(
            command = A_OPEN,
            arg0 = localId,
            arg1 = 0,
            payload = "$service\u0000".toByteArray(Charsets.US_ASCII),
        )
    }

    fun consume(packet: AdbPacketDispatcher.Packet): Step {
        if (phase == Phase.TERMINAL) {
            return staleStep(packet, "packet after sideload terminal state")
        }
        if (!targetsLocal(packet)) {
            return staleStep(packet, "stale packet local=${packet.arg1} expected=$localId")
        }
        if (remoteId > 0 && packet.arg0 != remoteId) {
            return failProtocol(
                "ADB sideload remote stream changed: remote=${packet.arg0} expected=$remoteId",
            )
        }

        return when (phase) {
            Phase.CREATED -> failProtocol("ADB sideload packet arrived before OPEN")
            Phase.OPEN_SENT -> consumeOpen(packet)
            Phase.WAITING_REQUEST -> consumeRequest(packet)
            Phase.WAITING_BLOCK_DATA -> failProtocol("ADB sideload packet arrived while block data was being read")
            Phase.WAITING_ACK -> consumeAck(packet)
            Phase.TERMINAL -> error("terminal phase handled above")
        }
    }

    fun provideBlock(request: BlockRequest, payload: ByteArray): Step {
        if (phase != Phase.WAITING_BLOCK_DATA || pendingBlockRequest != request) {
            return failProtocol("ADB sideload block payload does not match the pending request")
        }
        if (payload.size != request.length) {
            return failFile(
                "Payload source returned ${payload.size} bytes for block=${request.blockNumber}; expected=${request.length}",
            )
        }

        pendingBlockRequest = null
        pendingPayloadBytes = payload.size
        pendingPayloadBlockNumber = request.blockNumber
        pendingEndMarker = false
        phase = Phase.WAITING_ACK
        return Step(
            transition = Transition.BLOCK_SENT,
            outbound = listOf(writePacket(payload)),
            detail = "block=${request.blockNumber} offset=${request.offset} bytes=${payload.size}",
        )
    }

    /**
     * Marks the irreversible host safety boundary immediately before the first payload WRTE is
     * attempted. The caller must invoke this before putting that first non-empty payload on USB.
     */
    fun markPayloadTransmissionStarted(): Boolean {
        check(phase == Phase.WAITING_ACK) { "payload mutation boundary requires a pending block ACK" }
        check(pendingPayloadBytes > 0 && pendingPayloadBlockNumber != null) {
            "payload mutation boundary requires a real payload block"
        }
        val first = !payloadTransmissionStarted
        payloadTransmissionStarted = true
        return first
    }

    fun blockReadFailed(request: BlockRequest, message: String): Step {
        if (phase != Phase.WAITING_BLOCK_DATA || pendingBlockRequest != request) {
            return failProtocol("ADB sideload block-read failure does not match the pending request")
        }
        pendingBlockRequest = null
        return failFile(message)
    }

    fun transportClosed(message: String): Step = closeBeforeDoneDone(
        kind = SideloadContract.FailureKind.TRANSPORT,
        message = message,
        outbound = emptyList(),
    )

    /** Safe cancellation exists only before the first payload block is attempted on USB. */
    fun cancel(): Step {
        if (payloadTransmissionStarted) {
            return Step(
                transition = Transition.CANCELLATION_REJECTED_AFTER_PAYLOAD,
                detail = "ADB sideload cancellation rejected after payload mutation boundary",
            )
        }
        if (phase == Phase.TERMINAL) {
            return Step(
                transition = Transition.CANCELLED,
                result = SideloadContract.TransferResult.Cancelled,
                detail = "ADB sideload already terminal while cancellation was requested",
            )
        }
        phase = Phase.TERMINAL
        return Step(
            transition = Transition.CANCELLED,
            outbound = listOfNotNull(closePacketOrNull()),
            result = SideloadContract.TransferResult.Cancelled,
            detail = "ADB sideload cancelled before payload transmission",
        )
    }

    fun currentServedBytes(): Long = servedBytes

    fun currentConfirmedUniqueBytes(): Long = confirmedUniqueBytes

    fun hasPayloadTransmissionStarted(): Boolean = payloadTransmissionStarted

    val service: String
        get() = "sideload-host:$totalBytes:${SideloadContract.BLOCK_SIZE_BYTES}"

    private fun consumeOpen(packet: AdbPacketDispatcher.Packet): Step = when (packet.command) {
        A_OKAY -> {
            if (packet.arg0 <= 0) {
                failProtocol("Recovery confirmed sideload OPEN with invalid remote stream id=${packet.arg0}")
            } else {
                remoteId = packet.arg0
                phase = Phase.WAITING_REQUEST
                Step(
                    transition = Transition.OPENED,
                    detail = "local=$localId remote=$remoteId service=$service",
                )
            }
        }

        A_CLSE -> {
            remoteId = packet.arg0.coerceAtLeast(0)
            closeBeforeDoneDone(
                kind = SideloadContract.FailureKind.PROTOCOL,
                message = "Recovery closed the sideload stream before confirming OPEN",
                outbound = listOfNotNull(closePacketOrNull()),
            )
        }

        else -> failProtocol(
            "Recovery did not confirm sideload-host OPEN: cmd=0x${packet.command.toString(16)}",
        )
    }

    private fun consumeRequest(packet: AdbPacketDispatcher.Packet): Step = when (packet.command) {
        A_CLSE -> closeBeforeDoneDone(
            kind = SideloadContract.FailureKind.PROTOCOL,
            message = "Recovery closed the sideload stream before DONEDONE",
            outbound = listOfNotNull(closePacketOrNull()),
        )

        A_WRTE -> consumeWriteRequest(packet.payload)

        else -> failProtocol(
            "Unexpected ADB command in sideload stream: 0x${packet.command.toString(16)}",
        )
    }

    private fun consumeWriteRequest(payload: ByteArray): Step {
        val requestAck = okayPacket()
        val ascii = runCatching {
            String(payload, Charsets.US_ASCII).trimEnd('\u0000', ' ', '\r', '\n')
        }.getOrDefault("")

        if (ascii == DONE_DONE) {
            phase = Phase.TERMINAL
            return Step(
                transition = Transition.TRANSFER_COMPLETE,
                outbound = listOf(requestAck),
                result = SideloadContract.TransferResult.TransferComplete,
                detail = "Recovery sent DONEDONE; host transfer complete only",
            )
        }

        val blockToken = ascii.take(8).trim('\u0000', ' ')
        val blockNumber = blockToken.toIntOrNull()
            ?: return failProtocol(
                message = "Invalid sideload block request (${payload.size} bytes)",
                prefixOutbound = listOf(requestAck),
            )

        if (blockNumber == -1) {
            pendingPayloadBytes = 0
            pendingPayloadBlockNumber = null
            pendingEndMarker = true
            phase = Phase.WAITING_ACK
            return Step(
                transition = Transition.BLOCK_REQUESTS_COMPLETE,
                outbound = listOf(requestAck, writePacket(EMPTY_PAYLOAD)),
                detail = "Recovery reported block requests complete; waiting for DONEDONE",
            )
        }
        if (blockNumber < 0) {
            return failProtocol(
                message = "Negative sideload block number: $blockNumber",
                prefixOutbound = listOf(requestAck),
            )
        }

        val offset = blockNumber.toLong() * SideloadContract.BLOCK_SIZE_BYTES.toLong()
        if (offset < 0L || offset >= totalBytes) {
            return failProtocol(
                message = "Recovery requested a block outside the payload: block=$blockNumber offset=$offset size=$totalBytes",
                prefixOutbound = listOf(requestAck),
            )
        }
        val request = BlockRequest(
            blockNumber = blockNumber,
            offset = offset,
            length = minOf(SideloadContract.BLOCK_SIZE_BYTES.toLong(), totalBytes - offset).toInt(),
        )
        pendingBlockRequest = request
        phase = Phase.WAITING_BLOCK_DATA
        return Step(
            transition = Transition.BLOCK_REQUESTED,
            outbound = listOf(requestAck),
            blockRequest = request,
            detail = "block=$blockNumber offset=$offset bytes=${request.length}",
        )
    }

    private fun consumeAck(packet: AdbPacketDispatcher.Packet): Step = when (packet.command) {
        A_OKAY -> if (!pendingEndMarker && pendingPayloadBytes > 0 && !payloadTransmissionStarted) {
            failProtocol("ADB sideload payload ACK arrived before mutation boundary was marked")
        } else {
            phase = Phase.WAITING_REQUEST
            if (pendingEndMarker) {
                pendingEndMarker = false
                Step(
                    transition = Transition.BLOCK_REQUESTS_COMPLETE,
                    detail = "Recovery acknowledged end-of-block marker; waiting for DONEDONE",
                )
            } else {
                val acknowledgedBytes = pendingPayloadBytes
                val acknowledgedBlock = pendingPayloadBlockNumber
                servedBytes += acknowledgedBytes.toLong()
                if (acknowledgedBlock != null && confirmedBlocks.add(acknowledgedBlock)) {
                    confirmedUniqueBytes += acknowledgedBytes.toLong()
                }
                pendingPayloadBytes = 0
                pendingPayloadBlockNumber = null
                val approximatePercent = SideloadContract.coveragePercent(confirmedUniqueBytes, totalBytes)
                    .coerceIn(0, 99)
                Step(
                    transition = Transition.BLOCK_ACKNOWLEDGED,
                    progress = Progress(
                        servedBytes = servedBytes,
                        confirmedUniqueBytes = confirmedUniqueBytes,
                        totalBytes = totalBytes,
                        approximatePercent = approximatePercent,
                        confirmedUniqueBlocks = confirmedBlocks.size,
                        totalBlocks = totalBlockCount(),
                    ),
                    detail = "served=$servedBytes unique=$confirmedUniqueBytes/$totalBytes " +
                        "uniqueBlocks=${confirmedBlocks.size}/${totalBlockCount()} approximatePercent=$approximatePercent",
                )
            }
        }

        A_CLSE -> closeBeforeDoneDone(
            kind = SideloadContract.FailureKind.PROTOCOL,
            message = "Recovery closed the sideload stream before DONEDONE",
            outbound = listOfNotNull(closePacketOrNull()),
        )

        else -> failProtocol(
            "Unexpected ADB response after sideload block: cmd=0x${packet.command.toString(16)}",
        )
    }

    private fun closeBeforeDoneDone(
        kind: SideloadContract.FailureKind,
        message: String,
        outbound: List<OutboundPacket>,
    ): Step {
        if (phase == Phase.TERMINAL && !payloadTransmissionStarted) {
            return Step(
                transition = Transition.FAILED,
                result = SideloadContract.TransferResult.Failed(kind, message),
                detail = message,
            )
        }
        phase = Phase.TERMINAL
        val result = SideloadContract.classifyCloseBeforeDoneDone(
            kind = kind,
            message = message,
            payloadTransmissionStarted = payloadTransmissionStarted,
            servedBytes = servedBytes,
            confirmedUniqueBytes = confirmedUniqueBytes,
            totalBytes = totalBytes,
        )
        return Step(
            transition = when (result) {
                is SideloadContract.TransferResult.TransferClosedBeforeDoneDone -> Transition.CLOSED_BEFORE_DONE_DONE
                is SideloadContract.TransferResult.TransferInterruptedAfterPayload -> Transition.INTERRUPTED_AFTER_PAYLOAD
                else -> Transition.FAILED
            },
            outbound = outbound,
            result = result,
            detail = message,
        )
    }

    private fun failFile(message: String): Step = fail(
        kind = SideloadContract.FailureKind.FILE,
        message = message,
    )

    private fun failProtocol(
        message: String,
        prefixOutbound: List<OutboundPacket> = emptyList(),
    ): Step = fail(
        kind = SideloadContract.FailureKind.PROTOCOL,
        message = message,
        prefixOutbound = prefixOutbound,
    )

    private fun fail(
        kind: SideloadContract.FailureKind,
        message: String,
        prefixOutbound: List<OutboundPacket> = emptyList(),
    ): Step {
        phase = Phase.TERMINAL
        val outbound = prefixOutbound + listOfNotNull(closePacketOrNull())
        if (payloadTransmissionStarted) {
            val result = SideloadContract.classifyCloseBeforeDoneDone(
                kind = kind,
                message = message,
                payloadTransmissionStarted = true,
                servedBytes = servedBytes,
                confirmedUniqueBytes = confirmedUniqueBytes,
                totalBytes = totalBytes,
            )
            return Step(
                transition = when (result) {
                    is SideloadContract.TransferResult.TransferClosedBeforeDoneDone -> Transition.CLOSED_BEFORE_DONE_DONE
                    is SideloadContract.TransferResult.TransferInterruptedAfterPayload -> Transition.INTERRUPTED_AFTER_PAYLOAD
                    else -> Transition.FAILED
                },
                outbound = outbound,
                result = result,
                detail = message,
            )
        }
        return Step(
            transition = Transition.FAILED,
            outbound = outbound,
            result = SideloadContract.TransferResult.Failed(kind, message),
            detail = message,
        )
    }

    private fun staleStep(packet: AdbPacketDispatcher.Packet, detail: String): Step = Step(
        transition = Transition.STALE_PACKET,
        outbound = staleClose(packet),
        detail = detail,
    )

    private fun targetsLocal(packet: AdbPacketDispatcher.Packet): Boolean = packet.arg1 == localId

    private fun staleClose(packet: AdbPacketDispatcher.Packet): List<OutboundPacket> =
        if (packet.arg1 > 0 && packet.arg0 > 0) {
            listOf(OutboundPacket(A_CLSE, packet.arg1, packet.arg0, EMPTY_PAYLOAD))
        } else {
            emptyList()
        }

    private fun okayPacket(): OutboundPacket = OutboundPacket(A_OKAY, localId, remoteId, EMPTY_PAYLOAD)

    private fun writePacket(payload: ByteArray): OutboundPacket =
        OutboundPacket(A_WRTE, localId, remoteId, payload)

    private fun closePacketOrNull(): OutboundPacket? = remoteId.takeIf { it > 0 }?.let {
        OutboundPacket(A_CLSE, localId, it, EMPTY_PAYLOAD)
    }

    private fun totalBlockCount(): Int =
        ((totalBytes + SideloadContract.BLOCK_SIZE_BYTES - 1L) / SideloadContract.BLOCK_SIZE_BYTES).toInt()

    companion object {
        const val A_OPEN = 0x4E45504FL
        const val A_OKAY = 0x59414B4FL
        const val A_CLSE = 0x45534C43L
        const val A_WRTE = 0x45545257L
        const val DONE_DONE = "DONEDONE"

        private val EMPTY_PAYLOAD = ByteArray(0)
    }
}
