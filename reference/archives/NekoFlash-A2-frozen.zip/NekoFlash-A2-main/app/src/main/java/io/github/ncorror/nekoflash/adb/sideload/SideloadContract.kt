package io.github.ncorror.nekoflash.adb.sideload

/**
 * Pure ADB Sideload result contract.
 *
 * ADB Sideload is request-driven: Recovery may request the same 64 KiB block more than once and
 * may begin device mutation as soon as payload data is available. Cumulative bytes written by the
 * host therefore are diagnostic only; completion/coverage decisions use unique acknowledged
 * payload bytes. Once the first payload block is allowed onto the wire, an interruption is never
 * classified as a safe cancellation or an ordinary host-side failure: Recovery verification is
 * required because device mutation may already have started.
 */
internal object SideloadContract {
    const val BLOCK_SIZE_BYTES = 65_536
    const val CLOSE_VERIFY_PENDING_PERCENT = 95

    enum class FailureKind {
        FILE,
        TRANSPORT,
        PROTOCOL,
    }

    enum class StartRejectReason {
        TRANSPORT_UNAVAILABLE,
        NOT_IN_SIDELOAD_MODE,
        EMPTY_PAYLOAD,
    }

    sealed interface StartDecision {
        data object Ready : StartDecision
        data class Rejected(val reason: StartRejectReason) : StartDecision
    }

    sealed interface TransferResult {
        /** Host-side sideload stream reached DONEDONE. This is not an install-success verdict. */
        data object TransferComplete : TransferResult

        /**
         * Recovery closed after at least 95% of unique payload bytes were acknowledged. This keeps
         * the legacy near-complete distinction, but it still requires Recovery verification.
         */
        data class TransferClosedBeforeDoneDone(
            val servedBytes: Long,
            val confirmedUniqueBytes: Long,
            val totalBytes: Long,
            val percent: Int,
            val message: String,
        ) : TransferResult

        /**
         * The first payload block had already crossed the mutation boundary when the stream became
         * unusable. Device state is unknown regardless of apparent transfer percentage.
         */
        data class TransferInterruptedAfterPayload(
            val servedBytes: Long,
            val confirmedUniqueBytes: Long,
            val totalBytes: Long,
            val percent: Int,
            val message: String,
        ) : TransferResult

        /** Safe host-side cancellation is only valid before the first payload block is sent. */
        data object Cancelled : TransferResult

        data class NotInSideloadMode(val mode: String) : TransferResult

        data class Failed(
            val kind: FailureKind,
            val message: String,
        ) : TransferResult
    }

    fun validateStart(
        transportConnected: Boolean,
        peerIsSideload: Boolean,
        payloadBytes: Long,
    ): StartDecision = when {
        !transportConnected -> StartDecision.Rejected(StartRejectReason.TRANSPORT_UNAVAILABLE)
        !peerIsSideload -> StartDecision.Rejected(StartRejectReason.NOT_IN_SIDELOAD_MODE)
        payloadBytes <= 0L -> StartDecision.Rejected(StartRejectReason.EMPTY_PAYLOAD)
        else -> StartDecision.Ready
    }

    /**
     * Classifies a close/failure using unique acknowledged coverage, never cumulative served bytes.
     */
    fun classifyCloseBeforeDoneDone(
        kind: FailureKind,
        message: String,
        payloadTransmissionStarted: Boolean,
        servedBytes: Long,
        confirmedUniqueBytes: Long,
        totalBytes: Long,
    ): TransferResult {
        if (!payloadTransmissionStarted) return TransferResult.Failed(kind, message)

        val percent = coveragePercent(confirmedUniqueBytes, totalBytes)
        return if (percent >= CLOSE_VERIFY_PENDING_PERCENT) {
            TransferResult.TransferClosedBeforeDoneDone(
                servedBytes = servedBytes.coerceAtLeast(0L),
                confirmedUniqueBytes = confirmedUniqueBytes.coerceIn(0L, totalBytes.coerceAtLeast(0L)),
                totalBytes = totalBytes.coerceAtLeast(0L),
                percent = percent,
                message = message,
            )
        } else {
            TransferResult.TransferInterruptedAfterPayload(
                servedBytes = servedBytes.coerceAtLeast(0L),
                confirmedUniqueBytes = confirmedUniqueBytes.coerceIn(0L, totalBytes.coerceAtLeast(0L)),
                totalBytes = totalBytes.coerceAtLeast(0L),
                percent = percent,
                message = message,
            )
        }
    }

    fun requiresRecoveryVerification(result: TransferResult): Boolean = when (result) {
        TransferResult.TransferComplete,
        is TransferResult.TransferClosedBeforeDoneDone,
        is TransferResult.TransferInterruptedAfterPayload,
        -> true

        TransferResult.Cancelled,
        is TransferResult.NotInSideloadMode,
        is TransferResult.Failed,
        -> false
    }

    internal fun coveragePercent(confirmedUniqueBytes: Long, totalBytes: Long): Int {
        if (totalBytes <= 0L) return 0
        val confirmed = confirmedUniqueBytes.coerceIn(0L, totalBytes)
        return ((confirmed * 100L) / totalBytes).toInt().coerceIn(0, 100)
    }
}
