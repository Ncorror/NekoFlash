package io.github.ncorror.nekoflash.fastboot.transport

import java.util.Locale

internal object FastbootFlashTargetPolicy {
    private val PARTITION_PATTERN = Regex("^[A-Za-z0-9._:-]{1,128}$")
    private val SLOT_PATTERN = Regex("^[a-z]$")

    fun normalizePartition(raw: String): String? {
        val normalized = raw.trim().lowercase(Locale.US)
        return normalized.takeIf { PARTITION_PATTERN.matches(it) }
    }

    fun normalizeSlot(raw: String?): String? = raw
        ?.trim()
        ?.removePrefix("_")
        ?.lowercase(Locale.US)
        ?.takeIf { SLOT_PATTERN.matches(it) }

    fun applySlot(partition: String, slot: String): String {
        val normalized = normalizePartition(partition)
            ?: throw IllegalArgumentException("Invalid partition")
        val normalizedSlot = normalizeSlot(slot)
            ?: throw IllegalArgumentException("Invalid slot")
        val pieces = normalized.split(':', limit = 2)
        val target = "${pieces[0]}_$normalizedSlot"
        return if (pieces.size == 2) "$target:${pieces[1]}" else target
    }
}

internal sealed interface FastbootFlashTargetResult {
    data class Resolved(
        val target: String,
        val slot: String?,
        val slotted: Boolean,
    ) : FastbootFlashTargetResult

    data class Failed(
        val message: String,
        val sessionCorrupted: Boolean = false,
    ) : FastbootFlashTargetResult
}
