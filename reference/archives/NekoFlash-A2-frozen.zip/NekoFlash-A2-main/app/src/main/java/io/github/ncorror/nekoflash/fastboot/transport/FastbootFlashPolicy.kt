package io.github.ncorror.nekoflash.fastboot.transport

import io.github.ncorror.nekoflash.fastboot.codec.FastbootValueParser
import java.util.Locale

/** Pure validation and safety decisions for destructive Fastboot flash operations. */
internal object FastbootFlashPolicy {
    const val PROTOCOL_MAX_DOWNLOAD_BYTES = 0xFFFF_FFFFL
    private val PARTITION_PATTERN = Regex("^[A-Za-z0-9._:-]{1,128}$")
    private val DEVICE_LIMIT_PATTERN = Regex("^(?:0[xX][0-9A-Fa-f]+|[0-9]+)$")

    sealed interface Authorization {
        data object Allowed : Authorization
        data class Blocked(val reason: BlockReason) : Authorization
    }

    enum class BlockReason {
        BOOTLOADER_LOCKED,
        UNLOCK_STATE_UNKNOWN,
    }

    sealed interface PlanResult {
        data class Ready(val plan: Plan) : PlanResult
        data class Rejected(val reason: RejectReason) : PlanResult
    }

    sealed interface DeviceLimitResult {
        data class Available(val bytes: Long) : DeviceLimitResult
        data object Unavailable : DeviceLimitResult
    }

    sealed interface PartitionCapacityResult {
        data class Available(val bytes: Long) : PartitionCapacityResult
        data object Unavailable : PartitionCapacityResult
    }

    enum class RejectReason {
        INVALID_PARTITION,
        EMPTY_PAYLOAD,
        PAYLOAD_TOO_LARGE_FOR_PROTOCOL,
        PAYLOAD_EXCEEDS_DEVICE_LIMIT,
        PAYLOAD_EXCEEDS_PARTITION,
    }

    data class Plan(
        val partition: String,
        val payloadBytes: Long,
        val downloadCommand: String,
    )

    /**
     * Destructive flash is fail-closed. Only an explicit `unlocked=yes`-equivalent
     * authorizes the app to proceed; `no`, FAIL, or an unknown value blocks before DATA.
     */
    fun authorize(unlockedRaw: String?): Authorization = when (FastbootValueParser.parseBoolean(unlockedRaw)) {
        true -> Authorization.Allowed
        false -> Authorization.Blocked(BlockReason.BOOTLOADER_LOCKED)
        null -> Authorization.Blocked(BlockReason.UNLOCK_STATE_UNKNOWN)
    }

    /**
     * Flash is also fail-closed around the bootloader's advertised download limit.
     * A fresh terminal OKAY with a positive, parseable size is required before DATA.
     */
    fun requireDeviceLimit(finalType: String?, rawValue: String?): DeviceLimitResult {
        if (finalType != "OKAY") return DeviceLimitResult.Unavailable
        val normalized = rawValue?.trim()?.takeIf { DEVICE_LIMIT_PATTERN.matches(it) }
            ?: return DeviceLimitResult.Unavailable
        val bytes = FastbootCoreDiagnosticsPlan.parseFastbootSize(normalized)
            ?.takeIf { it > 0L }
            ?: return DeviceLimitResult.Unavailable
        return DeviceLimitResult.Available(bytes)
    }

    fun requirePartitionCapacity(finalType: String?, rawValue: String?): PartitionCapacityResult {
        if (finalType != "OKAY") return PartitionCapacityResult.Unavailable
        val normalized = rawValue?.trim()?.takeIf { DEVICE_LIMIT_PATTERN.matches(it) }
            ?: return PartitionCapacityResult.Unavailable
        val bytes = FastbootCoreDiagnosticsPlan.parseFastbootSize(normalized)
            ?.takeIf { it > 0L }
            ?: return PartitionCapacityResult.Unavailable
        return PartitionCapacityResult.Available(bytes)
    }

    fun plan(
        partitionRaw: String,
        payloadBytes: Long,
        maxDownloadSizeBytes: Long?,
        partitionCapacityBytes: Long? = null,
    ): PlanResult {
        val partition = partitionRaw.trim().lowercase(Locale.US)
        if (!PARTITION_PATTERN.matches(partition)) {
            return PlanResult.Rejected(RejectReason.INVALID_PARTITION)
        }
        if (payloadBytes <= 0L) {
            return PlanResult.Rejected(RejectReason.EMPTY_PAYLOAD)
        }
        if (payloadBytes > PROTOCOL_MAX_DOWNLOAD_BYTES) {
            return PlanResult.Rejected(RejectReason.PAYLOAD_TOO_LARGE_FOR_PROTOCOL)
        }
        val deviceLimit = maxDownloadSizeBytes?.takeIf { it > 0L }
        if (deviceLimit != null && payloadBytes > deviceLimit) {
            return PlanResult.Rejected(RejectReason.PAYLOAD_EXCEEDS_DEVICE_LIMIT)
        }
        val partitionCapacity = partitionCapacityBytes?.takeIf { it > 0L }
        if (partitionCapacity != null && payloadBytes > partitionCapacity) {
            return PlanResult.Rejected(RejectReason.PAYLOAD_EXCEEDS_PARTITION)
        }
        return PlanResult.Ready(
            Plan(
                partition = partition,
                payloadBytes = payloadBytes,
                downloadCommand = "download:${String.format(Locale.US, "%08x", payloadBytes)}",
            ),
        )
    }
}
