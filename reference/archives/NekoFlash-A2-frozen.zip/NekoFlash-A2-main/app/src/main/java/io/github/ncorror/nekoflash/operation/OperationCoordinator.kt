package io.github.ncorror.nekoflash.operation

/**
 * Application-scoped owner of the single active NekoFlash operation.
 *
 * Operation ownership, generation safety, cancellation, progress and terminal results are
 * independent from protocol capabilities. USB/protocol ownership remains in UsbSessionCoordinator.
 */
class OperationCoordinator {
    enum class Kind {
        FASTBOOT_DIAGNOSTIC_REFRESH,
        FASTBOOT_FLASH,
        ADB_SIDELOAD,
    }

    enum class Stage {
        STARTING,
        RUNNING,
        AUTHORIZING,
        TRANSFERRING,
        WRITING,
        FINALIZING,
        CANCELLING,
    }

    enum class Outcome {
        SUCCEEDED,
        FAILED,
        ABORTED,
        VERIFICATION_PENDING,
    }

    data class Metadata(
        val deviceLabel: String? = null,
        val product: String? = null,
        val fileName: String? = null,
        val partition: String? = null,
        val slot: String? = null,
        val totalBytes: Long? = null,
        val sha256: String? = null,
    )

    data class Progress(
        val confirmedBytes: Long,
        val totalBytes: Long,
        val percent: Int,
        val averageBytesPerSecond: Double,
        val etaMs: Long?,
    )

    data class ActiveOperation(
        val generation: Long,
        val kind: Kind,
        val stage: Stage = Stage.STARTING,
        val metadata: Metadata = Metadata(),
        val progress: Progress? = null,
        val cancellationRequested: Boolean = false,
        val startedAtEpochMs: Long = System.currentTimeMillis(),
    )

    data class CompletedOperation(
        val generation: Long,
        val kind: Kind,
        val outcome: Outcome,
        val metadata: Metadata = Metadata(),
        val progress: Progress? = null,
        val message: String? = null,
        val startedAtEpochMs: Long = 0L,
        val finishedAtEpochMs: Long = System.currentTimeMillis(),
    )

    data class Observation(
        val active: ActiveOperation? = null,
        val lastCompleted: CompletedOperation? = null,
    )

    class Lease internal constructor(
        val generation: Long,
        val kind: Kind,
        private val coordinator: OperationCoordinator,
    ) {
        /** Advances only while this lease still owns the active operation. */
        fun updateStage(stage: Stage): Boolean =
            coordinator.updateStage(generation, kind, stage)

        /** Publishes byte progress only while this lease still owns the active operation. */
        fun updateProgress(progress: Progress): Boolean =
            coordinator.updateProgress(generation, kind, progress)

        /** Installs the cleanup/cancel action owned by this exact generation. */
        fun setCancellationHandler(handler: () -> Unit): Boolean =
            coordinator.setCancellationHandler(generation, kind, handler)

        fun isCancellationRequested(): Boolean =
            coordinator.isCancellationRequested(generation, kind)

        /** Completes only if this lease still owns the active operation. */
        fun complete(outcome: Outcome, message: String? = null): Boolean =
            coordinator.complete(generation, kind, outcome, message)
    }

    private val lock = Any()
    private var operationGeneration = 0L
    private var listenerGeneration = 0L
    private var observation = Observation()
    private var listener: ((Observation) -> Unit)? = null
    private var cancellationHandler: (() -> Unit)? = null

    /** Returns null when another operation already owns the single operation slot. */
    fun tryBegin(kind: Kind, metadata: Metadata = Metadata()): Lease? {
        val nextObservation: Observation
        val callback: ((Observation) -> Unit)?
        val lease: Lease
        synchronized(lock) {
            if (observation.active != null) return null
            // A pending Sideload install verdict is intentionally sticky. Starting another
            // operation would overwrite the only in-memory result before Recovery evidence is
            // reconciled, so fail closed until verification resolves it.
            if (observation.lastCompleted?.outcome == Outcome.VERIFICATION_PENDING) return null
            val generation = ++operationGeneration
            val active = ActiveOperation(
                generation = generation,
                kind = kind,
                metadata = metadata,
            )
            nextObservation = observation.copy(active = active)
            observation = nextObservation
            cancellationHandler = null
            callback = listener
            lease = Lease(generation = generation, kind = kind, coordinator = this)
        }
        callback?.invoke(nextObservation)
        return lease
    }

    fun currentObservation(): Observation = synchronized(lock) { observation }

    /** Restores one durably persisted ADB Sideload verification-pending result after process start. */
    fun restoreVerificationPending(pending: SideloadVerificationStore.Pending): Boolean {
        val nextObservation: Observation
        val callback: ((Observation) -> Unit)?
        synchronized(lock) {
            if (observation.active != null || observation.lastCompleted != null) return false
            operationGeneration = maxOf(operationGeneration, pending.operationGeneration)
            nextObservation = Observation(
                active = null,
                lastCompleted = CompletedOperation(
                    generation = pending.operationGeneration,
                    kind = Kind.ADB_SIDELOAD,
                    outcome = Outcome.VERIFICATION_PENDING,
                    metadata = Metadata(
                        deviceLabel = pending.deviceLabel,
                        fileName = pending.fileName,
                        totalBytes = pending.totalBytes,
                        sha256 = pending.sha256,
                    ),
                    message = pending.message,
                    startedAtEpochMs = pending.startedAtEpochMs,
                    finishedAtEpochMs = pending.transferFinishedAtEpochMs,
                ),
            )
            observation = nextObservation
            callback = listener
        }
        callback?.invoke(nextObservation)
        return true
    }

    /**
     * Converts only the matching ADB Sideload VERIFICATION_PENDING result into a Recovery-verified
     * terminal verdict. A wrong SHA or a stale/non-pending result is never rewritten.
     */
    fun resolveSideloadVerification(
        expectedSha256: String,
        outcome: Outcome,
        message: String,
    ): Boolean {
        if (outcome != Outcome.SUCCEEDED && outcome != Outcome.FAILED) return false
        val nextObservation: Observation
        val callback: ((Observation) -> Unit)?
        synchronized(lock) {
            if (observation.active != null) return false
            val completed = observation.lastCompleted ?: return false
            if (
                completed.kind != Kind.ADB_SIDELOAD ||
                completed.outcome != Outcome.VERIFICATION_PENDING ||
                completed.metadata.sha256 != expectedSha256
            ) {
                return false
            }
            nextObservation = observation.copy(
                lastCompleted = completed.copy(
                    outcome = outcome,
                    message = message.take(MAX_RESULT_MESSAGE_CHARS),
                    finishedAtEpochMs = System.currentTimeMillis(),
                ),
            )
            observation = nextObservation
            callback = listener
        }
        callback?.invoke(nextObservation)
        return true
    }

    /**
     * Requests cancellation of the active operation. The operation does not become terminally
     * ABORTED here. Its owner must finish USB/file cleanup and then complete the lease.
     */
    fun requestCancellation(): Boolean {
        val nextObservation: Observation
        val callback: ((Observation) -> Unit)?
        val handler: (() -> Unit)?
        synchronized(lock) {
            val active = observation.active ?: return false
            // Once the device-side flash command is being written, closing USB can only destroy
            // our knowledge of the terminal result; it cannot reliably stop the device mutation.
            if (active.stage == Stage.WRITING || active.stage == Stage.FINALIZING) return false
            if (active.cancellationRequested) return true
            nextObservation = observation.copy(
                active = active.copy(
                    stage = Stage.CANCELLING,
                    cancellationRequested = true,
                ),
            )
            observation = nextObservation
            callback = listener
            handler = cancellationHandler
        }
        callback?.invoke(nextObservation)
        runCatching { handler?.invoke() }
        return true
    }

    /**
     * Replaces the UI observer. The listener receives the current immutable state immediately,
     * while operation ownership remains Application-scoped.
     */
    fun replaceObservationListener(listener: (Observation) -> Unit): Long {
        val generation: Long
        val snapshot: Observation
        synchronized(lock) {
            generation = ++listenerGeneration
            this.listener = listener
            snapshot = observation
        }
        listener(snapshot)
        return generation
    }

    /** Clears only the listener generation owned by the caller. */
    fun clearObservationListener(generation: Long) {
        synchronized(lock) {
            if (generation == listenerGeneration) {
                listener = null
            }
        }
    }

    private fun updateStage(
        generation: Long,
        kind: Kind,
        stage: Stage,
    ): Boolean {
        val nextObservation: Observation
        val callback: ((Observation) -> Unit)?
        synchronized(lock) {
            val active = observation.active
            if (active?.generation != generation || active.kind != kind) return false
            if (active.cancellationRequested && stage != Stage.CANCELLING) return false
            if (stage.ordinal < active.stage.ordinal) return false
            if (stage == active.stage) return true
            nextObservation = observation.copy(active = active.copy(stage = stage))
            observation = nextObservation
            callback = listener
        }
        callback?.invoke(nextObservation)
        return true
    }

    private fun updateProgress(
        generation: Long,
        kind: Kind,
        progress: Progress,
    ): Boolean {
        if (progress.totalBytes <= 0L) return false
        if (progress.confirmedBytes !in 0L..progress.totalBytes) return false
        if (progress.percent !in 0..100) return false
        if (progress.averageBytesPerSecond < 0.0) return false
        if (progress.etaMs != null && progress.etaMs < 0L) return false

        val nextObservation: Observation
        val callback: ((Observation) -> Unit)?
        synchronized(lock) {
            val active = observation.active
            if (active?.generation != generation || active.kind != kind) return false
            if (active.cancellationRequested) return false
            val previous = active.progress
            if (previous != null) {
                if (progress.totalBytes != previous.totalBytes) return false
                if (progress.confirmedBytes < previous.confirmedBytes) return false
            }
            nextObservation = observation.copy(active = active.copy(progress = progress))
            observation = nextObservation
            callback = listener
        }
        callback?.invoke(nextObservation)
        return true
    }

    private fun setCancellationHandler(
        generation: Long,
        kind: Kind,
        handler: () -> Unit,
    ): Boolean {
        var invokeImmediately: Boolean
        synchronized(lock) {
            val active = observation.active
            if (active?.generation != generation || active.kind != kind) return false
            cancellationHandler = handler
            invokeImmediately = active.cancellationRequested
        }
        if (invokeImmediately) runCatching(handler)
        return true
    }

    private fun isCancellationRequested(generation: Long, kind: Kind): Boolean = synchronized(lock) {
        val active = observation.active
        active?.generation == generation && active.kind == kind && active.cancellationRequested
    }

    private fun complete(
        generation: Long,
        kind: Kind,
        outcome: Outcome,
        message: String?,
    ): Boolean {
        val nextObservation: Observation
        val callback: ((Observation) -> Unit)?
        synchronized(lock) {
            val active = observation.active
            if (active?.generation != generation || active.kind != kind) return false
            nextObservation = Observation(
                active = null,
                lastCompleted = CompletedOperation(
                    generation = generation,
                    kind = kind,
                    outcome = outcome,
                    metadata = active.metadata,
                    progress = active.progress,
                    message = message?.take(MAX_RESULT_MESSAGE_CHARS),
                    startedAtEpochMs = active.startedAtEpochMs,
                ),
            )
            observation = nextObservation
            cancellationHandler = null
            callback = listener
        }
        callback?.invoke(nextObservation)
        return true
    }

    private companion object {
        const val MAX_RESULT_MESSAGE_CHARS = 500
    }
}
