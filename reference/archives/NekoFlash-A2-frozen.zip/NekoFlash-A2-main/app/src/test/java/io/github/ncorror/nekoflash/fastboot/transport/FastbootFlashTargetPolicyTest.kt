package io.github.ncorror.nekoflash.fastboot.transport

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FastbootFlashTargetPolicyTest {
    @Test
    fun normalizesValidPartition() {
        assertEquals("boot", FastbootFlashTargetPolicy.normalizePartition("  BOOT  "))
        assertEquals("vendor_boot:raw", FastbootFlashTargetPolicy.normalizePartition("Vendor_Boot:RAW"))
    }

    @Test
    fun rejectsUnsafePartitionToken() {
        assertNull(FastbootFlashTargetPolicy.normalizePartition("boot;reboot"))
        assertNull(FastbootFlashTargetPolicy.normalizePartition(""))
        assertNull(FastbootFlashTargetPolicy.normalizePartition("boot image"))
    }

    @Test
    fun normalizesSlot() {
        assertEquals("a", FastbootFlashTargetPolicy.normalizeSlot("_A"))
        assertEquals("b", FastbootFlashTargetPolicy.normalizeSlot(" b "))
        assertNull(FastbootFlashTargetPolicy.normalizeSlot("ab"))
    }

    @Test
    fun appliesSlotBeforeOptionalPartitionSuffix() {
        assertEquals("boot_a", FastbootFlashTargetPolicy.applySlot("boot", "a"))
        assertEquals("vendor_boot_b:raw", FastbootFlashTargetPolicy.applySlot("vendor_boot:raw", "_b"))
    }
}
