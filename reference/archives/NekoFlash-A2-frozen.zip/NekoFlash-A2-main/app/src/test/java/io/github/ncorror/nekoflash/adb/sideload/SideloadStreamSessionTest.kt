package io.github.ncorror.nekoflash.adb.sideload

import io.github.ncorror.nekoflash.adb.transport.AdbPacketDispatcher
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SideloadStreamSessionTest {
    @Test
    fun `open request uses legacy sideload-host service and block size`() {
        val session = SideloadStreamSession(localId = 3, totalBytes = 123_456L)

        val open = session.openRequest()

        assertEquals(SideloadStreamSession.A_OPEN, open.command)
        assertEquals(3, open.arg0)
        assertEquals(0, open.arg1)
        assertArrayEquals("sideload-host:123456:65536\u0000".toByteArray(), open.payload)
    }

    @Test
    fun `first payload boundary is explicit before block acknowledgement`() {
        val session = openedSession(totalBytes = 200_000L)

        val requestStep = session.consume(writeRequest("2"))

        assertEquals(SideloadStreamSession.Transition.BLOCK_REQUESTED, requestStep.transition)
        assertEquals(listOf(SideloadStreamSession.A_OKAY), requestStep.outbound.map { it.command })
        val request = assertNotNullValue(requestStep.blockRequest)
        assertEquals(2, request.blockNumber)
        assertEquals(131_072L, request.offset)
        assertEquals(65_536, request.length)

        val payload = ByteArray(request.length) { (it and 0x7F).toByte() }
        val sendStep = session.provideBlock(request, payload)
        assertEquals(SideloadStreamSession.Transition.BLOCK_SENT, sendStep.transition)
        assertFalse(session.hasPayloadTransmissionStarted())
        assertTrue(session.markPayloadTransmissionStarted())
        assertTrue(session.hasPayloadTransmissionStarted())
        assertEquals(SideloadStreamSession.A_WRTE, sendStep.outbound.single().command)
        assertArrayEquals(payload, sendStep.outbound.single().payload)

        val ack = session.consume(packet(SideloadStreamSession.A_OKAY, arg0 = 41, arg1 = 3))
        assertEquals(SideloadStreamSession.Transition.BLOCK_ACKNOWLEDGED, ack.transition)
        assertEquals(65_536L, ack.progress?.servedBytes)
        assertEquals(65_536L, ack.progress?.confirmedUniqueBytes)
        assertEquals(32, ack.progress?.approximatePercent)
        assertEquals(1, ack.progress?.confirmedUniqueBlocks)
    }

    @Test
    fun `duplicate block requests increase served traffic but not unique progress`() {
        val session = openedSession(totalBytes = 131_072L)

        val first = serveBlock(session, blockNumber = 0, markBoundary = true)
        assertEquals(65_536L, first.servedBytes)
        assertEquals(65_536L, first.confirmedUniqueBytes)
        assertEquals(50, first.approximatePercent)

        val duplicate = serveBlock(session, blockNumber = 0, markBoundary = false)
        assertEquals(131_072L, duplicate.servedBytes)
        assertEquals(65_536L, duplicate.confirmedUniqueBytes)
        assertEquals(50, duplicate.approximatePercent)
        assertEquals(1, duplicate.confirmedUniqueBlocks)
    }

    @Test
    fun `last block is shortened to remaining payload bytes`() {
        val session = openedSession(totalBytes = 65_537L)

        val request = assertNotNullValue(session.consume(writeRequest("1")).blockRequest)

        assertEquals(65_536L, request.offset)
        assertEquals(1, request.length)
    }

    @Test
    fun `DONEDONE acknowledges WRTE but only completes transfer`() {
        val session = openedSession(totalBytes = 65_536L)

        val done = session.consume(writeRequest("DONEDONE\u0000"))

        assertEquals(SideloadStreamSession.Transition.TRANSFER_COMPLETE, done.transition)
        assertEquals(listOf(SideloadStreamSession.A_OKAY), done.outbound.map { it.command })
        assertEquals(SideloadContract.TransferResult.TransferComplete, done.result)
        assertTrue(SideloadContract.requiresRecoveryVerification(done.result!!))
    }

    @Test
    fun `minus one sends empty WRTE and still waits for DONEDONE`() {
        val session = openedSession(totalBytes = 65_536L)

        val endBlocks = session.consume(writeRequest("-1"))
        assertEquals(SideloadStreamSession.Transition.BLOCK_REQUESTS_COMPLETE, endBlocks.transition)
        assertEquals(
            listOf(SideloadStreamSession.A_OKAY, SideloadStreamSession.A_WRTE),
            endBlocks.outbound.map { it.command },
        )
        assertTrue(endBlocks.outbound.last().payload.isEmpty())
        assertEquals(null, endBlocks.result)

        val ack = session.consume(packet(SideloadStreamSession.A_OKAY, arg0 = 41, arg1 = 3))
        assertEquals(SideloadStreamSession.Transition.BLOCK_REQUESTS_COMPLETE, ack.transition)
        assertEquals(null, ack.result)

        val done = session.consume(writeRequest("DONEDONE"))
        assertEquals(SideloadContract.TransferResult.TransferComplete, done.result)
    }

    @Test
    fun `invalid and out of range requests fail protocol after acking request`() {
        val invalid = openedSession(totalBytes = 65_536L)
        val invalidStep = invalid.consume(writeRequest("garbage"))
        assertEquals(SideloadStreamSession.Transition.FAILED, invalidStep.transition)
        assertTrue(invalidStep.result is SideloadContract.TransferResult.Failed)
        assertEquals(
            listOf(SideloadStreamSession.A_OKAY, SideloadStreamSession.A_CLSE),
            invalidStep.outbound.map { it.command },
        )

        val outside = openedSession(totalBytes = 65_536L)
        val outsideStep = outside.consume(writeRequest("1"))
        val result = outsideStep.result as SideloadContract.TransferResult.Failed
        assertEquals(SideloadContract.FailureKind.PROTOCOL, result.kind)
        assertTrue(result.message.contains("outside"))
    }

    @Test
    fun `wrong block payload length before mutation boundary is an ordinary file failure`() {
        val session = openedSession(totalBytes = 65_536L)
        val request = assertNotNullValue(session.consume(writeRequest("0")).blockRequest)

        val failed = session.provideBlock(request, ByteArray(request.length - 1))

        val result = failed.result as SideloadContract.TransferResult.Failed
        assertEquals(SideloadContract.FailureKind.FILE, result.kind)
        assertEquals(listOf(SideloadStreamSession.A_CLSE), failed.outbound.map { it.command })
    }

    @Test
    fun `close before any payload remains failed but close after first payload is verification pending`() {
        val before = openedSession(totalBytes = 131_072L)
        val beforeClose = before.transportClosed("transport closed before payload")
        assertTrue(beforeClose.result is SideloadContract.TransferResult.Failed)

        val after = openedSession(totalBytes = 131_072L)
        val request = assertNotNullValue(after.consume(writeRequest("0")).blockRequest)
        after.provideBlock(request, ByteArray(request.length))
        after.markPayloadTransmissionStarted()
        val afterClose = after.transportClosed("transport closed after payload started")
        assertEquals(SideloadStreamSession.Transition.INTERRUPTED_AFTER_PAYLOAD, afterClose.transition)
        assertTrue(afterClose.result is SideloadContract.TransferResult.TransferInterruptedAfterPayload)
        assertTrue(SideloadContract.requiresRecoveryVerification(afterClose.result!!))
    }

    @Test
    fun `95 percent close boundary uses unique acknowledged bytes`() {
        val session = openedSession(totalBytes = 65_536L)
        serveBlock(session, blockNumber = 0, markBoundary = true)
        val pending = session.transportClosed("transport closed before DONEDONE")
        assertTrue(pending.result is SideloadContract.TransferResult.TransferClosedBeforeDoneDone)
        assertEquals(
            100,
            (pending.result as SideloadContract.TransferResult.TransferClosedBeforeDoneDone).percent,
        )
    }

    @Test
    fun `cancellation is rejected after payload mutation boundary without emitting CLSE`() {
        val session = openedSession(totalBytes = 65_536L)
        val request = assertNotNullValue(session.consume(writeRequest("0")).blockRequest)
        session.provideBlock(request, ByteArray(request.length))
        assertTrue(session.markPayloadTransmissionStarted())

        val rejected = session.cancel()

        assertEquals(
            SideloadStreamSession.Transition.CANCELLATION_REJECTED_AFTER_PAYLOAD,
            rejected.transition,
        )
        assertTrue(rejected.outbound.isEmpty())
        assertEquals(null, rejected.result)
    }

    @Test
    fun `stale packet is closed without contaminating active stream`() {
        val session = openedSession(totalBytes = 65_536L)

        val stale = session.consume(
            packet(SideloadStreamSession.A_WRTE, arg0 = 99, arg1 = 2, payload = "0".toByteArray()),
        )

        assertEquals(SideloadStreamSession.Transition.STALE_PACKET, stale.transition)
        assertEquals(SideloadStreamSession.A_CLSE, stale.outbound.single().command)
        assertEquals(2, stale.outbound.single().arg0)
        assertEquals(99, stale.outbound.single().arg1)

        val valid = session.consume(writeRequest("0"))
        assertEquals(SideloadStreamSession.Transition.BLOCK_REQUESTED, valid.transition)
    }

    @Test
    fun `cancel after open but before payload is terminal cancelled and closes the stream`() {
        val session = openedSession(totalBytes = 65_536L)

        val cancelled = session.cancel()

        assertEquals(SideloadStreamSession.Transition.CANCELLED, cancelled.transition)
        assertEquals(SideloadContract.TransferResult.Cancelled, cancelled.result)
        assertEquals(listOf(SideloadStreamSession.A_CLSE), cancelled.outbound.map { it.command })
        assertFalse(SideloadContract.requiresRecoveryVerification(cancelled.result!!))
    }

    private fun openedSession(totalBytes: Long): SideloadStreamSession {
        val session = SideloadStreamSession(localId = 3, totalBytes = totalBytes)
        session.openRequest()
        val opened = session.consume(packet(SideloadStreamSession.A_OKAY, arg0 = 41, arg1 = 3))
        assertEquals(SideloadStreamSession.Transition.OPENED, opened.transition)
        return session
    }

    private fun writeRequest(text: String): AdbPacketDispatcher.Packet = packet(
        command = SideloadStreamSession.A_WRTE,
        arg0 = 41,
        arg1 = 3,
        payload = text.toByteArray(Charsets.US_ASCII),
    )

    private fun serveBlock(
        session: SideloadStreamSession,
        blockNumber: Int,
        markBoundary: Boolean,
    ): SideloadStreamSession.Progress {
        val request = assertNotNullValue(session.consume(writeRequest(blockNumber.toString())).blockRequest)
        val send = session.provideBlock(request, ByteArray(request.length))
        assertEquals(SideloadStreamSession.Transition.BLOCK_SENT, send.transition)
        if (markBoundary) assertTrue(session.markPayloadTransmissionStarted())
        val ack = session.consume(packet(SideloadStreamSession.A_OKAY, arg0 = 41, arg1 = 3))
        assertEquals(SideloadStreamSession.Transition.BLOCK_ACKNOWLEDGED, ack.transition)
        return assertNotNullValue(ack.progress)
    }

    private fun packet(
        command: Long,
        arg0: Int,
        arg1: Int,
        payload: ByteArray = ByteArray(0),
    ) = AdbPacketDispatcher.Packet(
        command = command,
        arg0 = arg0,
        arg1 = arg1,
        checksum = 0,
        magic = command.inv().toInt(),
        payload = payload,
    )

    private fun <T> assertNotNullValue(value: T?): T {
        assertNotNull(value)
        return value!!
    }
}
