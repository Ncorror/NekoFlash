# NekoFlash — START HERE

Дата: **2026-08-27**  
Статус: **SOURCE OF TRUTH для нового clean repository**.

## 1. Что произошло

Legacy NekoFlash имеет широкий профессиональный функционал, но старая архитектура и накопленные компромиссы не должны быть фундаментом нового проекта. NekoFlash-A2 дал важные transport/USB/Sideload решения и hardware evidence, но в процессе разработки в него проникли искусственные capability restrictions, stage-era архитектура и противоречивая документация.

Решение: **новая чистая кодовая база NekoFlash**. Не переписывание «по памяти» и не продолжение A2, а новая архитектура, использующая Legacy и A2 как источники проверенного опыта.

## 2. Иерархия решений

При конфликте информации приоритет такой:

1. `01_PRODUCT_CHARTER_RU.md` и `03_PROTOCOL_AND_SAFETY_INVARIANTS_RU.md`.
2. Актуальные ADR/Founding Decisions нового repository.
3. Доказанные protocol/transport invariants и hardware evidence.
4. Актуальный roadmap нового repository.
5. Legacy/A2 source, tests, logs и исторические документы — reference/evidence.

Старый checkpoint, временный prompt, stage-policy или комментарий в Legacy/A2 **не может** незаметно изменить продуктовую политику нового NekoFlash.

## 3. Неизменяемая продуктовая установка

**NekoFlash — профессиональный Android host toolkit. Он реализует максимально полный доступ к возможностям, которые реально предоставляют ADB, Fastboot/fastbootd, Recovery и поддерживаемые vendor protocols. NekoFlash не создаёт собственную систему запретов поверх этих возможностей только потому, что действие рискованное или продвинутое.**

Hard-block допустим только если:
- операция технически непредставима/некорректна;
- нарушен доказанный protocol/transport invariant;
- потерян ownership нужной physical session;
- peer/device сам отверг операцию;
- продолжение создало бы ложь о результате или недоказанную mutation.

Риск сам по себе = **warning/advisory**, а не удаление capability.

## 4. Что обязательно сохранить как смысл продукта

- имя **NekoFlash**;
- реальную Legacy Welcome identity и иконку как основу бренда;
- профессиональный характер продукта;
- Mi Unlock как важный first-class workflow, а не забытый поздний plugin;
- полный Expert Terminal и raw access;
- GUI как typed representation тех же core capabilities, а не отдельный урезанный уровень прав;
- сильные diagnostics/evidence;
- аппаратно доказанные correctness protections A2.

## 5. Что запрещено переносить как «наследство»

- broad allowlist/denylist ADB/Fastboot команд;
- host-side `unlocked/max-download-size/partition-size` как собственную authorization систему;
- entry gate, который делает профессиональные возможности «разрешаемыми» приложением;
- global god-class USB+ADB+Fastboot+UI;
- один логический ADB stream;
- global operation stage, одинаковый для всех операций;
- stale docs/recovery prompt как активную норму;
- `.orig`, `.bak`, `Old/New/Temp`, параллельные production paths, production stubs.

## 6. Правило миграции

Ничего не копировать целиком «потому что работает». Для каждого переносимого механизма:

1. определить capability/invariant;
2. описать новый API;
3. понять, какой код можно переиспользовать и какой надо переписать;
4. перенести тесты/evidence;
5. провести fault tests;
6. при hardware-sensitive изменении получить hardware proof;
7. оставить в новом repository только один production path.

## 7. Текущая точка

До freeze A2 стоит завершить один уже подготовленный read-only hardware gate на `vayu` для ADB inbound framing commit `a2479b333ee2f25b0bc86a530d948c48a3423a68`.

После PASS: freeze Legacy + A2 и bootstrap нового repository.  
После FAIL: исправить только доказанную framing-проблему, повторить gate, затем freeze. **Новых A2 features не строить.**
