package io.github.ncorror.nekoflash.adb.sideload

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SideloadContractTest {
    @Test
    fun `start validation fails before wire work unless transport peer and payload are ready`() {
        assertEquals(
            SideloadContract.StartDecision.Rejected(SideloadContract.StartRejectReason.TRANSPORT_UNAVAILABLE),
            SideloadContract.validateStart(false, true, 1L),
        )
        assertEquals(
            SideloadContract.StartDecision.Rejected(SideloadContract.StartRejectReason.NOT_IN_SIDELOAD_MODE),
            SideloadContract.validateStart(true, false, 1L),
        )
        assertEquals(
            SideloadContract.StartDecision.Rejected(SideloadContract.StartRejectReason.EMPTY_PAYLOAD),
            SideloadContract.validateStart(true, true, 0L),
        )
        assertEquals(
            SideloadContract.StartDecision.Ready,
            SideloadContract.validateStart(true, true, 1L),
        )
    }

    @Test
    fun `close before first payload stays an ordinary failure`() {
        val result = SideloadContract.classifyCloseBeforeDoneDone(
            kind = SideloadContract.FailureKind.TRANSPORT,
            message = "closed",
            payloadTransmissionStarted = false,
            servedBytes = 0L,
            confirmedUniqueBytes = 0L,
            totalBytes = 100L,
        )

        assertTrue(result is SideloadContract.TransferResult.Failed)
        assertFalse(SideloadContract.requiresRecoveryVerification(result))
    }

    @Test
    fun `post payload close below 95 percent is unknown instead of failed`() {
        val result = SideloadContract.classifyCloseBeforeDoneDone(
            kind = SideloadContract.FailureKind.TRANSPORT,
            message = "closed",
            payloadTransmissionStarted = true,
            servedBytes = 10L,
            confirmedUniqueBytes = 10L,
            totalBytes = 100L,
        )

        val interrupted = result as SideloadContract.TransferResult.TransferInterruptedAfterPayload
        assertEquals(10, interrupted.percent)
        assertTrue(SideloadContract.requiresRecoveryVerification(interrupted))
    }

    @Test
    fun `95 percent distinction uses unique coverage not cumulative served bytes`() {
        val duplicateHeavy = SideloadContract.classifyCloseBeforeDoneDone(
            kind = SideloadContract.FailureKind.PROTOCOL,
            message = "closed",
            payloadTransmissionStarted = true,
            servedBytes = 190L,
            confirmedUniqueBytes = 50L,
            totalBytes = 100L,
        )
        assertTrue(duplicateHeavy is SideloadContract.TransferResult.TransferInterruptedAfterPayload)
        assertEquals(
            50,
            (duplicateHeavy as SideloadContract.TransferResult.TransferInterruptedAfterPayload).percent,
        )

        val boundary = SideloadContract.classifyCloseBeforeDoneDone(
            kind = SideloadContract.FailureKind.PROTOCOL,
            message = "closed",
            payloadTransmissionStarted = true,
            servedBytes = 140L,
            confirmedUniqueBytes = 95L,
            totalBytes = 100L,
        )
        assertTrue(boundary is SideloadContract.TransferResult.TransferClosedBeforeDoneDone)
        assertEquals(
            95,
            (boundary as SideloadContract.TransferResult.TransferClosedBeforeDoneDone).percent,
        )
    }

    @Test
    fun `DONEDONE and every post payload interruption require recovery verification`() {
        assertTrue(
            SideloadContract.requiresRecoveryVerification(
                SideloadContract.TransferResult.TransferComplete,
            ),
        )
        assertTrue(
            SideloadContract.requiresRecoveryVerification(
                SideloadContract.TransferResult.TransferClosedBeforeDoneDone(
                    servedBytes = 100L,
                    confirmedUniqueBytes = 95L,
                    totalBytes = 100L,
                    percent = 95,
                    message = "closed",
                ),
            ),
        )
        assertTrue(
            SideloadContract.requiresRecoveryVerification(
                SideloadContract.TransferResult.TransferInterruptedAfterPayload(
                    servedBytes = 1L,
                    confirmedUniqueBytes = 0L,
                    totalBytes = 100L,
                    percent = 0,
                    message = "usb vanished",
                ),
            ),
        )
        assertFalse(
            SideloadContract.requiresRecoveryVerification(
                SideloadContract.TransferResult.Cancelled,
            ),
        )
    }

    @Test
    fun `unique coverage percent is bounded and invalid totals fail closed`() {
        assertEquals(0, SideloadContract.coveragePercent(50L, 0L))
        assertEquals(0, SideloadContract.coveragePercent(-1L, 100L))
        assertEquals(100, SideloadContract.coveragePercent(101L, 100L))
    }
}
