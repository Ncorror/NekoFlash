package io.github.ncorror.nekoflash.fastboot.transport

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbRequest
import android.os.Build
import java.io.File
import java.nio.channels.Channels
import java.nio.ByteBuffer

/** Byte-transfer implementation for an already-open Fastboot DATA OUT phase. */
internal class FastbootDataTransfer(
    private val connection: UsbDeviceConnection,
    private val endpointOut: UsbEndpoint,
    private val onEvent: (String, String) -> Unit,
) {
    enum class Mode {
        /** Resolve before download: prefer Native USBFS when source/transport preflight is proven. */
        AUTO,
        NATIVE_USBFS,
        ASYNC_USB_REQUEST,
        SYNC_BULK,
    }

    data class Progress(
        val confirmedBytes: Long,
        val totalBytes: Long,
        val percent: Int,
        val averageBytesPerSecond: Double,
        val etaMs: Long?,
        val mode: Mode,
    )

    data class Result(
        val success: Boolean,
        val cancelled: Boolean = false,
        val message: String = "",
        val bytesTransferred: Long = 0L,
        val mode: Mode,
    )

    @Volatile
    private var cancelled = false

    @Volatile
    private var activeRequest: UsbRequest? = null

    @Volatile
    private var activeSource: FastbootDataSource? = null

    /**
     * Hardware-proven legacy behavior prefers UsbRequest for the Java transport.
     * SYNC_BULK remains an explicit pre-DATA mode and is never selected as an inline retry.
     */
    var mode: Mode = Mode.ASYNC_USB_REQUEST

    fun cancel() {
        cancelled = true
        runCatching { activeSource?.cancel() }
        runCatching { activeRequest?.cancel() }
        runCatching { NativeUsbfsBackend.cancelActiveTransfer() }
    }

    fun transfer(
        file: File,
        label: String,
        onProgress: (Progress) -> Unit = {},
    ): Result {
        val source = FileFastbootDataSource(file)
        if (!source.isReadableFile()) {
            return Result(
                success = false,
                message = "Payload file is unavailable",
                mode = mode,
            )
        }
        return transfer(source, label, onProgress)
    }

    fun transfer(
        source: FastbootDataSource,
        label: String,
        onProgress: (Progress) -> Unit = {},
    ): Result {
        val totalBytes = source.sizeBytes
        if (totalBytes <= 0L) {
            return Result(
                success = false,
                message = "Payload source is empty or has no stable size",
                mode = mode,
            )
        }
        activeSource = source
        return try {
            when (mode) {
                Mode.NATIVE_USBFS -> transferNativeUsbfs(source, label, totalBytes, onProgress)
                Mode.ASYNC_USB_REQUEST -> transferUsbRequest(source, label, totalBytes, onProgress)
                Mode.SYNC_BULK -> transferSyncBulk(source, label, totalBytes, onProgress)
                Mode.AUTO -> Result(
                    success = false,
                    message = "AUTO DATA mode must be resolved before download begins",
                    mode = Mode.AUTO,
                )
            }
        } finally {
            activeSource = null
        }
    }

    private fun transferUsbRequest(
        source: FastbootDataSource,
        label: String,
        totalBytes: Long,
        onProgress: (Progress) -> Unit,
    ): Result {
        val request = UsbRequest()
        if (!request.initialize(connection, endpointOut)) {
            return Result(
                success = false,
                message = "Could not initialize UsbRequest for Fastboot DATA OUT",
                mode = Mode.ASYNC_USB_REQUEST,
            )
        }
        activeRequest = request

        val blockBytes = dataOutBlockBytes()
        val buffer = ByteBuffer.allocateDirect(blockBytes)
        val startedNs = System.nanoTime()
        var totalSent = 0L

        event(
            "FASTBOOT_DATA_TRANSFER_STARTED",
            "label=${label.take(EVENT_LABEL_LIMIT)} mode=${Mode.ASYNC_USB_REQUEST} totalBytes=$totalBytes " +
                "blockBytes=$blockBytes watchdogMs=$DATA_REQUEST_WATCHDOG_MS",
        )
        reportProgress(totalSent, totalBytes, startedNs, Mode.ASYNC_USB_REQUEST, onProgress)

        try {
            source.openInputStream().use { stream ->
                Channels.newChannel(stream).use { input ->
                    while (totalSent < totalBytes) {
                        if (cancelled) {
                            request.cancel()
                            return Result(
                                success = false,
                                cancelled = true,
                                message = "DATA transfer cancelled at offset=$totalSent",
                                bytesTransferred = totalSent,
                                mode = Mode.ASYNC_USB_REQUEST,
                            )
                        }

                        buffer.clear()
                        buffer.limit(
                            (totalBytes - totalSent)
                                .coerceAtMost(blockBytes.toLong())
                                .toInt(),
                        )
                        val read = input.read(buffer)
                        if (read <= 0) break
                        buffer.flip()

                        while (buffer.hasRemaining()) {
                            if (cancelled) {
                                request.cancel()
                                return Result(
                                    success = false,
                                    cancelled = true,
                                    message = "DATA transfer cancelled at offset=$totalSent",
                                    bytesTransferred = totalSent,
                                    mode = Mode.ASYNC_USB_REQUEST,
                                )
                            }

                            val startPosition = buffer.position()
                            val requested = buffer.remaining()
                            val absoluteOffset = totalSent
                            val queuedAtNs = System.nanoTime()
                            val queued = try {
                                request.queue(buffer)
                            } catch (error: Exception) {
                                return Result(
                                    success = false,
                                    message = "UsbRequest.queue failed at offset=$absoluteOffset: ${error.javaClass.simpleName}",
                                    bytesTransferred = totalSent,
                                    mode = Mode.ASYNC_USB_REQUEST,
                                )
                            }
                            if (!queued) {
                                return Result(
                                    success = false,
                                    message = "UsbRequest.queue rejected DATA block at offset=$absoluteOffset",
                                    bytesTransferred = totalSent,
                                    mode = Mode.ASYNC_USB_REQUEST,
                                )
                            }

                            val completed = try {
                                connection.requestWait(DATA_REQUEST_WATCHDOG_MS)
                            } catch (error: Exception) {
                                request.cancel()
                                return Result(
                                    success = false,
                                    message = "UsbRequest.requestWait failed at offset=$absoluteOffset: ${error.javaClass.simpleName}",
                                    bytesTransferred = totalSent,
                                    mode = Mode.ASYNC_USB_REQUEST,
                                )
                            }
                            val elapsedUs = (System.nanoTime() - queuedAtNs) / 1_000L

                            if (cancelled) {
                                request.cancel()
                                return Result(
                                    success = false,
                                    cancelled = true,
                                    message = "DATA transfer cancelled during UsbRequest at offset=$absoluteOffset",
                                    bytesTransferred = totalSent,
                                    mode = Mode.ASYNC_USB_REQUEST,
                                )
                            }
                            if (completed == null) {
                                request.cancel()
                                return Result(
                                    success = false,
                                    message = "UsbRequest watchdog expired at offset=$absoluteOffset after ${elapsedUs}us",
                                    bytesTransferred = totalSent,
                                    mode = Mode.ASYNC_USB_REQUEST,
                                )
                            }
                            if (completed !== request) {
                                request.cancel()
                                return Result(
                                    success = false,
                                    message = "Foreign UsbRequest completion at offset=$absoluteOffset",
                                    bytesTransferred = totalSent,
                                    mode = Mode.ASYNC_USB_REQUEST,
                                )
                            }

                            val confirmed = buffer.position() - startPosition
                            event(
                                "FASTBOOT_DATA_USB_REQUEST_COMPLETED",
                                "offset=$absoluteOffset requested=$requested confirmed=$confirmed elapsedUs=$elapsedUs",
                            )
                            if (confirmed <= 0 || confirmed > requested) {
                                return Result(
                                    success = false,
                                    message = "UsbRequest completed with invalid byte count=$confirmed requested=$requested",
                                    bytesTransferred = totalSent,
                                    mode = Mode.ASYNC_USB_REQUEST,
                                )
                            }
                            totalSent += confirmed
                        }
                        reportProgress(totalSent, totalBytes, startedNs, Mode.ASYNC_USB_REQUEST, onProgress)
                    }
                }
            }
        } catch (error: Exception) {
            return Result(
                success = false,
                message = "Payload read failed: ${error.javaClass.simpleName}: ${error.message ?: "<empty>"}",
                bytesTransferred = totalSent,
                mode = Mode.ASYNC_USB_REQUEST,
            )
        } finally {
            activeRequest = null
            runCatching { request.close() }
        }

        if (totalSent != totalBytes) {
            return Result(
                success = false,
                message = "DATA transfer ended early: sent=$totalSent expected=$totalBytes",
                bytesTransferred = totalSent,
                mode = Mode.ASYNC_USB_REQUEST,
            )
        }
        reportProgress(totalSent, totalBytes, startedNs, Mode.ASYNC_USB_REQUEST, onProgress)
        event(
            "FASTBOOT_DATA_TRANSFER_COMPLETED",
            "label=${label.take(EVENT_LABEL_LIMIT)} mode=${Mode.ASYNC_USB_REQUEST} bytes=$totalSent",
        )
        return Result(
            success = true,
            bytesTransferred = totalSent,
            mode = Mode.ASYNC_USB_REQUEST,
        )
    }

    private fun transferNativeUsbfs(
        source: FastbootDataSource,
        label: String,
        totalBytes: Long,
        onProgress: (Progress) -> Unit,
    ): Result {
        val descriptor = source.openNativeReadDescriptor()
            ?: return Result(
                success = false,
                message = "Native USBFS payload descriptor is unavailable after mode selection",
                mode = Mode.NATIVE_USBFS,
            )
        descriptor.use { payloadDescriptor ->
            NativeUsbfsBackend.transportPreflightError(connection, endpointOut)?.let { reason ->
                return Result(
                    success = false,
                    message = "Native USBFS transport preflight failed: $reason",
                    mode = Mode.NATIVE_USBFS,
                )
            }
            NativeUsbfsBackend.payloadPreflightError(payloadDescriptor, totalBytes)?.let { reason ->
                return Result(
                    success = false,
                    message = "Native USBFS payload preflight failed: $reason",
                    mode = Mode.NATIVE_USBFS,
                )
            }

            val startedNs = System.nanoTime()
            event(
                "FASTBOOT_DATA_TRANSFER_STARTED",
                "label=${label.take(EVENT_LABEL_LIMIT)} mode=${Mode.NATIVE_USBFS} totalBytes=$totalBytes " +
                    "blockBytes=$NATIVE_USBFS_BLOCK_BYTES pipelineDepth=$NATIVE_USBFS_PIPELINE_DEPTH " +
                    "stallTimeoutMs=$NATIVE_USBFS_STALL_TIMEOUT_MS hardTimeoutMs=$NATIVE_USBFS_HARD_TIMEOUT_MS",
            )
            reportProgress(0L, totalBytes, startedNs, Mode.NATIVE_USBFS, onProgress)

            val result = NativeUsbfsBackend.transferBulkOutUrb(
                connection = connection,
                outEndpoint = endpointOut,
                payloadDescriptor = payloadDescriptor,
                totalBytes = totalBytes,
                blockBytes = NATIVE_USBFS_BLOCK_BYTES,
                pipelineDepth = NATIVE_USBFS_PIPELINE_DEPTH,
                stallTimeoutMs = NATIVE_USBFS_STALL_TIMEOUT_MS,
                hardTimeoutMs = NATIVE_USBFS_HARD_TIMEOUT_MS,
                onProgress = { snapshot ->
                    val progress = calculateProgress(
                        confirmedBytes = snapshot.confirmedBytes,
                        totalBytes = snapshot.totalBytes.takeIf { it > 0L } ?: totalBytes,
                        elapsedMs = snapshot.elapsedMs,
                        mode = Mode.NATIVE_USBFS,
                    )
                    runCatching { onProgress(progress) }
                    event(
                        "FASTBOOT_DATA_NATIVE_PROGRESS",
                        "confirmedBytes=${progress.confirmedBytes} submittedBytes=${snapshot.submittedBytes} " +
                            "totalBytes=${progress.totalBytes} percent=${progress.percent} elapsedMs=${snapshot.elapsedMs} " +
                            "stage=${NativeUsbfsBackend.stageLabel(snapshot.stage)}",
                    )
                },
            )

            event(
                if (result.success) "FASTBOOT_DATA_NATIVE_RESULT" else "FASTBOOT_DATA_NATIVE_FAILURE",
                "success=${result.success} confirmedBytes=${result.bytesTransferred} submittedBytes=${result.submittedBytes} " +
                    "stage=${NativeUsbfsBackend.stageLabel(result.stage)} stopErrno=${result.errnoCode} " +
                    "kernelIoctlErrno=${result.kernelIoctlErrno} urbStatus=${result.urbStatus} " +
                    "actualLength=${result.actualLength} pendingAtStop=${result.pendingUrbCountAtStop} " +
                    "lastCompletionAgeMs=${result.lastCompletionAgeMs} drain=${NativeUsbfsBackend.drainLabel(result.drainState)} " +
                    "drainErrno=${result.drainErrno} backendPoisoned=${result.backendPoisoned} elapsedMs=${result.elapsedMs}",
            )

            if (!result.success) {
                return Result(
                    success = false,
                    cancelled = result.cancelled || cancelled,
                    message = result.message,
                    bytesTransferred = result.bytesTransferred,
                    mode = Mode.NATIVE_USBFS,
                )
            }
            if (result.bytesTransferred != totalBytes) {
                return Result(
                    success = false,
                    message = "Native USBFS DATA length mismatch: confirmed=${result.bytesTransferred} expected=$totalBytes",
                    bytesTransferred = result.bytesTransferred,
                    mode = Mode.NATIVE_USBFS,
                )
            }

            reportProgress(totalBytes, totalBytes, startedNs, Mode.NATIVE_USBFS, onProgress)
            event(
                "FASTBOOT_DATA_TRANSFER_COMPLETED",
                "label=${label.take(EVENT_LABEL_LIMIT)} mode=${Mode.NATIVE_USBFS} bytes=$totalBytes elapsedMs=${result.elapsedMs}",
            )
            return Result(
                success = true,
                bytesTransferred = totalBytes,
                mode = Mode.NATIVE_USBFS,
            )
        }
    }

    private fun transferSyncBulk(
        source: FastbootDataSource,
        label: String,
        totalBytes: Long,
        onProgress: (Progress) -> Unit,
    ): Result {
        val chunk = ByteArray(SYNC_BULK_BLOCK_BYTES)
        val startedNs = System.nanoTime()
        var totalSent = 0L

        event(
            "FASTBOOT_DATA_TRANSFER_STARTED",
            "label=${label.take(EVENT_LABEL_LIMIT)} mode=${Mode.SYNC_BULK} totalBytes=$totalBytes " +
                "blockBytes=${chunk.size} timeoutMs=$SYNC_BULK_TIMEOUT_MS",
        )
        reportProgress(totalSent, totalBytes, startedNs, Mode.SYNC_BULK, onProgress)

        try {
            source.openInputStream().use { input ->
                while (totalSent < totalBytes) {
                    if (cancelled) {
                        return Result(
                            success = false,
                            cancelled = true,
                            message = "DATA transfer cancelled at offset=$totalSent",
                            bytesTransferred = totalSent,
                            mode = Mode.SYNC_BULK,
                        )
                    }
                    val remaining = (totalBytes - totalSent)
                        .coerceAtMost(chunk.size.toLong())
                        .toInt()
                    val read = input.read(chunk, 0, remaining)
                    if (read <= 0) break

                    var offset = 0
                    while (offset < read) {
                        if (cancelled) {
                            return Result(
                                success = false,
                                cancelled = true,
                                message = "DATA transfer cancelled at offset=${totalSent + offset}",
                                bytesTransferred = totalSent + offset,
                                mode = Mode.SYNC_BULK,
                            )
                        }
                        val requested = read - offset
                        val absoluteOffset = totalSent + offset
                        val startedCallNs = System.nanoTime()
                        val sent = connection.bulkTransfer(
                            endpointOut,
                            chunk,
                            offset,
                            requested,
                            SYNC_BULK_TIMEOUT_MS,
                        )
                        val elapsedUs = (System.nanoTime() - startedCallNs) / 1_000L
                        event(
                            "FASTBOOT_DATA_SYNC_WRITE",
                            "offset=$absoluteOffset requested=$requested sent=$sent elapsedUs=$elapsedUs",
                        )
                        if (sent <= 0 || sent > requested) {
                            return Result(
                                success = false,
                                message = "Ambiguous sync DATA write at offset=$absoluteOffset sent=$sent requested=$requested",
                                bytesTransferred = absoluteOffset,
                                mode = Mode.SYNC_BULK,
                            )
                        }
                        offset += sent
                    }
                    totalSent += read
                    reportProgress(totalSent, totalBytes, startedNs, Mode.SYNC_BULK, onProgress)
                }
            }
        } catch (error: Exception) {
            return Result(
                success = false,
                message = "Payload read/write failed: ${error.javaClass.simpleName}: ${error.message ?: "<empty>"}",
                bytesTransferred = totalSent,
                mode = Mode.SYNC_BULK,
            )
        }

        if (totalSent != totalBytes) {
            return Result(
                success = false,
                message = "DATA transfer ended early: sent=$totalSent expected=$totalBytes",
                bytesTransferred = totalSent,
                mode = Mode.SYNC_BULK,
            )
        }
        reportProgress(totalSent, totalBytes, startedNs, Mode.SYNC_BULK, onProgress)
        event(
            "FASTBOOT_DATA_TRANSFER_COMPLETED",
            "label=${label.take(EVENT_LABEL_LIMIT)} mode=${Mode.SYNC_BULK} bytes=$totalSent",
        )
        return Result(
            success = true,
            bytesTransferred = totalSent,
            mode = Mode.SYNC_BULK,
        )
    }

    private fun reportProgress(
        confirmedBytes: Long,
        totalBytes: Long,
        startedNs: Long,
        mode: Mode,
        callback: (Progress) -> Unit,
    ) {
        val elapsedMs = ((System.nanoTime() - startedNs) / 1_000_000L).coerceAtLeast(0L)
        val progress = calculateProgress(confirmedBytes, totalBytes, elapsedMs, mode)
        runCatching { callback(progress) }
        event(
            "FASTBOOT_DATA_PROGRESS",
            "mode=$mode confirmedBytes=${progress.confirmedBytes} totalBytes=${progress.totalBytes} " +
                "percent=${progress.percent} elapsedMs=$elapsedMs",
        )
    }

    private fun event(name: String, detail: String) {
        runCatching { onEvent(name, detail) }
    }

    private fun dataOutBlockBytes(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) DATA_BLOCK_BYTES_MODERN else DATA_BLOCK_BYTES_LEGACY

    sealed interface ModeSelection {
        data class Ready(val mode: Mode, val detail: String) : ModeSelection
        data class Rejected(val reason: String) : ModeSelection
    }

    companion object {
        internal fun resolveMode(
            requested: Mode,
            connection: UsbDeviceConnection,
            endpointOut: UsbEndpoint,
            source: FastbootDataSource,
        ): ModeSelection {
            if (requested == Mode.ASYNC_USB_REQUEST || requested == Mode.SYNC_BULK) {
                return ModeSelection.Ready(requested, "explicit Java DATA mode")
            }

            fun nativePreflight(): String? {
                NativeUsbfsBackend.transportPreflightError(connection, endpointOut)?.let { return it }
                val descriptor = source.openNativeReadDescriptor()
                    ?: return "payload source does not expose a native descriptor"
                descriptor.use { owned ->
                    NativeUsbfsBackend.payloadPreflightError(owned, source.sizeBytes)?.let { return it }
                }
                return null
            }

            return chooseMode(requested, nativePreflight())
        }

        internal fun chooseMode(requested: Mode, nativePreflightError: String?): ModeSelection = when (requested) {
            Mode.NATIVE_USBFS -> if (nativePreflightError == null) {
                ModeSelection.Ready(Mode.NATIVE_USBFS, "explicit Native USBFS preflight passed")
            } else {
                ModeSelection.Rejected("Native USBFS preflight failed: $nativePreflightError")
            }
            Mode.AUTO -> if (nativePreflightError == null) {
                ModeSelection.Ready(Mode.NATIVE_USBFS, "AUTO selected Native USBFS after pre-DATA preflight")
            } else {
                ModeSelection.Ready(
                    Mode.ASYNC_USB_REQUEST,
                    "AUTO selected hardware-proven UsbRequest fallback: $nativePreflightError",
                )
            }
            Mode.ASYNC_USB_REQUEST,
            Mode.SYNC_BULK,
            -> ModeSelection.Ready(requested, "explicit Java DATA mode")
        }

        internal fun calculateProgress(
            confirmedBytes: Long,
            totalBytes: Long,
            elapsedMs: Long,
            mode: Mode = Mode.ASYNC_USB_REQUEST,
        ): Progress {
            val safeTotal = totalBytes.coerceAtLeast(0L)
            val confirmed = if (safeTotal > 0L) confirmedBytes.coerceIn(0L, safeTotal) else 0L
            val elapsed = elapsedMs.coerceAtLeast(0L)
            val percent = when {
                safeTotal <= 0L -> 0
                confirmed >= safeTotal -> 100
                else -> ((confirmed.toDouble() / safeTotal.toDouble()) * 100.0)
                    .toInt()
                    .coerceIn(0, 99)
            }
            val average = if (elapsed > 0L && confirmed > 0L) {
                confirmed * 1000.0 / elapsed.toDouble()
            } else {
                0.0
            }
            val remaining = (safeTotal - confirmed).coerceAtLeast(0L)
            val eta = if (safeTotal <= 0L) {
                null
            } else if (remaining == 0L) {
                0L
            } else if (average > 1.0) {
                ((remaining / average) * 1000.0).toLong().coerceAtLeast(0L)
            } else {
                null
            }
            return Progress(
                confirmedBytes = confirmed,
                totalBytes = safeTotal,
                percent = percent,
                averageBytesPerSecond = average,
                etaMs = eta,
                mode = mode,
            )
        }

        private const val DATA_BLOCK_BYTES_LEGACY = 16 * 1024
        private const val DATA_BLOCK_BYTES_MODERN = 256 * 1024
        private const val DATA_REQUEST_WATCHDOG_MS = 30_000L
        private const val NATIVE_USBFS_BLOCK_BYTES = 256 * 1024
        private const val NATIVE_USBFS_PIPELINE_DEPTH = 2
        private const val NATIVE_USBFS_STALL_TIMEOUT_MS = 30_000
        private const val NATIVE_USBFS_HARD_TIMEOUT_MS = 90_000
        private const val SYNC_BULK_BLOCK_BYTES = 16 * 1024
        private const val SYNC_BULK_TIMEOUT_MS = 10_000
        private const val EVENT_LABEL_LIMIT = 120
    }
}
