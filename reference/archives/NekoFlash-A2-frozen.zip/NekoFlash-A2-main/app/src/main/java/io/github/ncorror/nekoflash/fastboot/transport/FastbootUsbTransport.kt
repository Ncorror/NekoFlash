package io.github.ncorror.nekoflash.fastboot.transport

import io.github.ncorror.nekoflash.usb.transport.UsbTransportShutdownPolicy
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import io.github.ncorror.nekoflash.fastboot.codec.FastbootGetVarAllParser
import io.github.ncorror.nekoflash.fastboot.codec.FastbootValueParser
import io.github.ncorror.nekoflash.fastboot.partition.FastbootPartitionInventory
import io.github.ncorror.nekoflash.fastboot.partition.FastbootPartitionInventoryBuilder
import io.github.ncorror.nekoflash.fastboot.partition.FastbootPartitionProbe
import io.github.ncorror.nekoflash.fastboot.partition.FastbootPartitionProbePlanner
import io.github.ncorror.nekoflash.fastboot.partition.FastbootPartitionRisk
import io.github.ncorror.nekoflash.fastboot.partition.FastbootPartitionWarning
import io.github.ncorror.nekoflash.fastboot.partition.FastbootStorageKind
import io.github.ncorror.nekoflash.fastboot.partition.FastbootWarningSeverity
import java.io.File

/**
 * USB transport and synchronous transaction lane for Fastboot.
 *
 * The transport owns USB interface lifetime and Fastboot framing. Product/core/extended
 * diagnostics are consumers of the same generic transaction engine rather than separate
 * protocol paths. DATA is represented as a protocol state even before a higher-level
 * operation supplies its payload/receiver. The transport never reopens itself.
 */
class FastbootUsbTransport(
    private val usbManager: UsbManager,
    private val device: UsbDevice,
    private val preferredInterfaceIndex: Int?,
    private val onEvent: (String, String) -> Unit,
    private val onTransportFailure: (TransportFailureCode, String) -> Unit,
) {
    data class PartitionInventorySummary(
        val productReported: Boolean,
        val topology: String,
        val currentSlot: String?,
        val entryCount: Int,
        val slotFamilyCount: Int,
        val physicalCount: Int,
        val logicalCount: Int,
        val unknownStorageCount: Int,
        val normalCount: Int,
        val advancedCount: Int,
        val criticalCount: Int,
        val incompleteEntryCount: Int,
        val warningCount: Int,
        val duplicateMetadataCount: Int,
        val pointQueryCount: Int,
        val unresolvedPointQueryCount: Int,
        val complete: Boolean,
    )

    data class GetVarAllSummary(
        val transactionComplete: Boolean,
        val supported: Boolean,
        val complete: Boolean,
        val finalStatus: String,
        val variableCount: Int,
        val partitionMetadataCount: Int,
        val ignoredLineCount: Int,
        val duplicateVariableCount: Int,
        val conflictingDuplicateCount: Int,
        val serialReported: Boolean,
        val inventory: PartitionInventorySummary? = null,
    )

    data class ConnectionInfo(
        val product: String?,
        val qualifierFinalType: String,
        val qualifierFinalPayload: String,
        val currentSlot: String? = null,
        val slotCount: String? = null,
        val unlocked: String? = null,
        val maxDownloadSizeRaw: String? = null,
        val maxDownloadSizeBytes: Long? = null,
        val slotSuffix: String? = null,
        val secure: String? = null,
        val serialReported: Boolean = false,
        val versionBootloader: String? = null,
        val antiRollback: String? = null,
        val antiRollbackSource: String? = null,
        val isUserspace: String? = null,
        val superPartitionName: String? = null,
        val snapshotUpdateStatus: String? = null,
        val maxFetchSizeRaw: String? = null,
        val maxFetchSizeBytes: Long? = null,
    )

    enum class TransportFailureCode {
        INTERFACE_NOT_FOUND,
        ENDPOINTS_NOT_FOUND,
        OPEN_FAILED,
        CLAIM_FAILED,
        COMMAND_SHORT_WRITE,
        DATA_TRANSFER_FAILED,
        DATA_FINAL_TIMEOUT,
        PROTOCOL_DESYNC,
        NATIVE_SHUTDOWN_UNPROVEN,
        UNKNOWN,
    }

    private data class MutablePartitionPointProbe(
        val name: String,
        var sizeBytes: Long? = null,
        var type: String? = null,
        var logical: Boolean? = null,
        var hasSlot: Boolean? = null,
        val attemptedFields: MutableSet<FastbootGetVarAllParser.MetadataField> = linkedSetOf(),
        val resolvedFields: MutableSet<FastbootGetVarAllParser.MetadataField> = linkedSetOf(),
    ) {
        fun snapshot(): FastbootPartitionProbe = FastbootPartitionProbe(
            name = name,
            sizeBytes = sizeBytes,
            type = type,
            logical = logical,
            hasSlot = hasSlot,
            attemptedFields = attemptedFields.toSet(),
            resolvedFields = resolvedFields.toSet(),
        )
    }

    private var connection: UsbDeviceConnection? = null
    private var endpointIn: UsbEndpoint? = null
    private var endpointOut: UsbEndpoint? = null
    private var fastbootInterface: UsbInterface? = null

    @Volatile
    private var closed = false

    @Volatile
    private var transportFailureReported = false

    @Volatile
    private var lastConnectionInfo: ConnectionInfo? = null

    @Volatile
    private var transactionState = FastbootTransactionState.DISCONNECTED

    @Volatile
    private var pendingDataSizeBytes: Long? = null

    @Volatile
    private var activeDataTransfer: FastbootDataTransfer? = null

    private val transactionLock = Any()

    val isConnected: Boolean
        get() = !closed && connection != null && fastbootInterface != null && endpointIn != null && endpointOut != null

    internal val isCommandReady: Boolean
        get() = isConnected && transactionState == FastbootTransactionState.IDLE

    internal val currentTransactionState: FastbootTransactionState
        get() = transactionState

    fun connectAndQualify(): ConnectionInfo? {
        if (closed) return null
        if (NativeUsbfsBackend.isProcessBlocked) {
            return transportFailure(
                TransportFailureCode.NATIVE_SHUTDOWN_UNPROVEN,
                "Fastboot connection blocked until app restart after unproven Native USBFS shutdown",
            )
        }

        val usbInterface = findSelectedFastbootInterface()
            ?: return transportFailure(
                TransportFailureCode.INTERFACE_NOT_FOUND,
                "Fastboot interface not found",
            )
        fastbootInterface = usbInterface
        val endpoints = findBulkEndpoints(usbInterface)
        endpointIn = endpoints.first
        endpointOut = endpoints.second
        if (endpointIn == null || endpointOut == null) {
            return transportFailure(
                TransportFailureCode.ENDPOINTS_NOT_FOUND,
                "Fastboot bulk IN/OUT endpoints not found",
            )
        }

        event(
            "FASTBOOT_USB_INTERFACE",
            "interface=${usbInterface.id} class=${usbInterface.interfaceClass} " +
                "subclass=${usbInterface.interfaceSubclass} protocol=${usbInterface.interfaceProtocol} " +
                "in=0x${endpointIn!!.address.toString(16)} out=0x${endpointOut!!.address.toString(16)}",
        )

        connection = usbManager.openDevice(device)
        if (connection == null) {
            return transportFailure(
                TransportFailureCode.OPEN_FAILED,
                "Could not open USB device for Fastboot",
            )
        }
        if (!connection!!.claimInterface(usbInterface, true)) {
            return transportFailure(
                TransportFailureCode.CLAIM_FAILED,
                "Could not claim Fastboot interface",
            )
        }
        transactionState = FastbootTransactionState.IDLE
        event("FASTBOOT_INTERFACE_CLAIMED", "interface=${usbInterface.id}")

        return try {
            if (FastbootTransactionTiming.HANDSHAKE_SETTLE_MS > 0L) {
                Thread.sleep(FastbootTransactionTiming.HANDSHAKE_SETTLE_MS)
            }
            event(
                "FASTBOOT_HANDSHAKE_STARTED",
                "command=$PRODUCT_COMMAND settleMs=${FastbootTransactionTiming.HANDSHAKE_SETTLE_MS} " +
                    "writeTimeoutMs=${FastbootTransactionTiming.HANDSHAKE_WRITE_TIMEOUT_MS} " +
                    "inactivityTimeoutMs=${FastbootTransactionTiming.HANDSHAKE_INACTIVITY_TIMEOUT_MS}",
            )

            val productCollector = FastbootGetVarResponseCollector(PRODUCT_VARIABLE)
            val qualificationResult = executeCommand(
                command = PRODUCT_COMMAND,
                writeTimeoutMs = FastbootTransactionTiming.HANDSHAKE_WRITE_TIMEOUT_MS,
                inactivityTimeoutMs = FastbootTransactionTiming.HANDSHAKE_INACTIVITY_TIMEOUT_MS,
                onProgress = productCollector::onProgress,
            )
            val qualification = when (qualificationResult) {
                is FastbootTransactionResult.Completed -> productCollector.finish(qualificationResult)
                else -> return incompleteConnect(
                    "qualification result=${qualificationResult.resultName()} state=$transactionState",
                )
            }
            val safeProduct = qualification.value?.take(EVENT_PAYLOAD_LIMIT)
            event(
                "FASTBOOT_HANDSHAKE_CONFIRMED",
                "finalType=${qualification.finalType} product=${safeProduct ?: "unreported"} " +
                    "payload=${qualification.finalPayload.take(EVENT_PAYLOAD_LIMIT)}",
            )
            val baseInfo = ConnectionInfo(
                product = safeProduct,
                qualifierFinalType = qualification.finalType,
                qualifierFinalPayload = qualification.finalPayload.take(EVENT_PAYLOAD_LIMIT),
            )

            val diagnostics = collectCoreDiagnostics()
                ?: return incompleteConnect("core diagnostics did not reach a final response")
            val extended = collectExtendedDiagnostics()
                ?: return incompleteConnect("extended diagnostics did not reach a final response")
            baseInfo.copy(
                currentSlot = diagnostics.currentSlot,
                slotCount = diagnostics.slotCount,
                unlocked = diagnostics.unlocked,
                maxDownloadSizeRaw = diagnostics.maxDownloadSizeRaw,
                maxDownloadSizeBytes = diagnostics.maxDownloadSizeBytes,
                slotSuffix = extended.slotSuffix,
                secure = extended.secure,
                serialReported = extended.serialReported,
                versionBootloader = extended.versionBootloader,
                antiRollback = extended.antiRollback,
                antiRollbackSource = extended.antiRollbackSource,
                isUserspace = extended.isUserspace,
                superPartitionName = extended.superPartitionName,
                snapshotUpdateStatus = extended.snapshotUpdateStatus,
                maxFetchSizeRaw = extended.maxFetchSizeRaw,
                maxFetchSizeBytes = extended.maxFetchSizeBytes,
            ).also { lastConnectionInfo = it }
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            event("FASTBOOT_CONNECT_ABORTED", "reason=interrupted")
            close()
            null
        } catch (error: Exception) {
            transportFailure(
                TransportFailureCode.UNKNOWN,
                "Fastboot qualification failed: ${error.message ?: error.javaClass.simpleName}",
            )
        }
    }

    /**
     * Collects `getvar:all` through the common transaction engine. Raw response values
     * remain local to this operation and are reduced to aggregate diagnostics before
     * leaving the transport.
     */
    fun collectGetVarAllSnapshot(): GetVarAllSummary? {
        if (!isCommandReady) {
            event(
                "FASTBOOT_GETVAR_ALL_REJECTED",
                "reason=session_not_ready state=$transactionState connected=$isConnected",
            )
            return null
        }
        event(
            "FASTBOOT_GETVAR_ALL_STARTED",
            "command=${FastbootGetVarAllRequest.COMMAND} " +
                "writeTimeoutMs=${FastbootGetVarAllRequest.WRITE_TIMEOUT_MS} " +
                "inactivityTimeoutMs=${FastbootGetVarAllRequest.INACTIVITY_TIMEOUT_MS}",
        )

        val lines = mutableListOf<String>()
        val result = executeCommand(
            command = FastbootGetVarAllRequest.COMMAND,
            writeTimeoutMs = FastbootGetVarAllRequest.WRITE_TIMEOUT_MS,
            inactivityTimeoutMs = FastbootGetVarAllRequest.INACTIVITY_TIMEOUT_MS,
            redactPayload = true,
        ) { packet ->
            when (packet.type) {
                "INFO", "TEXT" -> {
                    if (packet.payload.isNotBlank()) lines += packet.payload
                    event(
                        "FASTBOOT_GETVAR_ALL_PROGRESS",
                        "type=${packet.type} lines=${lines.size} payloadRedacted=true",
                    )
                }

                else -> event(
                    "FASTBOOT_GETVAR_ALL_UNEXPECTED_RESPONSE",
                    "type=${packet.type} lines=${lines.size} payloadRedacted=true",
                )
            }
        }

        val summary = when (result) {
            is FastbootTransactionResult.Completed -> {
                when (result.finalType) {
                    "OKAY" -> {
                        if (result.finalPayload.isNotBlank()) lines += result.finalPayload
                        val snapshot = FastbootGetVarAllParser.parse(
                            lines = lines,
                            complete = true,
                            finalStatus = "OKAY",
                        )
                        buildGetVarAllSummary(
                            snapshot = snapshot,
                            transactionComplete = true,
                            allowPointBackfill = true,
                        )
                    }

                    "FAIL" -> {
                        val snapshot = FastbootGetVarAllParser.parse(
                            lines = lines,
                            complete = false,
                            finalStatus = "FAIL",
                            finalMessage = result.finalPayload,
                        )
                        buildGetVarAllSummary(
                            snapshot = snapshot,
                            transactionComplete = true,
                            allowPointBackfill = true,
                        )
                    }

                    else -> partialGetVarAllSummary(
                        lines = lines,
                        finalStatus = result.finalType,
                        finalMessage = result.finalPayload,
                    )
                }
            }

            is FastbootTransactionResult.TimedOut -> partialGetVarAllSummary(
                lines = lines,
                finalStatus = "TIMEOUT",
                finalMessage = "No Fastboot response activity for ${result.inactivityMs} ms",
            )

            is FastbootTransactionResult.DataRequested -> partialGetVarAllSummary(
                lines = lines,
                finalStatus = "DATA",
                finalMessage = result.payload,
            )

            is FastbootTransactionResult.NotReady -> {
                event("FASTBOOT_GETVAR_ALL_REJECTED", "reason=transaction_${result.state.name.lowercase()}")
                return null
            }

            FastbootTransactionResult.Closed -> {
                if (lines.isEmpty()) return null
                partialGetVarAllSummary(
                    lines = lines,
                    finalStatus = "CLOSED",
                    finalMessage = null,
                )
            }
        }
        eventGetVarAllComplete(summary)
        return summary
    }

    @Synchronized
    fun close(): Boolean {
        if (closed && connection == null) return true
        closed = true
        activeDataTransfer?.cancel()
        pendingDataSizeBytes = null
        transactionState = FastbootTransactionState.CLOSED

        val drained = awaitNativeUsbfsIdleForClose()
        val nativeState = NativeUsbfsBackend.backendState()
        val canClose = drained && !nativeState.poisoned && UsbTransportShutdownPolicy.canCloseUsb(
            kotlinTransferActive = NativeUsbfsBackend.hasActiveTransfer,
            nativeTransferActive = nativeState.nativeTransferActive,
        )
        if (!canClose) {
            NativeUsbfsBackend.blockProcessAfterUnconfirmedShutdown()
            event(
                "FASTBOOT_TRANSPORT_CLOSE_BLOCKED",
                "device=${device.deviceName} drained=$drained backendPoisoned=${nativeState.poisoned} " +
                    "kotlinNativeActive=${NativeUsbfsBackend.hasActiveTransfer} nativeActive=${nativeState.nativeTransferActive}",
            )
            return false
        }

        activeDataTransfer = null
        fastbootInterface?.let { usbInterface ->
            runCatching { connection?.releaseInterface(usbInterface) }
        }
        runCatching { connection?.close() }
        connection = null
        endpointIn = null
        endpointOut = null
        fastbootInterface = null
        lastConnectionInfo = null
        event("FASTBOOT_TRANSPORT_CLOSED", "device=${device.deviceName}")
        return true
    }

    private fun awaitNativeUsbfsIdleForClose(): Boolean {
        if (!NativeUsbfsBackend.isAvailable) return true
        val startedNs = System.nanoTime()
        while (true) {
            val state = NativeUsbfsBackend.backendState()
            if (!NativeUsbfsBackend.hasActiveTransfer && !state.nativeTransferActive) return true
            val elapsedMs = (System.nanoTime() - startedNs) / 1_000_000L
            if (elapsedMs >= NATIVE_USBFS_CLOSE_WAIT_MS) return false
            try {
                Thread.sleep(NATIVE_USBFS_CLOSE_POLL_MS)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return false
            }
        }
    }

    private fun incompleteConnect(message: String): ConnectionInfo? {
        event(
            "FASTBOOT_CONNECT_INCOMPLETE",
            "message=${message.take(EVENT_PAYLOAD_LIMIT)} state=$transactionState",
        )
        close()
        return null
    }

    private fun collectCoreDiagnostics(): FastbootCoreDiagnostics? {
        val values = linkedMapOf<String, String?>()

        for (variable in FastbootCoreDiagnosticsPlan.variables) {
            val result = queryGetVar(variable) ?: return null
            values[variable.name] = result.value
        }

        val maxDownloadSizeRaw = values["max-download-size"]
        val diagnostics = FastbootCoreDiagnostics(
            currentSlot = values["current-slot"],
            slotCount = values["slot-count"],
            unlocked = values["unlocked"],
            maxDownloadSizeRaw = maxDownloadSizeRaw,
            maxDownloadSizeBytes = FastbootCoreDiagnosticsPlan.parseFastbootSize(maxDownloadSizeRaw),
        )
        event(
            "FASTBOOT_CORE_DIAGNOSTICS_COMPLETE",
            "currentSlot=${diagnostics.currentSlot ?: "unreported"} " +
                "slotCount=${diagnostics.slotCount ?: "unreported"} " +
                "unlocked=${diagnostics.unlocked ?: "unreported"} " +
                "maxDownloadSizeRaw=${diagnostics.maxDownloadSizeRaw ?: "unreported"} " +
                "maxDownloadSizeBytes=${diagnostics.maxDownloadSizeBytes ?: "unreported"}",
        )
        return diagnostics
    }

    private fun collectExtendedDiagnostics(): FastbootExtendedDiagnostics? {
        val values = linkedMapOf<String, String?>()

        for (variable in FastbootExtendedDiagnosticsPlan.beforeAnti) {
            val result = queryGetVar(variable) ?: return null
            values[variable.name] = result.value
        }

        val antiPrimary = queryGetVar(FastbootExtendedDiagnosticsPlan.antiPrimary) ?: return null
        values[FastbootExtendedDiagnosticsPlan.antiPrimary.name] = antiPrimary.value
        val antiRollback: String?
        val antiRollbackSource: String?
        if (FastbootExtendedDiagnosticsPlan.shouldQueryAntiRollback(antiPrimary.value)) {
            val fallback = queryGetVar(FastbootExtendedDiagnosticsPlan.antiFallback) ?: return null
            antiRollback = fallback.value
            antiRollbackSource = if (fallback.value.isNullOrBlank()) null else FastbootExtendedDiagnosticsPlan.antiFallback.name
        } else {
            antiRollback = antiPrimary.value
            antiRollbackSource = FastbootExtendedDiagnosticsPlan.antiPrimary.name
        }

        for (variable in FastbootExtendedDiagnosticsPlan.afterAnti) {
            val result = queryGetVar(variable) ?: return null
            values[variable.name] = result.value
        }

        val maxFetchSizeRaw = values["max-fetch-size"]
        val diagnostics = FastbootExtendedDiagnostics(
            slotSuffix = values["slot-suffix"],
            secure = values["secure"],
            serialReported = !values["serialno"].isNullOrBlank(),
            versionBootloader = values["version-bootloader"],
            antiRollback = antiRollback,
            antiRollbackSource = antiRollbackSource,
            isUserspace = values["is-userspace"],
            superPartitionName = values["super-partition-name"],
            snapshotUpdateStatus = values["snapshot-update-status"],
            maxFetchSizeRaw = maxFetchSizeRaw,
            maxFetchSizeBytes = FastbootCoreDiagnosticsPlan.parseFastbootSize(maxFetchSizeRaw),
        )
        event(
            "FASTBOOT_EXTENDED_DIAGNOSTICS_COMPLETE",
            "slotSuffix=${diagnostics.slotSuffix ?: "unreported"} " +
                "secure=${diagnostics.secure ?: "unreported"} " +
                "serialReported=${diagnostics.serialReported} " +
                "versionBootloader=${diagnostics.versionBootloader ?: "unreported"} " +
                "antiRollback=${diagnostics.antiRollback ?: "unreported"} " +
                "antiSource=${diagnostics.antiRollbackSource ?: "unreported"} " +
                "isUserspace=${diagnostics.isUserspace ?: "unreported"} " +
                "superPartitionName=${diagnostics.superPartitionName ?: "unreported"} " +
                "snapshotUpdateStatus=${diagnostics.snapshotUpdateStatus ?: "unreported"} " +
                "maxFetchSizeRaw=${diagnostics.maxFetchSizeRaw ?: "unreported"} " +
                "maxFetchSizeBytes=${diagnostics.maxFetchSizeBytes ?: "unreported"}",
        )
        return diagnostics
    }

    private fun queryGetVar(
        variable: FastbootCoreDiagnosticsPlan.Variable,
    ): FastbootGetVarResponseCollector.Value? {
        if (!isCommandReady) {
            event(
                "FASTBOOT_DIAGNOSTIC_QUERY_REJECTED",
                "command=${variable.command} state=$transactionState connected=$isConnected",
            )
            return null
        }
        event(
            "FASTBOOT_DIAGNOSTIC_QUERY_STARTED",
            "command=${variable.command} writeTimeoutMs=${variable.writeTimeoutMs} " +
                "inactivityTimeoutMs=${variable.inactivityTimeoutMs}",
        )
        val collector = FastbootGetVarResponseCollector(variable.name)
        val result = executeCommand(
            command = variable.command,
            writeTimeoutMs = variable.writeTimeoutMs,
            inactivityTimeoutMs = variable.inactivityTimeoutMs,
            redactPayload = variable.sensitive,
            onProgress = collector::onProgress,
        )
        val value = when (result) {
            is FastbootTransactionResult.Completed -> collector.finish(result)
            is FastbootTransactionResult.TimedOut -> {
                event(
                    "FASTBOOT_DIAGNOSTIC_QUERY_INCOMPLETE",
                    "variable=${variable.name} reason=inactivity_timeout inactivityMs=${result.inactivityMs}",
                )
                return null
            }
            is FastbootTransactionResult.DataRequested -> {
                event(
                    "FASTBOOT_DIAGNOSTIC_QUERY_INCOMPLETE",
                    "variable=${variable.name} reason=data_requested sizeBytes=${result.sizeBytes ?: -1}",
                )
                return null
            }
            is FastbootTransactionResult.NotReady -> {
                event(
                    "FASTBOOT_DIAGNOSTIC_QUERY_INCOMPLETE",
                    "variable=${variable.name} reason=session_${result.state.name.lowercase()}",
                )
                return null
            }
            FastbootTransactionResult.Closed -> return null
        }
        event(
            "FASTBOOT_DIAGNOSTIC_QUERY_RESULT",
            "variable=${variable.name} finalType=${value.finalType} " +
                "value=${variable.valueForEvent(value.value)?.take(EVENT_PAYLOAD_LIMIT) ?: "unreported"} " +
                "payload=${variable.payloadForEvent(value.finalPayload).take(EVENT_PAYLOAD_LIMIT)}",
        )
        return value
    }

    /**
     * Executes one command on the session's single synchronous Fastboot lane.
     * No command whitelist exists here. INFO/TEXT refresh inactivity, terminal OKAY/FAIL
     * return the lane to IDLE, and DATA is surfaced as a first-class protocol state.
     */
    internal fun executeCommand(
        command: String,
        writeTimeoutMs: Int,
        inactivityTimeoutMs: Int,
        redactCommand: Boolean = false,
        redactPayload: Boolean = false,
        onProgress: (FastbootPacket) -> Unit = {},
    ): FastbootTransactionResult = synchronized(transactionLock) {
        require(command.isNotBlank()) { "Fastboot command must not be blank" }
        require(writeTimeoutMs > 0) { "writeTimeoutMs must be positive" }
        require(inactivityTimeoutMs > 0) { "inactivityTimeoutMs must be positive" }

        if (closed || !isConnected) return@synchronized FastbootTransactionResult.Closed
        if (transactionState != FastbootTransactionState.IDLE) {
            return@synchronized FastbootTransactionResult.NotReady(transactionState)
        }

        val usbConnection = connection ?: return@synchronized FastbootTransactionResult.Closed
        val output = endpointOut ?: return@synchronized FastbootTransactionResult.Closed
        pendingDataSizeBytes = null
        val commandForEvent = if (redactCommand) "<redacted>" else command.take(EVENT_PAYLOAD_LIMIT)
        val commandBytes = command.toByteArray(Charsets.US_ASCII)
        val sent = usbConnection.bulkTransfer(
            output,
            commandBytes,
            0,
            commandBytes.size,
            writeTimeoutMs,
        )
        event(
            "FASTBOOT_COMMAND_SENT",
            "command=$commandForEvent sent=$sent expected=${commandBytes.size}",
        )
        if (sent != commandBytes.size) {
            transportFailure<Unit>(
                TransportFailureCode.COMMAND_SHORT_WRITE,
                "Fastboot command '$commandForEvent' was not written completely (sent=$sent expected=${commandBytes.size})",
            )
            return@synchronized FastbootTransactionResult.Closed
        }

        transactionState = FastbootTransactionState.AWAITING_FINAL
        val inactivityBudget = FastbootInactivityBudget(
            timeoutMs = inactivityTimeoutMs.toLong(),
            startedAtNs = System.nanoTime(),
        )

        while (!closed) {
            val nowNs = System.nanoTime()
            val remainingMs = inactivityBudget.remainingMs(nowNs)
            if (remainingMs <= 0L) {
                pendingDataSizeBytes = null
                transactionState = FastbootTransactionState.STALLED
                event(
                    "FASTBOOT_TRANSACTION_TIMEOUT",
                    "command=$commandForEvent inactivityMs=$inactivityTimeoutMs state=${transactionState.name}",
                )
                return@synchronized FastbootTransactionResult.TimedOut(inactivityTimeoutMs.toLong())
            }

            val packet = readPacket(
                timeoutMs = FastbootTransactionTiming.nextReadTimeoutMs(remainingMs),
                redactPayload = redactPayload,
            ) ?: continue

            inactivityBudget.markActivity(System.nanoTime())
            when (packet.type) {
                "INFO", "TEXT" -> onProgress(packet)

                "OKAY", "FAIL" -> {
                    pendingDataSizeBytes = null
                    transactionState = FastbootTransactionState.IDLE
                    return@synchronized FastbootTransactionResult.Completed(
                        finalType = packet.type,
                        finalPayload = packet.payload,
                    )
                }

                "DATA" -> {
                    val sizeBytes = packet.dataSizeBytes()
                    pendingDataSizeBytes = sizeBytes
                    transactionState = FastbootTransactionState.AWAITING_DATA
                    event(
                        "FASTBOOT_DATA_REQUESTED",
                        "command=$commandForEvent sizeBytes=${sizeBytes ?: -1} payloadRedacted=$redactPayload",
                    )
                    return@synchronized FastbootTransactionResult.DataRequested(
                        sizeBytes = sizeBytes,
                        payload = packet.payload,
                    )
                }

                else -> {
                    onProgress(packet)
                    event(
                        "FASTBOOT_UNEXPECTED_RESPONSE",
                        "command=$commandForEvent type=${packet.type} payloadRedacted=$redactPayload",
                    )
                }
            }
        }

        transactionState = FastbootTransactionState.CLOSED
        FastbootTransactionResult.Closed
    }

    /**
     * Continues the exact command that most recently returned DATA. No second command may
     * enter this lane until the advertised byte count is sent and a terminal response is read.
     * Any ambiguous OUT failure makes the USB session unusable; switching transport mid-DATA
     * is intentionally forbidden because the accepted byte count can no longer be proven.
     */
    internal fun continueDataOut(
        file: File,
        label: String,
        expectedBytes: Long = file.length(),
        finalInactivityTimeoutMs: Int = DATA_FINAL_INACTIVITY_TIMEOUT_MS,
        mode: FastbootDataTransfer.Mode = FastbootDataTransfer.Mode.ASYNC_USB_REQUEST,
        onProgress: (FastbootDataTransfer.Progress) -> Unit = {},
    ): FastbootDataContinuationResult {
        val source = FileFastbootDataSource(file)
        if (!source.isReadableFile()) return FastbootDataContinuationResult.Closed
        return continueDataOut(
            source = source,
            label = label,
            expectedBytes = expectedBytes,
            finalInactivityTimeoutMs = finalInactivityTimeoutMs,
            mode = mode,
            onProgress = onProgress,
        )
    }

    internal fun continueDataOut(
        source: FastbootDataSource,
        label: String,
        expectedBytes: Long = source.sizeBytes,
        finalInactivityTimeoutMs: Int = DATA_FINAL_INACTIVITY_TIMEOUT_MS,
        mode: FastbootDataTransfer.Mode = FastbootDataTransfer.Mode.ASYNC_USB_REQUEST,
        onProgress: (FastbootDataTransfer.Progress) -> Unit = {},
    ): FastbootDataContinuationResult = synchronized(transactionLock) {
        require(expectedBytes > 0L) { "expectedBytes must be positive" }
        require(finalInactivityTimeoutMs > 0) { "finalInactivityTimeoutMs must be positive" }

        if (closed || !isConnected) return@synchronized FastbootDataContinuationResult.Closed
        if (transactionState != FastbootTransactionState.AWAITING_DATA) {
            return@synchronized FastbootDataContinuationResult.NotReady(transactionState)
        }

        val advertisedBytes = pendingDataSizeBytes
        if (advertisedBytes == null || advertisedBytes != expectedBytes || source.sizeBytes != expectedBytes) {
            val message =
                "Fastboot DATA size mismatch: advertised=${advertisedBytes ?: "invalid"} " +
                    "expected=$expectedBytes source=${source.sizeBytes}"
            event("FASTBOOT_DATA_SIZE_MISMATCH", message)
            val result = FastbootDataContinuationResult.SizeMismatch(
                expectedBytes = expectedBytes,
                advertisedBytes = advertisedBytes,
            )
            invalidateTransport(TransportFailureCode.PROTOCOL_DESYNC, message)
            return@synchronized result
        }

        val usbConnection = connection ?: return@synchronized FastbootDataContinuationResult.Closed
        val output = endpointOut ?: return@synchronized FastbootDataContinuationResult.Closed
        val transfer = FastbootDataTransfer(usbConnection, output, ::event).also {
            it.mode = mode
            activeDataTransfer = it
        }
        transactionState = FastbootTransactionState.SENDING_DATA
        val transferResult = try {
            transfer.transfer(source = source, label = label, onProgress = onProgress)
        } finally {
            activeDataTransfer = null
        }

        if (!transferResult.success) {
            pendingDataSizeBytes = null
            val result = FastbootDataContinuationResult.TransferFailed(
                message = transferResult.message,
                bytesTransferred = transferResult.bytesTransferred,
                cancelled = transferResult.cancelled,
                mode = transferResult.mode,
            )
            invalidateTransport(
                TransportFailureCode.DATA_TRANSFER_FAILED,
                "Fastboot DATA transfer failed after ${transferResult.bytesTransferred}/$expectedBytes bytes: " +
                    transferResult.message,
            )
            return@synchronized result
        }

        pendingDataSizeBytes = null
        transactionState = FastbootTransactionState.AWAITING_DATA_FINAL
        val inactivityBudget = FastbootInactivityBudget(
            timeoutMs = finalInactivityTimeoutMs.toLong(),
            startedAtNs = System.nanoTime(),
        )

        while (!closed) {
            val remainingMs = inactivityBudget.remainingMs(System.nanoTime())
            if (remainingMs <= 0L) {
                val result = FastbootDataContinuationResult.TimedOut(
                    inactivityMs = finalInactivityTimeoutMs.toLong(),
                    bytesTransferred = transferResult.bytesTransferred,
                    mode = transferResult.mode,
                )
                event(
                    "FASTBOOT_DATA_FINAL_TIMEOUT",
                    "label=${label.take(EVENT_PAYLOAD_LIMIT)} inactivityMs=$finalInactivityTimeoutMs " +
                        "bytesTransferred=${transferResult.bytesTransferred}",
                )
                invalidateTransport(
                    TransportFailureCode.DATA_FINAL_TIMEOUT,
                    "Fastboot DATA final response timed out after $finalInactivityTimeoutMs ms",
                )
                return@synchronized result
            }

            val packet = readPacket(
                timeoutMs = FastbootTransactionTiming.nextReadTimeoutMs(remainingMs),
            ) ?: continue
            inactivityBudget.markActivity(System.nanoTime())

            when (packet.type) {
                "INFO", "TEXT" -> onProgressPacketSafely(packet)
                "OKAY", "FAIL" -> {
                    transactionState = FastbootTransactionState.IDLE
                    event(
                        "FASTBOOT_DATA_FINAL",
                        "label=${label.take(EVENT_PAYLOAD_LIMIT)} type=${packet.type} " +
                            "bytesTransferred=${transferResult.bytesTransferred}",
                    )
                    return@synchronized FastbootDataContinuationResult.Completed(
                        finalType = packet.type,
                        finalPayload = packet.payload,
                        bytesTransferred = transferResult.bytesTransferred,
                        mode = transferResult.mode,
                    )
                }
                else -> {
                    val message = "Unexpected Fastboot response after DATA: type=${packet.type}"
                    val result = FastbootDataContinuationResult.TransferFailed(
                        message = message,
                        bytesTransferred = transferResult.bytesTransferred,
                        cancelled = false,
                        mode = transferResult.mode,
                    )
                    invalidateTransport(TransportFailureCode.PROTOCOL_DESYNC, message)
                    return@synchronized result
                }
            }
        }

        FastbootDataContinuationResult.Closed
    }

    /**
     * Resolves a base partition to the device's current slot without issuing any mutation.
     * Unknown/unsupported slot metadata fails closed; callers can instead choose an explicit
     * concrete partition token in the Quick Flash review.
     */
    internal fun resolveCurrentSlotFlashTarget(partition: String): FastbootFlashTargetResult =
        synchronized(transactionLock) {
            if (closed || !isConnected || transactionState != FastbootTransactionState.IDLE) {
                return@synchronized FastbootFlashTargetResult.Failed(
                    message = "Fastboot session is not ready for slot resolution: state=$transactionState",
                    sessionCorrupted = transactionState == FastbootTransactionState.STALLED,
                )
            }
            val normalized = FastbootFlashTargetPolicy.normalizePartition(partition)
                ?: return@synchronized FastbootFlashTargetResult.Failed("Invalid partition name")
            val base = normalized.substringBefore(':')
            val hasSlot = queryGetVar(FastbootCoreDiagnosticsPlan.Variable("has-slot:$base"))
                ?: return@synchronized FastbootFlashTargetResult.Failed(
                    message = "Could not obtain terminal has-slot metadata for $base",
                    sessionCorrupted = transactionState != FastbootTransactionState.IDLE,
                )
            if (hasSlot.finalType != "OKAY") {
                return@synchronized FastbootFlashTargetResult.Failed(
                    "Bootloader does not provide reliable has-slot metadata for $base",
                )
            }
            when (FastbootValueParser.parseBoolean(hasSlot.value)) {
                false -> FastbootFlashTargetResult.Resolved(
                    target = normalized,
                    slot = null,
                    slotted = false,
                )

                true -> {
                    val current = queryGetVar(FastbootCoreDiagnosticsPlan.Variable("current-slot"))
                        ?: return@synchronized FastbootFlashTargetResult.Failed(
                            message = "Could not obtain terminal current-slot metadata",
                            sessionCorrupted = transactionState != FastbootTransactionState.IDLE,
                        )
                    val slot = if (current.finalType == "OKAY") {
                        FastbootFlashTargetPolicy.normalizeSlot(current.value)
                    } else {
                        null
                    } ?: return@synchronized FastbootFlashTargetResult.Failed(
                        "Device reports a slotted partition but current-slot is unavailable",
                    )
                    FastbootFlashTargetResult.Resolved(
                        target = FastbootFlashTargetPolicy.applySlot(normalized, slot),
                        slot = slot,
                        slotted = true,
                    )
                }

                null -> FastbootFlashTargetResult.Failed(
                    "Bootloader returned an unrecognized has-slot value for $base",
                )
            }
        }

    /**
     * Safety-gated flash flow built entirely on the generic command/DATA transaction lane.
     * The bootloader unlock state is queried immediately before `download:` and the operation
     * fails closed unless that fresh value explicitly means yes/true/1.
     */
    internal fun flashPartitionDetailed(
        partition: String,
        file: File,
        dataMode: FastbootDataTransfer.Mode = FastbootDataTransfer.Mode.AUTO,
        onDataProgress: (FastbootDataTransfer.Progress) -> Unit = {},
        onStage: (FastbootFlashStage) -> Unit = {},
        isCancellationRequested: () -> Boolean = { false },
        beforePartitionWrite: () -> Boolean = { true },
    ): FastbootFlashResult {
        val source = FileFastbootDataSource(file)
        if (!source.isReadableFile()) {
            return FastbootFlashResult.fail(
                stage = FastbootFlashStage.VALIDATION,
                kind = FastbootFlashFailureKind.VALIDATION,
                message = "Payload file is unavailable: ${file.name}",
            )
        }
        return flashPartitionDetailed(
            partition = partition,
            source = source,
            dataMode = dataMode,
            onDataProgress = onDataProgress,
            onStage = onStage,
            isCancellationRequested = isCancellationRequested,
            beforePartitionWrite = beforePartitionWrite,
        )
    }

    internal fun flashPartitionDetailed(
        partition: String,
        source: FastbootDataSource,
        dataMode: FastbootDataTransfer.Mode = FastbootDataTransfer.Mode.AUTO,
        onDataProgress: (FastbootDataTransfer.Progress) -> Unit = {},
        onStage: (FastbootFlashStage) -> Unit = {},
        isCancellationRequested: () -> Boolean = { false },
        beforePartitionWrite: () -> Boolean = { true },
    ): FastbootFlashResult = synchronized(transactionLock) {
        reportFlashStage(onStage, FastbootFlashStage.VALIDATION)
        if (closed || !isConnected || transactionState != FastbootTransactionState.IDLE) {
            return@synchronized FastbootFlashResult.fail(
                stage = FastbootFlashStage.VALIDATION,
                kind = FastbootFlashFailureKind.SESSION_UNAVAILABLE,
                message = "Fastboot session is not ready: state=$transactionState connected=$isConnected",
                sessionCorrupted = transactionState == FastbootTransactionState.STALLED,
            )
        }
        if (isCancellationRequested()) {
            return@synchronized FastbootFlashResult.fail(
                stage = FastbootFlashStage.VALIDATION,
                kind = FastbootFlashFailureKind.CANCELLED,
                message = "Flash cancelled before authorization",
            )
        }
        val preliminaryPlan = when (
            val planned = FastbootFlashPolicy.plan(
                partitionRaw = partition,
                payloadBytes = source.sizeBytes,
                maxDownloadSizeBytes = null,
            )
        ) {
            is FastbootFlashPolicy.PlanResult.Ready -> planned.plan
            is FastbootFlashPolicy.PlanResult.Rejected -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.VALIDATION,
                    kind = FastbootFlashFailureKind.VALIDATION,
                    message = "Flash plan rejected: ${planned.reason}",
                )
            }
        }

        reportFlashStage(onStage, FastbootFlashStage.AUTHORIZATION)
        event(
            "FASTBOOT_FLASH_AUTHORIZATION_STARTED",
            "partition=${partition.take(EVENT_PAYLOAD_LIMIT)} payloadBytes=${source.sizeBytes}",
        )
        val unlockedQuery = queryGetVar(FastbootCoreDiagnosticsPlan.Variable("unlocked"))
        if (unlockedQuery == null) {
            val corrupted = transactionState != FastbootTransactionState.IDLE
            val result = FastbootFlashResult.fail(
                stage = FastbootFlashStage.AUTHORIZATION,
                kind = FastbootFlashFailureKind.TRANSPORT,
                message = "Could not obtain a terminal getvar:unlocked response",
                sessionCorrupted = corrupted,
            )
            if (corrupted) {
                invalidateTransport(
                    TransportFailureCode.PROTOCOL_DESYNC,
                    "Safety query getvar:unlocked did not reach a terminal response",
                )
            }
            return@synchronized result
        }
        lastConnectionInfo = lastConnectionInfo?.copy(unlocked = unlockedQuery.value)
        when (val authorization = FastbootFlashPolicy.authorize(unlockedQuery.value)) {
            FastbootFlashPolicy.Authorization.Allowed -> event(
                "FASTBOOT_FLASH_AUTHORIZED",
                "partition=${partition.take(EVENT_PAYLOAD_LIMIT)} unlocked=explicit_yes",
            )
            is FastbootFlashPolicy.Authorization.Blocked -> {
                event(
                    "FASTBOOT_FLASH_BLOCKED",
                    "partition=${partition.take(EVENT_PAYLOAD_LIMIT)} reason=${authorization.reason}",
                )
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.AUTHORIZATION,
                    kind = FastbootFlashFailureKind.SAFETY,
                    message = "Flash blocked by bootloader safety policy: ${authorization.reason}",
                )
            }
        }

        val maxDownloadQuery = queryGetVar(FastbootCoreDiagnosticsPlan.Variable("max-download-size"))
        if (maxDownloadQuery == null) {
            val corrupted = transactionState != FastbootTransactionState.IDLE
            val result = FastbootFlashResult.fail(
                stage = FastbootFlashStage.VALIDATION,
                kind = FastbootFlashFailureKind.TRANSPORT,
                message = "Could not obtain a terminal getvar:max-download-size response",
                sessionCorrupted = corrupted,
            )
            if (corrupted) {
                invalidateTransport(
                    TransportFailureCode.PROTOCOL_DESYNC,
                    "Safety query getvar:max-download-size did not reach a terminal response",
                )
            }
            return@synchronized result
        }
        val freshMaxDownloadBytes = when (
            val deviceLimit = FastbootFlashPolicy.requireDeviceLimit(
                finalType = maxDownloadQuery.finalType,
                rawValue = maxDownloadQuery.value,
            )
        ) {
            is FastbootFlashPolicy.DeviceLimitResult.Available -> deviceLimit.bytes
            FastbootFlashPolicy.DeviceLimitResult.Unavailable -> {
                event(
                    "FASTBOOT_FLASH_BLOCKED",
                    "partition=${partition.take(EVENT_PAYLOAD_LIMIT)} reason=max_download_size_unavailable_or_invalid",
                )
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.VALIDATION,
                    kind = FastbootFlashFailureKind.SAFETY,
                    message = "Flash blocked because max-download-size is unavailable or invalid",
                )
            }
        }
        lastConnectionInfo = lastConnectionInfo?.copy(
            maxDownloadSizeRaw = maxDownloadQuery.value,
            maxDownloadSizeBytes = freshMaxDownloadBytes,
        )

        val partitionSizeVariable = "partition-size:${preliminaryPlan.partition}"
        val partitionSizeQuery = queryGetVar(FastbootCoreDiagnosticsPlan.Variable(partitionSizeVariable))
        if (partitionSizeQuery == null) {
            val corrupted = transactionState != FastbootTransactionState.IDLE
            val result = FastbootFlashResult.fail(
                stage = FastbootFlashStage.VALIDATION,
                kind = FastbootFlashFailureKind.TRANSPORT,
                message = "Could not obtain a terminal getvar:$partitionSizeVariable response",
                partition = preliminaryPlan.partition,
                sessionCorrupted = corrupted,
            )
            if (corrupted) {
                invalidateTransport(
                    TransportFailureCode.PROTOCOL_DESYNC,
                    "Safety query getvar:$partitionSizeVariable did not reach a terminal response",
                )
            }
            return@synchronized result
        }
        val freshPartitionCapacityBytes = when (
            val capacity = FastbootFlashPolicy.requirePartitionCapacity(
                finalType = partitionSizeQuery.finalType,
                rawValue = partitionSizeQuery.value,
            )
        ) {
            is FastbootFlashPolicy.PartitionCapacityResult.Available -> capacity.bytes
            FastbootFlashPolicy.PartitionCapacityResult.Unavailable -> {
                event(
                    "FASTBOOT_FLASH_BLOCKED",
                    "partition=${preliminaryPlan.partition.take(EVENT_PAYLOAD_LIMIT)} " +
                        "reason=partition_size_unavailable_or_invalid",
                )
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.VALIDATION,
                    kind = FastbootFlashFailureKind.SAFETY,
                    message = "Flash blocked because target partition size is unavailable or invalid",
                    partition = preliminaryPlan.partition,
                )
            }
        }
        event(
            "FASTBOOT_FLASH_TARGET_CAPACITY",
            "partition=${preliminaryPlan.partition.take(EVENT_PAYLOAD_LIMIT)} " +
                "partitionBytes=$freshPartitionCapacityBytes payloadBytes=${source.sizeBytes}",
        )

        val plan = when (
            val planned = FastbootFlashPolicy.plan(
                partitionRaw = preliminaryPlan.partition,
                payloadBytes = source.sizeBytes,
                maxDownloadSizeBytes = freshMaxDownloadBytes,
                partitionCapacityBytes = freshPartitionCapacityBytes,
            )
        ) {
            is FastbootFlashPolicy.PlanResult.Ready -> planned.plan
            is FastbootFlashPolicy.PlanResult.Rejected -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.VALIDATION,
                    kind = FastbootFlashFailureKind.VALIDATION,
                    message = "Flash plan rejected: ${planned.reason}",
                )
            }
        }

        val usbConnectionForData = connection ?: return@synchronized FastbootFlashResult.fail(
            stage = FastbootFlashStage.VALIDATION,
            kind = FastbootFlashFailureKind.SESSION_UNAVAILABLE,
            message = "Fastboot USB connection disappeared before DATA mode selection",
            partition = plan.partition,
            sessionCorrupted = true,
        )
        val outputForData = endpointOut ?: return@synchronized FastbootFlashResult.fail(
            stage = FastbootFlashStage.VALIDATION,
            kind = FastbootFlashFailureKind.SESSION_UNAVAILABLE,
            message = "Fastboot OUT endpoint disappeared before DATA mode selection",
            partition = plan.partition,
            sessionCorrupted = true,
        )
        val resolvedDataMode = when (
            val selection = FastbootDataTransfer.resolveMode(
                requested = dataMode,
                connection = usbConnectionForData,
                endpointOut = outputForData,
                source = source,
            )
        ) {
            is FastbootDataTransfer.ModeSelection.Ready -> {
                event(
                    "FASTBOOT_DATA_MODE_SELECTED",
                    "requested=$dataMode selected=${selection.mode} detail=${selection.detail.take(EVENT_PAYLOAD_LIMIT)}",
                )
                selection.mode
            }
            is FastbootDataTransfer.ModeSelection.Rejected -> {
                event(
                    "FASTBOOT_FLASH_BLOCKED",
                    "partition=${plan.partition.take(EVENT_PAYLOAD_LIMIT)} reason=data_mode_preflight_failed " +
                        "requested=$dataMode detail=${selection.reason.take(EVENT_PAYLOAD_LIMIT)}",
                )
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.VALIDATION,
                    kind = FastbootFlashFailureKind.SAFETY,
                    message = selection.reason,
                    partition = plan.partition,
                )
            }
        }

        if (isCancellationRequested()) {
            return@synchronized FastbootFlashResult.fail(
                stage = FastbootFlashStage.SEND_DOWNLOAD,
                kind = FastbootFlashFailureKind.CANCELLED,
                message = "Flash cancelled before DATA negotiation",
                partition = plan.partition,
            )
        }

        reportFlashStage(onStage, FastbootFlashStage.SEND_DOWNLOAD)
        event(
            "FASTBOOT_FLASH_DOWNLOAD_STARTED",
            "partition=${plan.partition} payloadBytes=${plan.payloadBytes} mode=$resolvedDataMode requestedMode=$dataMode",
        )
        val download = executeCommand(
            command = plan.downloadCommand,
            writeTimeoutMs = FLASH_COMMAND_WRITE_TIMEOUT_MS,
            inactivityTimeoutMs = DOWNLOAD_REQUEST_INACTIVITY_TIMEOUT_MS,
        )
        when (download) {
            is FastbootTransactionResult.DataRequested -> {
                if (download.sizeBytes != plan.payloadBytes) {
                    val message =
                        "Bootloader DATA size does not match payload: advertised=${download.sizeBytes ?: "invalid"} " +
                            "expected=${plan.payloadBytes}"
                    val result = FastbootFlashResult.fail(
                        stage = FastbootFlashStage.WAIT_DATA,
                        kind = FastbootFlashFailureKind.PROTOCOL,
                        message = message,
                        partition = plan.partition,
                        sessionCorrupted = true,
                    )
                    invalidateTransport(TransportFailureCode.PROTOCOL_DESYNC, message)
                    return@synchronized result
                }
            }
            is FastbootTransactionResult.Completed -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.WAIT_DATA,
                    kind = FastbootFlashFailureKind.PROTOCOL,
                    message = "Expected DATA, got ${download.finalType}: ${download.finalPayload}",
                    partition = plan.partition,
                )
            }
            is FastbootTransactionResult.TimedOut -> {
                val result = FastbootFlashResult.fail(
                    stage = FastbootFlashStage.WAIT_DATA,
                    kind = FastbootFlashFailureKind.TRANSPORT,
                    message = "Timed out waiting for DATA request",
                    partition = plan.partition,
                    sessionCorrupted = true,
                )
                invalidateTransport(
                    TransportFailureCode.PROTOCOL_DESYNC,
                    "download:${plan.partition} timed out before DATA",
                )
                return@synchronized result
            }
            is FastbootTransactionResult.NotReady -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.SEND_DOWNLOAD,
                    kind = FastbootFlashFailureKind.SESSION_UNAVAILABLE,
                    message = "Fastboot lane not ready: ${download.state}",
                    partition = plan.partition,
                    sessionCorrupted = download.state == FastbootTransactionState.STALLED,
                )
            }
            FastbootTransactionResult.Closed -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.SEND_DOWNLOAD,
                    kind = FastbootFlashFailureKind.TRANSPORT,
                    message = "Fastboot transport closed while sending download command",
                    partition = plan.partition,
                    sessionCorrupted = true,
                )
            }
        }

        reportFlashStage(onStage, FastbootFlashStage.DATA_TRANSFER)
        val dataDone = continueDataOut(
            source = source,
            label = "flash:${plan.partition}",
            expectedBytes = plan.payloadBytes,
            finalInactivityTimeoutMs = DATA_FINAL_INACTIVITY_TIMEOUT_MS,
            mode = resolvedDataMode,
            onProgress = onDataProgress,
        )
        val transferred = when (dataDone) {
            is FastbootDataContinuationResult.Completed -> {
                if (dataDone.finalType != "OKAY") {
                    return@synchronized FastbootFlashResult.fail(
                        stage = FastbootFlashStage.WAIT_DOWNLOAD_FINAL,
                        kind = FastbootFlashFailureKind.PROTOCOL,
                        message = dataDone.finalPayload.ifBlank { "Bootloader rejected downloaded payload" },
                        partition = plan.partition,
                        dataBytesTransferred = dataDone.bytesTransferred,
                    )
                }
                dataDone.bytesTransferred
            }
            is FastbootDataContinuationResult.TransferFailed -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.DATA_TRANSFER,
                    kind = if (dataDone.cancelled) FastbootFlashFailureKind.CANCELLED else FastbootFlashFailureKind.TRANSPORT,
                    message = dataDone.message,
                    partition = plan.partition,
                    dataBytesTransferred = dataDone.bytesTransferred,
                    sessionCorrupted = true,
                )
            }
            is FastbootDataContinuationResult.SizeMismatch -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.WAIT_DATA,
                    kind = FastbootFlashFailureKind.PROTOCOL,
                    message = "DATA size mismatch",
                    partition = plan.partition,
                    sessionCorrupted = true,
                )
            }
            is FastbootDataContinuationResult.TimedOut -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.WAIT_DOWNLOAD_FINAL,
                    kind = FastbootFlashFailureKind.TRANSPORT,
                    message = "Timed out waiting for final response after DATA",
                    partition = plan.partition,
                    dataBytesTransferred = dataDone.bytesTransferred,
                    sessionCorrupted = true,
                )
            }
            is FastbootDataContinuationResult.NotReady -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.DATA_TRANSFER,
                    kind = FastbootFlashFailureKind.SESSION_UNAVAILABLE,
                    message = "Fastboot DATA lane not ready: ${dataDone.state}",
                    partition = plan.partition,
                    sessionCorrupted = dataDone.state == FastbootTransactionState.STALLED,
                )
            }
            FastbootDataContinuationResult.Closed -> {
                return@synchronized FastbootFlashResult.fail(
                    stage = FastbootFlashStage.DATA_TRANSFER,
                    kind = FastbootFlashFailureKind.TRANSPORT,
                    message = "Fastboot transport closed during DATA",
                    partition = plan.partition,
                    sessionCorrupted = true,
                )
            }
        }

        // This is the last safe cancellation boundary. The payload is downloaded but no
        // partition mutation has been requested yet. After SEND_FLASH is published, cancellation
        // must be rejected and the terminal flash response must be observed instead of closing USB.
        if (isCancellationRequested()) {
            return@synchronized FastbootFlashResult.fail(
                stage = FastbootFlashStage.SEND_FLASH,
                kind = FastbootFlashFailureKind.CANCELLED,
                message = "Flash cancelled after DATA and before partition write",
                partition = plan.partition,
                dataBytesTransferred = transferred,
            )
        }

        // Atomically cross the owner-level cancellation boundary before sending flash:. If a
        // cancellation request won the race, the owner returns false and no mutation command is
        // sent. If this callback wins, later cancellation must be rejected until terminal status.
        if (!beforePartitionWrite()) {
            return@synchronized FastbootFlashResult.fail(
                stage = FastbootFlashStage.SEND_FLASH,
                kind = FastbootFlashFailureKind.CANCELLED,
                message = "Flash stopped at the partition-write cancellation boundary",
                partition = plan.partition,
                dataBytesTransferred = transferred,
            )
        }

        reportFlashStage(onStage, FastbootFlashStage.SEND_FLASH)
        event(
            "FASTBOOT_FLASH_WRITE_STARTED",
            "partition=${plan.partition} bytes=$transferred inactivityTimeoutMs=$FLASH_FINAL_INACTIVITY_TIMEOUT_MS",
        )
        val flash = executeCommand(
            command = "flash:${plan.partition}",
            writeTimeoutMs = FLASH_COMMAND_WRITE_TIMEOUT_MS,
            inactivityTimeoutMs = FLASH_FINAL_INACTIVITY_TIMEOUT_MS,
        )
        when (flash) {
            is FastbootTransactionResult.Completed -> {
                if (flash.finalType == "OKAY") {
                    reportFlashStage(onStage, FastbootFlashStage.COMPLETE)
                    event("FASTBOOT_FLASH_COMPLETED", "partition=${plan.partition} bytes=$transferred")
                    FastbootFlashResult.ok(plan.partition, transferred)
                } else {
                    FastbootFlashResult.fail(
                        stage = FastbootFlashStage.WAIT_FLASH_FINAL,
                        kind = FastbootFlashFailureKind.PROTOCOL,
                        message = flash.finalPayload.ifBlank { "Bootloader rejected flash command" },
                        partition = plan.partition,
                        dataBytesTransferred = transferred,
                    )
                }
            }
            is FastbootTransactionResult.DataRequested -> {
                val message = "Unexpected DATA response to flash:${plan.partition}"
                val result = FastbootFlashResult.fail(
                    stage = FastbootFlashStage.WAIT_FLASH_FINAL,
                    kind = FastbootFlashFailureKind.PROTOCOL,
                    message = message,
                    partition = plan.partition,
                    dataBytesTransferred = transferred,
                    sessionCorrupted = true,
                )
                invalidateTransport(TransportFailureCode.PROTOCOL_DESYNC, message)
                result
            }
            is FastbootTransactionResult.TimedOut -> {
                val result = FastbootFlashResult.fail(
                    stage = FastbootFlashStage.WAIT_FLASH_FINAL,
                    kind = FastbootFlashFailureKind.TRANSPORT,
                    message = "Timed out waiting for flash completion",
                    partition = plan.partition,
                    dataBytesTransferred = transferred,
                    sessionCorrupted = true,
                )
                invalidateTransport(
                    TransportFailureCode.PROTOCOL_DESYNC,
                    "flash:${plan.partition} timed out before terminal response",
                )
                result
            }
            is FastbootTransactionResult.NotReady -> FastbootFlashResult.fail(
                stage = FastbootFlashStage.SEND_FLASH,
                kind = FastbootFlashFailureKind.SESSION_UNAVAILABLE,
                message = "Fastboot lane not ready: ${flash.state}",
                partition = plan.partition,
                dataBytesTransferred = transferred,
                sessionCorrupted = flash.state == FastbootTransactionState.STALLED,
            )
            FastbootTransactionResult.Closed -> FastbootFlashResult.fail(
                stage = FastbootFlashStage.SEND_FLASH,
                kind = FastbootFlashFailureKind.TRANSPORT,
                message = "Fastboot transport closed during flash",
                partition = plan.partition,
                dataBytesTransferred = transferred,
                sessionCorrupted = true,
            )
        }
    }

    private fun reportFlashStage(
        callback: (FastbootFlashStage) -> Unit,
        stage: FastbootFlashStage,
    ) {
        runCatching { callback(stage) }
    }

    private fun onProgressPacketSafely(packet: FastbootPacket) {
        event(
            "FASTBOOT_DATA_FINAL_PROGRESS",
            "type=${packet.type} payload=${packet.payload.take(EVENT_PAYLOAD_LIMIT)}",
        )
    }

    private fun partialGetVarAllSummary(
        lines: List<String>,
        finalStatus: String,
        finalMessage: String?,
    ): GetVarAllSummary {
        val snapshot = FastbootGetVarAllParser.parse(
            lines = lines,
            complete = false,
            finalStatus = finalStatus,
            finalMessage = finalMessage,
        )
        return buildGetVarAllSummary(
            snapshot = snapshot,
            transactionComplete = false,
            allowPointBackfill = false,
        )
    }

    private fun buildGetVarAllSummary(
        snapshot: FastbootGetVarAllParser.Result,
        transactionComplete: Boolean,
        allowPointBackfill: Boolean,
    ): GetVarAllSummary {
        val connectionInfo = lastConnectionInfo
        val supplemental = linkedMapOf<String, String>()
        connectionInfo?.currentSlot?.takeIf { it.isNotBlank() }?.let { supplemental["current-slot"] = it }
        connectionInfo?.slotCount?.takeIf { it.isNotBlank() }?.let { supplemental["slot-count"] = it }

        val initialInventory = FastbootPartitionInventoryBuilder.build(
            source = snapshot,
            fallbackProduct = connectionInfo?.product,
            supplementalVariables = supplemental,
        )
        val plan = if (allowPointBackfill && isCommandReady) {
            FastbootPartitionProbePlanner.plan(
                source = snapshot,
                inventory = initialInventory,
            )
        } else {
            FastbootPartitionProbePlanner.Plan(
                requests = emptyList(),
                discoveryFallbackUsed = false,
            )
        }
        event(
            "FASTBOOT_PARTITION_BACKFILL_PLAN",
            "planned=${plan.requests.size} enabled=$allowPointBackfill " +
                "discoveryFallback=${plan.discoveryFallbackUsed} privacySafe=true",
        )

        val probes = linkedMapOf<String, MutablePartitionPointProbe>()
        var abortedByIncompleteSession = false
        for (request in plan.requests) {
            if (!isCommandReady) {
                abortedByIncompleteSession = true
                break
            }
            val probe = probes.getOrPut(request.partition) {
                MutablePartitionPointProbe(request.partition)
            }
            probe.attemptedFields += request.field
            val result = queryGetVar(
                FastbootCoreDiagnosticsPlan.Variable(request.variableName),
            )
            if (result == null) {
                abortedByIncompleteSession = true
                break
            }
            val raw = result.value ?: continue
            when (request.field) {
                FastbootGetVarAllParser.MetadataField.SIZE -> {
                    FastbootGetVarAllParser.parseSize(raw)?.let {
                        probe.sizeBytes = it
                        probe.resolvedFields += request.field
                    }
                }
                FastbootGetVarAllParser.MetadataField.TYPE -> {
                    raw.trim().takeIf { it.isNotBlank() }?.let {
                        probe.type = it
                        probe.resolvedFields += request.field
                    }
                }
                FastbootGetVarAllParser.MetadataField.LOGICAL -> {
                    FastbootGetVarAllParser.parseBoolean(raw)?.let {
                        probe.logical = it
                        probe.resolvedFields += request.field
                    }
                }
                FastbootGetVarAllParser.MetadataField.HAS_SLOT -> {
                    FastbootGetVarAllParser.parseBoolean(raw)?.let {
                        probe.hasSlot = it
                        probe.resolvedFields += request.field
                    }
                }
            }
        }

        val collectionWarnings = mutableListOf<FastbootPartitionWarning>()
        if (plan.discoveryFallbackUsed) {
            collectionWarnings += FastbootPartitionWarning(
                code = "FALLBACK_POINT_DISCOVERY",
                message = "getvar:all exposed no concrete partition entries; point queries used fallback discovery candidates.",
                severity = FastbootWarningSeverity.WARNING,
            )
        }
        if (!transactionComplete) {
            collectionWarnings += FastbootPartitionWarning(
                code = "TRANSACTION_INCOMPLETE",
                message = "getvar:all ended before a terminal OKAY or FAIL response was observed.",
                severity = FastbootWarningSeverity.WARNING,
            )
        }
        if (abortedByIncompleteSession) {
            collectionWarnings += FastbootPartitionWarning(
                code = "POINT_QUERY_ABORTED",
                message = "Point-query backfill stopped because the Fastboot transaction lane was no longer ready.",
                severity = FastbootWarningSeverity.WARNING,
            )
        }

        val inventory = FastbootPartitionInventoryBuilder.build(
            source = snapshot,
            fallbackProduct = connectionInfo?.product,
            supplementalVariables = supplemental,
            pointProbes = probes.values.map { it.snapshot() },
            collectionWarnings = collectionWarnings,
        )
        val publicInventory = inventory.toPublicSummary()
        val resolvedPointQueries = inventory.pointQueryCount - inventory.unresolvedPointQueryCount
        event(
            "FASTBOOT_PARTITION_BACKFILL_COMPLETE",
            "planned=${plan.requests.size} attempted=${inventory.pointQueryCount} " +
                "resolved=$resolvedPointQueries unresolved=${inventory.unresolvedPointQueryCount} " +
                "aborted=$abortedByIncompleteSession privacySafe=true",
        )
        val inventorySource = if (allowPointBackfill) {
            "getvar_all_plus_point_queries"
        } else {
            "getvar_all_partial"
        }
        event(
            "FASTBOOT_PARTITION_INVENTORY_COMPLETE",
            "source=$inventorySource topology=${publicInventory.topology} " +
                "currentSlot=${publicInventory.currentSlot ?: "unreported"} " +
                "entries=${publicInventory.entryCount} slotFamilies=${publicInventory.slotFamilyCount} " +
                "physical=${publicInventory.physicalCount} logical=${publicInventory.logicalCount} " +
                "unknownStorage=${publicInventory.unknownStorageCount} normal=${publicInventory.normalCount} " +
                "advanced=${publicInventory.advancedCount} critical=${publicInventory.criticalCount} " +
                "incomplete=${publicInventory.incompleteEntryCount} warnings=${publicInventory.warningCount} " +
                "duplicates=${publicInventory.duplicateMetadataCount} complete=${publicInventory.complete} " +
                "pointQueries=${publicInventory.pointQueryCount} " +
                "unresolvedPointQueries=${publicInventory.unresolvedPointQueryCount} privacySafe=true",
        )
        return snapshot.toPublicSummary(
            transactionComplete = transactionComplete,
            inventory = publicInventory,
        )
    }

    private fun FastbootGetVarAllParser.Result.toPublicSummary(
        transactionComplete: Boolean,
        inventory: PartitionInventorySummary? = null,
    ): GetVarAllSummary = GetVarAllSummary(
        transactionComplete = transactionComplete,
        supported = complete || variables.isNotEmpty() || partitions.isNotEmpty() || ignoredLines.isNotEmpty(),
        complete = complete,
        finalStatus = finalStatus,
        variableCount = variables.size,
        partitionMetadataCount = partitions.size,
        ignoredLineCount = ignoredLines.size,
        duplicateVariableCount = duplicateVariables.size,
        conflictingDuplicateCount = duplicateVariables.count { it.conflicting },
        serialReported = !value("serialno").isNullOrBlank(),
        inventory = inventory,
    )

    private fun FastbootPartitionInventory.toPublicSummary(): PartitionInventorySummary =
        PartitionInventorySummary(
            productReported = !variables["product"].isNullOrBlank(),
            topology = topology.name,
            currentSlot = currentSlot,
            entryCount = entries.size,
            slotFamilyCount = slotFamilies.size,
            physicalCount = entries.count { it.storage == FastbootStorageKind.PHYSICAL },
            logicalCount = entries.count { it.storage == FastbootStorageKind.LOGICAL },
            unknownStorageCount = entries.count { it.storage == FastbootStorageKind.UNKNOWN },
            normalCount = entries.count { it.risk == FastbootPartitionRisk.NORMAL },
            advancedCount = entries.count { it.risk == FastbootPartitionRisk.ADVANCED },
            criticalCount = entries.count { it.risk == FastbootPartitionRisk.CRITICAL },
            incompleteEntryCount = entries.count { it.missingFields.isNotEmpty() },
            warningCount = warnings.size,
            duplicateMetadataCount = duplicateMetadataCount,
            pointQueryCount = pointQueryCount,
            unresolvedPointQueryCount = unresolvedPointQueryCount,
            complete = complete,
        )

    private fun eventGetVarAllComplete(summary: GetVarAllSummary) {
        event(
            "FASTBOOT_GETVAR_ALL_COMPLETE",
            "transactionComplete=${summary.transactionComplete} supported=${summary.supported} " +
                "complete=${summary.complete} finalType=${summary.finalStatus} " +
                "variables=${summary.variableCount} partitionMetadata=${summary.partitionMetadataCount} " +
                "ignored=${summary.ignoredLineCount} duplicates=${summary.duplicateVariableCount} " +
                "conflictingDuplicates=${summary.conflictingDuplicateCount} " +
                "serialReported=${summary.serialReported} " +
                "inventoryTopology=${summary.inventory?.topology ?: "unreported"} " +
                "inventoryEntries=${summary.inventory?.entryCount ?: 0} " +
                "pointQueries=${summary.inventory?.pointQueryCount ?: 0} " +
                "unresolvedPointQueries=${summary.inventory?.unresolvedPointQueryCount ?: 0} " +
                "payloadsRedacted=true",
        )
    }

    private fun readPacket(
        timeoutMs: Int,
        redactPayload: Boolean = false,
    ): FastbootPacket? {
        val usbConnection = connection ?: return null
        val input = endpointIn ?: return null
        val buffer = ByteArray(FASTBOOT_RESPONSE_BUFFER_BYTES)
        val bytesRead = usbConnection.bulkTransfer(
            input,
            buffer,
            0,
            buffer.size,
            timeoutMs,
        )
        if (bytesRead <= 0) return null

        val packet = FastbootPacketCodec.parse(buffer, bytesRead)
        val eventPayload = if (redactPayload && packet.payload.isNotBlank()) {
            "<redacted>"
        } else {
            packet.payload.take(EVENT_PAYLOAD_LIMIT)
        }
        event(
            "FASTBOOT_RESPONSE",
            "type=${packet.type} bytes=$bytesRead payload=$eventPayload",
        )
        return packet
    }

    private fun FastbootTransactionResult.resultName(): String = when (this) {
        is FastbootTransactionResult.Completed -> "completed:$finalType"
        is FastbootTransactionResult.DataRequested -> "data_requested"
        is FastbootTransactionResult.TimedOut -> "timed_out"
        is FastbootTransactionResult.NotReady -> "not_ready:${state.name.lowercase()}"
        FastbootTransactionResult.Closed -> "closed"
    }

    private fun findSelectedFastbootInterface(): UsbInterface? {
        preferredInterfaceIndex?.let { index ->
            if (index in 0 until device.interfaceCount) {
                val usbInterface = device.getInterface(index)
                if (isFastbootCompatibleInterface(usbInterface, allowGeneric = true)) return usbInterface
                event(
                    "FASTBOOT_INTERFACE_REBIND",
                    "preferred=$index no longer matches Fastboot-compatible bulk pair",
                )
            }
        }

        for (index in 0 until device.interfaceCount) {
            val usbInterface = device.getInterface(index)
            if (isCanonicalFastbootInterface(usbInterface)) return usbInterface
        }
        for (index in 0 until device.interfaceCount) {
            val usbInterface = device.getInterface(index)
            if (isFastbootCompatibleInterface(usbInterface, allowGeneric = false)) return usbInterface
        }
        return null
    }

    private fun isCanonicalFastbootInterface(usbInterface: UsbInterface): Boolean =
        usbInterface.interfaceClass == UsbConstants.USB_CLASS_VENDOR_SPEC &&
            usbInterface.interfaceSubclass == ANDROID_USB_SUBCLASS &&
            usbInterface.interfaceProtocol == FASTBOOT_PROTOCOL &&
            hasBulkPair(usbInterface)

    private fun isFastbootCompatibleInterface(usbInterface: UsbInterface, allowGeneric: Boolean): Boolean {
        if (!hasBulkPair(usbInterface)) return false
        if (usbInterface.interfaceClass != UsbConstants.USB_CLASS_VENDOR_SPEC) return false
        if (allowGeneric) return usbInterface.interfaceProtocol != ADB_PROTOCOL
        return usbInterface.interfaceSubclass == ANDROID_USB_SUBCLASS && usbInterface.interfaceProtocol != ADB_PROTOCOL
    }

    private fun hasBulkPair(usbInterface: UsbInterface): Boolean =
        findBulkEndpoints(usbInterface).let { it.first != null && it.second != null }

    private fun findBulkEndpoints(usbInterface: UsbInterface): Pair<UsbEndpoint?, UsbEndpoint?> {
        var input: UsbEndpoint? = null
        var output: UsbEndpoint? = null
        for (index in 0 until usbInterface.endpointCount) {
            val endpoint = usbInterface.getEndpoint(index)
            if (endpoint.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
            if (endpoint.direction == UsbConstants.USB_DIR_IN && input == null) input = endpoint
            if (endpoint.direction == UsbConstants.USB_DIR_OUT && output == null) output = endpoint
        }
        return input to output
    }

    private fun invalidateTransport(code: TransportFailureCode, message: String) {
        event(
            "FASTBOOT_TRANSPORT_FAILURE",
            "code=${code.name} message=${message.take(EVENT_PAYLOAD_LIMIT)}",
        )
        if (!transportFailureReported) {
            transportFailureReported = true
            runCatching { onTransportFailure(code, message) }
        }
        close()
    }

    private fun <T> transportFailure(code: TransportFailureCode, message: String): T? {
        invalidateTransport(code, message)
        return null
    }

    private fun event(name: String, detail: String) {
        runCatching { onEvent(name, detail) }
    }

    private companion object {
        const val PRODUCT_VARIABLE = "product"
        const val PRODUCT_COMMAND = "getvar:$PRODUCT_VARIABLE"
        const val ANDROID_USB_SUBCLASS = 0x42
        const val ADB_PROTOCOL = 0x01
        const val FASTBOOT_PROTOCOL = 0x03
        const val FASTBOOT_RESPONSE_BUFFER_BYTES = 1024
        const val EVENT_PAYLOAD_LIMIT = 300
        const val FLASH_COMMAND_WRITE_TIMEOUT_MS = 5_000
        const val DOWNLOAD_REQUEST_INACTIVITY_TIMEOUT_MS = 10_000
        const val DATA_FINAL_INACTIVITY_TIMEOUT_MS = 30_000
        const val FLASH_FINAL_INACTIVITY_TIMEOUT_MS = 600_000
        private const val NATIVE_USBFS_CLOSE_WAIT_MS = 100_000L
        private const val NATIVE_USBFS_CLOSE_POLL_MS = 10L
    }
}
