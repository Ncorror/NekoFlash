package io.github.ncorror.nekoflash.fastboot.transport

import android.os.ParcelFileDescriptor
import java.io.File
import java.io.InputStream

/**
 * Exact-size one-shot source used by Fastboot DATA OUT.
 *
 * The caller owns source lifetime. A source may optionally provide a duplicated regular-file
 * descriptor for the Native USBFS path. The descriptor returned by [openNativeReadDescriptor]
 * is owned by the caller and must be closed independently of the source.
 */
internal interface FastbootDataSource {
    val sizeBytes: Long
    fun openInputStream(): InputStream

    /** Returns a caller-owned read-only descriptor, or null when native usbfs is unsupported. */
    fun openNativeReadDescriptor(): ParcelFileDescriptor? = null

    /** Best-effort cancellation hook for sources whose read can block outside USB I/O. */
    fun cancel() = Unit
}

internal class FileFastbootDataSource(
    private val file: File,
) : FastbootDataSource {
    override val sizeBytes: Long
        get() = file.length()

    override fun openInputStream(): InputStream = file.inputStream()

    override fun openNativeReadDescriptor(): ParcelFileDescriptor? = runCatching {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }.getOrNull()

    fun isReadableFile(): Boolean = file.exists() && file.isFile && file.canRead()
}
